"""Pose compatibility for characters already saved in Blockstage 0.2 scenes. No model generation."""
from math import radians
import bpy
from mathutils import Vector

def _set_control_world(rig, name, position, direction=None):
    bone = rig.pose.bones[name]
    matrix = rig.data.bones[name].matrix_local.copy()
    matrix.translation = Vector(position)
    if direction is not None:
        rot = Vector(direction).to_track_quat('Y', 'Z')
        matrix = rot.to_matrix().to_4x4()
        matrix.translation = Vector(position)
    bone.matrix = matrix

def set_hand_grip(rig, amount):
    """Set a symmetric FK finger curl, leaving wrist and arm controls intact."""
    amount = min(1.0, max(0.0, float(amount)))
    for bone in rig.pose.bones:
        split = bone.name.split('.')
        if len(split) == 3 and split[0] in ('index', 'middle', 'ring', 'pinky', 'thumb'):
            index = int(split[1])
            angle = (43 if index == 1 else 65) if split[0] == 'thumb' else (66 if index == 1 else 84 if index == 2 else 64)
            bone.rotation_euler.x = radians(angle) * amount
    rig['bs_hand_grip'] = amount

def apply_pose(rig, pose):
    """Apply one blocking pose; does not insert or overwrite animation keys."""
    if not rig or rig.type != 'ARMATURE' or rig.get('bs_kind') != 'character':
        return
    pose = pose.upper()
    h = float(rig.get('bs_height_scale', 1.0))
    for bone in rig.pose.bones:
        bone.location = (0, 0, 0)
        bone.rotation_mode = 'XYZ'
        bone.rotation_euler = (0, 0, 0)
        bone.scale = (1, 1, 1)
    bpy.context.view_layer.update()
    def move(name, location, direction=None):
        _set_control_world(rig, name, (location[0], location[1], location[2] * h), direction)
    def rest(name):
        v = rig.data.bones[name].head_local
        return [v.x, v.y, v.z / h]
    if pose == 'WALK':
        for side, sign in (('L', 1), ('R', -1)):
            foot = rest('CTRL_foot.' + side)
            foot[1] = -.29 if sign == 1 else .25
            foot[2] += .0 if sign == 1 else .075
            move('CTRL_foot.' + side, foot)
            hand = rest('CTRL_hand.' + side)
            hand[0] *= .61
            hand[1] = .18 if sign == 1 else -.26
            hand[2] = 1.00
            move('CTRL_hand.' + side, hand)
        rig.pose.bones['pelvis'].location.y = -.035 * h
        rig.pose.bones['chest'].rotation_euler.y = radians(-6)
        set_hand_grip(rig, .20)
    elif pose == 'SIT':
        rig.pose.bones['pelvis'].location.y = -.410 * h
        for side, sign in (('L', 1), ('R', -1)):
            foot = rest('CTRL_foot.' + side)
            foot[1] = -.365
            foot[0] *= 1.25
            move('CTRL_foot.' + side, foot)
            move('CTRL_hand.' + side, (sign * .22, -.265, .705), (0, -.70, -.60))
            move('CTRL_knee.' + side, (sign * .20, -.94, .49))
        rig.pose.bones['spine'].rotation_euler.x = radians(5)
        set_hand_grip(rig, .12)
    elif pose == 'REACH':
        move('CTRL_hand.R', (-.20, -.545, 1.61), (0, -.75, .45))
        move('CTRL_elbow.R', (-.64, -.33, 1.20))
        rig.pose.bones['chest'].rotation_euler.x = radians(5)
        rig.pose.bones['head'].rotation_euler.x = radians(-9)
        set_hand_grip(rig, .12)
    elif pose == 'HOLD':
        move('CTRL_hand.R', (-.115, -.33, 1.225), (0, -.25, -.96))
        move('CTRL_hand.L', (.105, -.485, 1.235), (-.12, -.65, -.65))
        move('CTRL_elbow.R', (-.64, -.12, 1.05))
        move('CTRL_elbow.L', (.62, -.20, 1.04))
        set_hand_grip(rig, .87)
    else:
        set_hand_grip(rig, .06)
        pose = 'NEUTRAL'
    rig['bs_pose'] = pose
    bpy.context.view_layer.update()
