# 0.3.0 — Integrated Cast

- Replaced the four original generated characters with Man, Woman, Heavy Man and Heavy Woman from the supplied Cast add-on.
- Bundled only the four requested actor collections and their dependencies.
- Preserved the supplied body meshes, skin weights, 141-bone rigs, native drivers and control shapes.
- Integrated body controls, finger grip, IK/FK matching, foot roll, pose presets and correct control-only animation keying.
- Updated the four character thumbnails; retained the room, furniture and whole-object color tools.
- Kept pose compatibility for actors already saved in older Blockstage scenes.
- All interface text and included guides are in English.
- Installation-unlocked variant: installer metadata lowered to 4.2.0. Functional code and the bundled library are unchanged; this is not a compatibility certification for older Blender versions.

# 0.2.2 — Whole-object colors

- One Furniture Color control for the entire asset and all material slots.
- Walls Color includes complete wall assemblies; Floor Color and Ceiling Color remain separate.
- New whole-object colors replace old per-part overrides.
- Color controls preserve independent assets, duplicates, geometry and animation.
- Room colors persist through rebuilding, new openings and ceiling recreation.
- Removed per-part controls from the interface; all UI and guides are in English.
- Retained the 46 preview thumbnails.

# 0.2.0

- Added Room Builder panel, rectangle and L-shaped presets, and interactive outline drawing.
- Added corner editing, wall visibility, overview and top view.
- Added multiple real door/window/passage openings per wall with collision fitting notices.
- Added hinged door leaves, handles and keyframeable opening angles.
- Added frame divisions, opening duplication, placement and repositioning.
- Added 14 interior assets, ceiling attachment and fixture light power.
- Added mouse placement with grid/wall snapping and 90-degree rotation.
- Added complete furniture selection, dimensions, duplication and removal.
- Added six room furnishing presets and explicit 0.1 room migration.
- Preserved original cast, prop, camera, color ID and export tools.
- Kept all UI in English. Reused existing materials; no new shaders/textures.

Validation: procedural geometry, multiple apertures, fixture drivers, independent
room duplication, door animation after deletion, all assets/layouts, invalid plans,
legacy migration, registration, and saved-data round trip. Interactive drawing,
window placement, furniture placement and rotation were also checked in Blender.
