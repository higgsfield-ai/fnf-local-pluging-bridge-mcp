# Blockstage 0.3.0 — Preview and Color Guide

## Visual catalog

Open **N > Blockstage > Furniture & Lighting**, choose a category, and click the large thumbnail. Select an asset from the pictures and press **Place [Name]**. Click to place, **R** to turn, and **Esc** to cancel.

The **BLOCKSTAGE / BASE 01** library also has thumbnails for characters, furniture, props, vehicles and set pieces. Search filters the pictures. Selecting a thumbnail by itself never creates an object.

Previews also appear in **Object Properties > Blockstage**. Its **Add [Name]** button places furniture at the 3D Cursor. Use the sidebar for interactive mouse placement.

The 46 thumbnails show the actual default generated models. Custom colors and dimensions are visible on the scene objects.

## One color for the whole object

Select any mesh part of a furniture asset and open **Colors** in the Blockstage sidebar, or use **Object Properties > Blockstage**.

**Furniture Color** recolors the entire object, including all its components and material slots. Old part-specific colors are replaced when you choose a new color. Other furniture items keep their own colors.

For rooms, use **Walls Color**, **Floor Color** and **Ceiling Color**. Walls Color includes all walls and their generated corner pieces, trim, frames, door leaves and handles. It does not affect furniture placed in the room. Floor and ceiling colors remain separate.

There are no part-level color controls in the panel. Colors persist through room edits, new openings, ceiling recreation and saving/reopening the file. Materials retain their existing surface properties, so lighting can create shading differences even when base colors match.

## Hide or restore walls

In **N > Blockstage > Room Builder > Walls & Corners**, uncheck the box beside the wall to hide its complete assembly from the viewport and render. Recheck it to restore it. The floor outline stays intact.

## Install

In Blender Preferences, choose **Install from Disk**, select **Blockstage-0.3.0.zip**, then enable Blockstage. Save your work before replacing an installed version manually, and restart Blender to load the updated code.
