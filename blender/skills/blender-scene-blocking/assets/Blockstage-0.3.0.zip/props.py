"""Original, deliberately simple set dressing for Blockstage.

All assets use meters, sit on Z=0 and face -Y. The geometry is generated locally;
no downloaded models, textures, fonts, or external files are required.
"""

import math

import bpy

from .core import attach, box, cylinder, material, mesh_object


ASSET_ITEMS = [
    ("sofa", "Sofa · 3 seat", "Low backed sofa with three distinct seat cushions", "FURNITURE"),
    ("sectional", "Sofa · Chaise", "Asymmetric sectional sofa with a long chaise", "FURNITURE"),
    ("armchair", "Lounge Chair", "Soft block lounge chair with timber feet", "FURNITURE"),
    ("dining_chair", "Dining Chair", "Light timber chair with an upholstered seat", "FURNITURE"),
    ("bench", "Bench", "Long simple bench for a park, hall, or waiting room", "FURNITURE"),
    ("dining_table", "Dining Table", "Six person timber dining table", "FURNITURE"),
    ("round_table", "Round Table", "Faceted pedestal cafe table", "FURNITURE"),
    ("coffee_table", "Coffee Table", "Low coffee table with an open lower shelf", "FURNITURE"),
    ("desk", "Desk", "Writing desk with a drawer pedestal", "FURNITURE"),
    ("bed", "Double Bed", "Double bed with headboard, blanket, and two pillows", "FURNITURE"),
    ("bookcase", "Bookcase", "Open shelf unit with a few graphic books and boxes", "FURNITURE"),
    ("cabinet", "Sideboard", "Low two-door sideboard with recessed handles", "FURNITURE"),
    ("floor_lamp", "Floor Lamp", "Floor lamp with a broad faceted shade", "FURNITURE"),
    ("table_lamp", "Table Lamp", "Compact sculptural lamp; place on a table", "FURNITURE"),
    ("plant", "Potted Plant", "Graphic low polygon indoor plant in a tapered pot", "FURNITURE"),
    ("crate", "Storage Crate", "Stackable storage box with contrasting corner strips", "PROPS"),
    ("suitcase", "Suitcase", "Upright wheeled suitcase with an extended handle", "PROPS"),
    ("phone", "Phone", "Simple phone with a dark inset screen", "PROPS"),
    ("laptop", "Open Laptop", "Readable open laptop silhouette for an office scene", "PROPS"),
    ("rifle", "Film Prop · Rifle", "Nonfunctional stylized movie-prop silhouette", "PROPS"),
    ("pistol", "Film Prop · Pistol", "Nonfunctional stylized movie-prop silhouette", "PROPS"),
    ("sedan", "Sedan", "Faceted four door car with readable cabin and wheels", "VEHICLES"),
    ("box_truck", "Box Truck", "Simple delivery truck with separate cabin and cargo box", "VEHICLES"),
    ("door_frame", "Door + Frame", "Open doorway with a separate door leaf", "SET"),
    ("window_frame", "Window Frame", "Freestanding four-pane architectural window", "SET"),
    ("stairs", "Stair Flight", "Six steps with landing; front at -Y", "SET"),
    ("platform", "Stage Platform", "Low raised platform for blocking action", "SET"),
    ("bollard", "Street Bollard", "Short contrasting bollard for streets and car parks", "SET"),
]


class _Build:
    def __init__(self, root, collection, color_index):
        self.root = root
        self.collection = collection
        self.mats = {role: material(role, color_index) for role in (
            "primary", "secondary", "dark", "light", "wood", "glass", "metal"
        )}

    def box(self, name, location, dimensions, role="primary", bevel=0.025,
            rotation=None, parent=None):
        obj = box(name, location, dimensions, self.mats[role], self.collection,
                  parent=parent or self.root, bevel=bevel)
        if rotation:
            obj.rotation_euler = rotation
        return obj

    def cyl(self, name, location, radius, depth, role="primary", vertices=12,
            rotation=None, parent=None):
        return cylinder(name, location, radius, depth, self.mats[role],
                        self.collection, parent=parent or self.root,
                        vertices=vertices, rotation=rotation)

    def mesh(self, name, vertices, faces, role="primary", parent=None):
        return mesh_object(name, vertices, faces, self.mats[role],
                           self.collection, parent=parent or self.root)

    def taper(self, name, center, lower, upper, depth, role="primary", vertices=12):
        """Flat shaded frustum, with both caps; radii are measured in XY."""
        x, y, z = center
        vs = []
        for radius, level in ((lower, z - depth / 2), (upper, z + depth / 2)):
            vs += [(x + radius * math.cos(i * math.tau / vertices),
                    y + radius * math.sin(i * math.tau / vertices), level)
                   for i in range(vertices)]
        fs = [tuple(reversed(range(vertices))), tuple(range(vertices, 2 * vertices))]
        fs += [(i, (i + 1) % vertices, (i + 1) % vertices + vertices, i + vertices)
               for i in range(vertices)]
        return self.mesh(name, vs, fs, role)

    def beam(self, name, start, end, width, role="wood", depth=None):
        from mathutils import Vector
        a, b = Vector(start), Vector(end)
        obj = self.box(name, (a + b) / 2, (width, depth or width, (b - a).length),
                       role, bevel=min(width * .12, .014))
        obj.rotation_euler = (b - a).to_track_quat("Z", "Y").to_euler()
        return obj

    def feet(self, width, depth, height, inset=.12, thickness=.06, role="wood"):
        for x in (-width / 2 + inset, width / 2 - inset):
            for y in (-depth / 2 + inset, depth / 2 - inset):
                self.box("Foot", (x, y, height / 2), (thickness, thickness, height), role,
                         bevel=.009)


def _sofa(b, chaise=False, single=False):
    width = .88 if single else 2.32
    depth = .89
    b.feet(width, depth, .19, thickness=.065)
    b.box("Upholstered base", (0, 0, .285), (width, depth, .25), "secondary", .055)
    b.box("Back", (0, .335, .66), (width, .21, .64), "primary", .055)
    for x in (-width / 2 + .08, width / 2 - .08):
        b.box("Arm", (x, -.035, .49), (.18, .83, .49), "primary", .045)
    count = 1 if single else 3
    inner = width - .39
    for i in range(count):
        x = -inner / 2 + inner * (i + .5) / count
        b.box("Seat cushion", (x, -.075, .448), (inner / count - .024, .62, .16),
              "primary", .041)
        b.box("Back cushion", (x, .187, .711), (inner / count - .028, .16, .46),
              "secondary", .047, rotation=(math.radians(-8), 0, 0))
    if chaise:
        x = width / 2 - .51
        b.box("Chaise base", (x, -.73, .285), (.88, .85, .25), "secondary", .055)
        b.box("Chaise cushion", (x, -.76, .448), (.79, .81, .16), "primary", .045)
        for foot_x in (x - .30, x + .30):
            b.box("Chaise foot", (foot_x, -1.03, .095), (.065, .065, .19), "wood", .009)


def _dining_chair(b):
    b.feet(.46, .49, .43, inset=.045, thickness=.046)
    b.box("Seat frame", (0, 0, .428), (.47, .50, .062), "wood", .013)
    b.box("Seat cushion", (0, -.01, .477), (.445, .46, .058), "primary", .025)
    for x in (-.203, .203):
        b.beam("Back upright", (x, .207, .44), (x, .255, .87), .046)
    b.box("Backrest", (0, .252, .795), (.47, .075, .21), "primary", .022,
          rotation=(math.radians(-6), 0, 0))


def _bench(b):
    b.box("Bench seat", (0, 0, .465), (1.72, .45, .10), "wood", .03)
    for x in (-.63, .63):
        b.box("Bench leg", (x, 0, .21), (.11, .38, .42), "dark", .018)
    b.box("Backrest", (0, .235, .79), (1.72, .075, .24), "primary", .025)
    for x in (-.63, .63):
        b.box("Back upright", (x, .23, .64), (.055, .055, .50), "dark", .007)


def _table(b, style):
    if style == "round_table":
        b.cyl("Foot", (0, 0, .025), .31, .05, "dark", vertices=16)
        b.cyl("Pedestal", (0, 0, .364), .06, .68, "dark")
        b.cyl("Tabletop", (0, 0, .746), .49, .055, "wood", vertices=24)
        return
    coffee = style == "coffee_table"
    width, depth, height = ((1.06, .62, .39) if coffee else (1.80, .86, .76))
    b.feet(width, depth, height - .055, thickness=.065, inset=.10)
    b.box("Tabletop", (0, 0, height - .0275), (width, depth, .055), "wood", .022)
    if coffee:
        b.box("Lower shelf", (0, 0, .16), (width - .20, depth - .20, .035),
              "secondary", .012)
    else:
        for y in (-depth / 2 + .1, depth / 2 - .1):
            b.box("Apron", (0, y, height - .12), (width - .2, .04, .12), "wood", .008)


def _desk(b):
    b.box("Desktop", (0, 0, .738), (1.44, .70, .06), "wood", .022)
    for y in (-.27, .27):
        b.box("Slim leg", (-.625, y, .352), (.045, .045, .704), "dark", .006)
    b.box("Foot rail", (-.625, 0, .10), (.045, .58, .045), "dark", .006)
    b.box("Drawer pedestal", (.475, .02, .34), (.37, .58, .65), "primary", .025)
    for z, h in ((.52, .18), (.275, .28)):
        b.box("Drawer front", (.475, -.281, z), (.326, .018, h), "secondary", .009)
        b.box("Drawer pull", (.475, -.299, z + .04), (.12, .028, .018), "dark", .004)


def _bed(b):
    b.feet(1.60, 2.10, .18, inset=.14, thickness=.085)
    b.box("Bed frame", (0, 0, .265), (1.66, 2.12, .22), "wood", .035)
    b.box("Mattress", (0, -.015, .435), (1.55, 2.00, .24), "light", .065)
    b.box("Headboard", (0, 1.02, .65), (1.74, .12, 1.10), "primary", .045)
    b.box("Blanket", (0, -.32, .562), (1.565, 1.365, .052), "primary", .018)
    b.box("Blanket fold", (0, .34, .587), (1.56, .16, .045), "secondary", .014)
    for x in (-.397, .397):
        b.box("Pillow", (x, .704, .607), (.65, .43, .145), "light", .055)


def _bookcase(b):
    width, depth, height = 1.13, .34, 1.92
    for x in (-width / 2 + .026, width / 2 - .026):
        b.box("Shelf side", (x, 0, height / 2), (.052, depth, height), "wood", .009)
    b.box("Backing", (0, .145, height / 2), (width - .10, .025, height - .09),
          "secondary", .004)
    for z in (.065, .52, .975, 1.43, 1.89):
        b.box("Shelf", (0, 0, z), (width, depth, .055), "wood", .01)
    # A few readable masses communicate books without visual noise.
    for shelf, row in ((.552, [(-.38, .25), (-.27, .29), (-.16, .23)]),
                       (1.007, [( .14, .27), ( .25, .23), (.35, .30)])):
        for index, (x, h) in enumerate(row):
            b.box("Book", (x, -.005, shelf + h / 2), (.073, .23, h),
                  "primary" if index % 2 == 0 else "light", .003)
    b.box("Storage box", (.23, -.015, .21), (.36, .25, .24), "primary", .02)
    b.box("Shelf box", (-.25, -.015, 1.58), (.37, .25, .24), "light", .02)


def _cabinet(b):
    b.feet(1.40, .46, .17, inset=.09, thickness=.045, role="dark")
    b.box("Cabinet case", (0, 0, .47), (1.40, .46, .62), "wood", .024)
    for x in (-.342, .342):
        b.box("Cabinet door", (x, -.239, .475), (.662, .034, .546), "primary", .012)
    for x in (-.075, .075):
        b.box("Door pull", (x, -.263, .51), (.019, .022, .095), "dark", .004)


def _lamp(b, tall):
    if tall:
        b.cyl("Lamp base", (0, 0, .025), .205, .05, "dark", 16)
        b.cyl("Stem", (0, 0, .710), .021, 1.40, "metal", 10)
        b.taper("Faceted lampshade", (0, 0, 1.425), .31, .17, .39, "light", 12)
        b.cyl("Shade top", (0, 0, 1.623), .17, .009, "primary", 12)
    else:
        b.taper("Lamp body", (0, 0, .16), .12, .071, .28, "primary", 12)
        b.cyl("Lamp base", (0, 0, .016), .139, .032, "secondary", 12)
        b.taper("Faceted lampshade", (0, 0, .395), .235, .115, .23, "light", 12)
    # Deliberately geometry only: adding a prop must not alter scene lighting.


def _leaf(b, start, end, width):
    from mathutils import Vector
    a, e = Vector(start), Vector(end)
    axis = e - a
    normal = axis.cross(Vector((0, 0, 1)))
    if normal.length < .001:
        normal = Vector((1, 0, 0))
    normal.normalize()
    center = a + axis * .56
    ridge = center + Vector((0, 0, width * .19))
    vs = [tuple(a), tuple(center - normal * width / 2), tuple(e),
          tuple(center + normal * width / 2), tuple(ridge)]
    return b.mesh("Faceted leaf", vs, [(0, 1, 4), (1, 2, 4), (2, 3, 4), (3, 0, 4)], "primary")


def _plant(b):
    b.taper("Planter", (0, 0, .20), .155, .22, .40, "light", 10)
    b.cyl("Soil", (0, 0, .392), .202, .012, "dark", 10)
    b.cyl("Stem", (0, 0, .75), .015, .72, "wood", 8)
    for i, (z, length, spread) in enumerate(((.53, .41, .25), (.66, .43, .22),
                                            (.80, .35, .19), (.91, .31, .16),
                                            (1.04, .26, .16))):
        angle = i * 2.35
        end = (math.cos(angle) * length, math.sin(angle) * length, z + .19)
        b.beam("Leaf stem", (0, 0, z), (end[0] * .47, end[1] * .47, z + .11),
               .012, "wood")
        _leaf(b, (0, 0, z + .055), end, spread)
    _leaf(b, (0, 0, 1.04), (.09, .055, 1.38), .15)


def _crate(b):
    b.box("Storage crate", (0, 0, .32), (.72, .55, .64), "primary", .032)
    b.box("Lid", (0, 0, .636), (.742, .57, .054), "secondary", .014)
    for x in (-.285, .285):
        b.box("Reinforcing strip", (x, 0, .32), (.07, .575, .63), "dark", .007)
    b.box("Front inset", (0, -.283, .386), (.255, .018, .13), "secondary", .008)
    b.box("Handle", (0, -.297, .42), (.125, .018, .036), "dark", .005)


def _suitcase(b):
    b.box("Suitcase shell", (0, 0, .43), (.48, .27, .72), "primary", .055)
    b.box("Case band", (0, 0, .43), (.489, .026, .725), "dark", .008)
    for x in (-.172, .172):
        b.cyl("Roller", (x, .070, .047), .046, .055, "dark", 10, (0, math.pi / 2, 0))
    for x in (-.11, .11):
        b.box("Handle rail", (x, .065, .91), (.022, .022, .43), "metal", .005)
    b.box("Extended handle", (0, .065, 1.121), (.275, .047, .041), "dark", .01)
    for x in (-.12, 0, .12):
        b.box("Front rib", (x, -.14, .44), (.023, .018, .47), "secondary", .007)


def _phone(b):
    b.box("Phone body", (0, 0, .0065), (.078, .156, .013), "primary", .006)
    b.box("Screen", (0, -.001, .0135), (.067, .132, .0018), "dark", .005)
    b.box("Speaker", (0, .068, .015), (.012, .002, .001), "metal", .0004)


def _laptop(b):
    b.box("Laptop base", (0, 0, .009), (.34, .235, .018), "secondary", .008)
    b.box("Keyboard inset", (0, .015, .019), (.285, .102, .002), "dark", .003)
    b.box("Trackpad", (0, -.075, .019), (.102, .054, .002), "primary", .003)
    # Mesh lets the screen lean back while its bottom edge stays at the hinge.
    verts = [(-.17, .108, .017), (.17, .108, .017), (.17, .163, .236), (-.17, .163, .236),
             (-.17, .116, .017), (.17, .116, .017), (.17, .171, .236), (-.17, .171, .236)]
    b.mesh("Display housing", verts, [(0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1),
                                     (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)], "primary")
    b.mesh("Laptop screen", [(-.154, .111, .039), (.154, .111, .039),
                              (.154, .157, .219), (-.154, .157, .219)], [(0, 1, 2, 3)], "dark")


def _silhouette_extrusion(b, name, outline, width, role):
    """An intentionally solid, nonfunctional movie prop, outlined in YZ."""
    n = len(outline)
    verts = [(-width / 2, y, z) for y, z in outline] + [(width / 2, y, z) for y, z in outline]
    faces = [tuple(reversed(range(n))), tuple(range(n, n * 2))]
    faces += [(i, (i + 1) % n, (i + 1) % n + n, i + n) for i in range(n)]
    return b.mesh(name, verts, faces, role)


def _rifle(b):
    # Only large visual masses. No bore, firing parts, functional details, or mechanism.
    b.box("Prop body", (0, -.02, .24), (.078, .42, .105), "primary", .012)
    b.box("Solid fore-end", (0, -.274, .239), (.086, .22, .096), "secondary", .009)
    b.box("Solid barrel silhouette", (0, -.455, .248), (.035, .20, .035), "dark", .004)
    _silhouette_extrusion(b, "Stock silhouette", [(.165, .29), (.40, .285), (.43, .265),
                                                  (.43, .145), (.32, .145), (.25, .21),
                                                  (.165, .212)], .062, "secondary")
    _silhouette_extrusion(b, "Grip silhouette", [(.07, .217), (.139, .217), (.20, .035),
                                                 (.125, .020)], .052, "dark")
    _silhouette_extrusion(b, "Magazine silhouette", [(-.113, .207), (-.025, .207),
                                                     (-.035, .025), (-.102, 0),
                                                     (-.143, .025)], .060, "dark")
    b.box("Top silhouette", (0, -.036, .306), (.027, .23, .025), "dark", .004)


def _pistol(b):
    b.box("Solid upper silhouette", (0, -.024, .165), (.036, .198, .044), "secondary", .008)
    _silhouette_extrusion(b, "Solid grip silhouette", [(.002, .151), (.077, .147),
                                                       (.105, .02), (.088, 0), (.029, 0),
                                                       (-.014, .112), (-.082, .122),
                                                       (-.082, .15)], .034, "primary")


def _cabin(b, name, width, bottom_z, top_z, front_bottom, back_bottom, front_top,
           back_top, role="primary"):
    half = width / 2
    top_half = half * .83
    verts = [(-half, front_bottom, bottom_z), (half, front_bottom, bottom_z),
             (half, back_bottom, bottom_z), (-half, back_bottom, bottom_z),
             (-top_half, front_top, top_z), (top_half, front_top, top_z),
             (top_half, back_top, top_z), (-top_half, back_top, top_z)]
    b.mesh(name, verts, [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
                         (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)], role)


def _wheel(b, x, y, radius=.335, depth=.20):
    b.cyl("Faceted tire", (x, y, radius), radius, depth, "dark", 16, (0, math.pi / 2, 0))
    side = -1 if x < 0 else 1
    b.cyl("Wheel hub", (x + side * (depth / 2 + .002), y, radius), radius * .57,
          .018, "metal", 12, (0, math.pi / 2, 0))
    b.cyl("Hub center", (x + side * (depth / 2 + .013), y, radius), radius * .22,
          .023, "secondary", 8, (0, math.pi / 2, 0))


def _sedan(b):
    b.box("Chassis shadow", (0, 0, .412), (1.57, 3.75, .18), "dark", .07)
    b.box("Car body", (0, 0, .695), (1.78, 4.15, .54), "primary", .12)
    b.box("Hood", (0, -1.40, .938), (1.66, 1.21, .105), "primary", .055)
    b.box("Trunk", (0, 1.635, .935), (1.67, .72, .105), "primary", .04)
    _cabin(b, "Cabin", 1.63, .916, 1.493, -.94, 1.27, -.38, .79)
    # Each pane is its own surface, offset very slightly from the faceted cabin.
    b.mesh("Windscreen", [(-.734, -.918, .961), (.734, -.918, .961),
                           (.625, -.425, 1.453), (-.625, -.425, 1.453)], [(0, 1, 2, 3)], "glass")
    b.mesh("Rear window", [(-.73, 1.248, .966), (.73, 1.248, .966),
                            (.625, .823, 1.453), (-.625, .823, 1.453)], [(0, 3, 2, 1)], "glass")
    for side in (-1, 1):
        # The side windows follow x(z), avoiding z fighting against the side faces.
        b.mesh("Front side window", [(side * .808, -.817, .973), (side * .808, .14, .973),
                                       (side * .690, .14, 1.453), (side * .690, -.33, 1.453)],
               [(0, 1, 2, 3)], "glass")
        b.mesh("Rear side window", [(side * .808, .211, .973), (side * .808, 1.13, .973),
                                      (side * .690, .743, 1.453), (side * .690, .211, 1.453)],
               [(0, 1, 2, 3)], "glass")
        for y in (-.24, .75):
            b.box("Door handle", (side * .90, y, .851), (.021, .14, .028), "secondary", .008)
        b.box("Side mirror", (side * .949, -.726, 1.028), (.175, .14, .10), "primary", .025)
        for y in (-1.28, 1.27):
            _wheel(b, side * .889, y)
    for x in (-.60, .60):
        b.box("Headlamp", (x, -2.069, .778), (.39, .022, .128), "light", .018)
        b.box("Rear lamp", (x, 2.069, .783), (.35, .022, .105), "secondary", .016)
    b.box("Front grille", (0, -2.076, .58), (.79, .026, .13), "dark", .017)
    b.box("Rear bumper", (0, 2.076, .54), (1.47, .032, .085), "dark", .018)


def _truck(b):
    b.box("Truck chassis", (0, .23, .57), (1.72, 5.02, .22), "dark", .045)
    b.box("Cab base", (0, -1.72, .934), (1.92, 1.61, .64), "primary", .075)
    _cabin(b, "Truck cabin", 1.90, 1.02, 2.115, -2.42, -.91, -2.19, -.93)
    b.mesh("Truck windscreen", [(-.827, -2.382, 1.242), (.827, -2.382, 1.242),
                                  (.739, -2.207, 2.01), (-.739, -2.207, 2.01)],
           [(0, 1, 2, 3)], "glass")
    for side in (-1, 1):
        b.mesh("Cab side window", [(side * .925, -2.27, 1.24), (side * .925, -1.08, 1.24),
                                     (side * .809, -1.08, 2.01), (side * .809, -2.12, 2.01)],
               [(0, 1, 2, 3)], "glass")
        b.box("Cab door handle", (side * .96, -1.195, 1.108), (.022, .145, .03), "dark", .006)
        b.box("Mirror support", (side * 1.04, -2.11, 1.52), (.25, .035, .035), "dark", .006)
        b.box("Truck mirror", (side * 1.15, -2.11, 1.52), (.072, .08, .225), "dark", .015)
        b.box("Cab step", (side * 1.0, -1.22, .62), (.20, .48, .095), "metal", .014)
        for y in (-1.76, 1.73):
            _wheel(b, side * .96, y, radius=.415, depth=.24)
    b.box("Cargo box", (0, .925, 1.648), (2.12, 3.65, 1.93), "secondary", .04)
    b.box("Cargo top edge", (0, .925, 2.601), (2.16, 3.69, .075), "light", .016)
    for x in (-1.035, 1.035):
        b.box("Cargo lower rail", (x, .925, .758), (.052, 3.66, .10), "metal", .009)
    for x in (-.512, .512):
        b.box("Rear cargo door", (x, 2.76, 1.62), (1.00, .032, 1.78), "primary", .016)
        b.box("Door latch", (x + (-.30 if x > 0 else .30), 2.786, 1.53),
              (.028, .018, .74), "metal", .004)
    for x in (-.67, .67):
        b.box("Headlamp", (x, -2.536, 1.00), (.35, .022, .17), "light", .015)
        b.box("Rear signal", (x, 2.778, .729), (.21, .025, .10), "secondary", .008)
    b.box("Truck grille", (0, -2.537, .951), (.74, .026, .25), "dark", .022)
    b.box("Front bumper", (0, -2.546, .718), (1.97, .10, .16), "metal", .015)


def _door(b):
    # The open leaf has its own pivot at the left hinge for direct manual edits.
    for x in (-.54, .54):
        b.box("Door jamb", (x, 0, 1.08), (.11, .18, 2.16), "light", .012)
    b.box("Door header", (0, 0, 2.185), (1.19, .18, .12), "light", .012)
    pivot = bpy.data.objects.new("Door hinge · rotate Z", None)
    b.collection.objects.link(pivot)
    attach(pivot, b.root)
    pivot.location = (-.48, 0, 0)
    pivot.rotation_euler.z = math.radians(-60)
    pivot.empty_display_type = "PLAIN_AXES"
    pivot.empty_display_size = .12
    b.box("Door leaf", (.47, 0, 1.055), (.94, .055, 2.11), "primary", .011, parent=pivot)
    b.box("Door inset", (.47, -.033, 1.12), (.70, .009, 1.52), "secondary", .012, parent=pivot)
    for y in (-.055, .055):
        b.box("Handle", (.80, y, 1.0), (.105, .022, .028), "metal", .009, parent=pivot)


def _window(b):
    w, h = 1.40, 1.20
    for x in (-w / 2 + .04, w / 2 - .04):
        b.box("Window side", (x, 0, h / 2), (.08, .13, h), "light", .01)
    for z in (.04, h - .04):
        b.box("Window rail", (0, 0, z), (w, .13, .08), "light", .01)
    b.box("Vertical mullion", (0, -.01, h / 2), (.042, .09, h - .10), "light", .006)
    b.box("Horizontal mullion", (0, -.01, h / 2), (w - .10, .09, .042), "light", .006)
    for x in (-.328, .328):
        for z in (.315, .885):
            b.box("Window pane", (x, .019, z), (.59, .018, .51), "glass", .002)
    b.box("Window sill", (0, -.075, .035), (1.53, .32, .07), "wood", .012)


def _stairs(b):
    steps, rise, run, width = 6, .17, .29, 1.20
    for i in range(steps):
        h = (i + 1) * rise
        y = (i - (steps - 1) / 2) * run
        b.box("Step %02d" % (i + 1), (0, y, h / 2), (width, run + .002, h),
              "secondary", .008)
        b.box("Step edge", (0, y - run / 2 + .014, h + .001),
              (width - .045, .028, .004), "light", .002)
    b.box("Top landing", (0, 1.16, .51), (width, .58, 1.02), "secondary", .008)
    for side in (-1, 1):
        for y, z in ((-.725, .17), (.725, 1.02)):
            b.box("Rail post", (side * .565, y, z + .44), (.035, .035, .88), "dark", .005)
        b.beam("Handrail", (side * .565, -.83, .99), (side * .565, .88, 1.99),
               .045, "dark")


def _platform(b):
    b.box("Platform", (0, 0, .16), (2.4, 1.8, .32), "secondary", .02)
    b.box("Stage top", (0, 0, .334), (2.42, 1.82, .028), "primary", .01)
    b.box("Access step", (0, -1.07, .0775), (.90, .34, .155), "secondary", .014)


def _bollard(b):
    b.cyl("Bollard base", (0, 0, .036), .16, .072, "dark", 12)
    b.cyl("Bollard", (0, 0, .455), .09, .85, "primary", 10)
    b.cyl("Reflective band", (0, 0, .692), .092, .09, "light", 10)
    b.taper("Bollard cap", (0, 0, .891), .09, .067, .028, "dark", 10)


_BUILDERS = {
    "sofa": lambda b: _sofa(b),
    "sectional": lambda b: _sofa(b, chaise=True),
    "armchair": lambda b: _sofa(b, single=True),
    "dining_chair": _dining_chair,
    "bench": _bench,
    "dining_table": lambda b: _table(b, "dining_table"),
    "round_table": lambda b: _table(b, "round_table"),
    "coffee_table": lambda b: _table(b, "coffee_table"),
    "desk": _desk,
    "bed": _bed,
    "bookcase": _bookcase,
    "cabinet": _cabinet,
    "floor_lamp": lambda b: _lamp(b, True),
    "table_lamp": lambda b: _lamp(b, False),
    "plant": _plant,
    "crate": _crate,
    "suitcase": _suitcase,
    "phone": _phone,
    "laptop": _laptop,
    "rifle": _rifle,
    "pistol": _pistol,
    "sedan": _sedan,
    "box_truck": _truck,
    "door_frame": _door,
    "window_frame": _window,
    "stairs": _stairs,
    "platform": _platform,
    "bollard": _bollard,
}


def create_asset(context, asset_id, collection, color_index=0):
    """Create one editable hierarchy. The caller places/selects/colors the root."""
    if asset_id not in _BUILDERS:
        raise ValueError("Unknown Blockstage asset: %s" % asset_id)
    label = next(item[1] for item in ASSET_ITEMS if item[0] == asset_id)
    root = bpy.data.objects.new(label, None)
    collection.objects.link(root)
    root.empty_display_type = "PLAIN_AXES"
    root.empty_display_size = .28
    root["bs_root"] = True
    root["bs_kind"] = "prop"
    root["bs_asset"] = asset_id
    root["bs_color_index"] = color_index
    root["bs_front"] = "-Y"
    _BUILDERS[asset_id](_Build(root, collection, color_index))
    return root
