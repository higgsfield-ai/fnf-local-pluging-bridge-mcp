"""Whole-asset color controls, with persistent colors for generated room assemblies."""
import uuid
import bpy
from bpy.props import FloatVectorProperty, PointerProperty
from . import core

ROLES = ('primary', 'secondary', 'wood', 'metal', 'dark', 'light', 'glass')
ROOM_GROUPS = ('walls', 'floor', 'ceiling', 'trim', 'doors', 'frames', 'hardware')
DEFAULT_ROLES = dict(walls='light', floor='wood', ceiling='light', trim='dark', doors='primary', frames='dark', hardware='metal')


def owned_meshes(root):
    objects = [root]
    for obj in objects:
        objects.extend(c for c in obj.children if not c.get('bs_root'))
    return [o for o in objects if o.type == 'MESH' and not o.get('bs_widget')]


def arch_group(key):
    if key.startswith(('wall_', 'corner_')): return 'walls'
    if key in {'floor', 'ceiling'}: return key
    if key.startswith('trim_'): return 'trim'
    if key.endswith('_leaf'): return 'doors'
    if key.endswith('_frame'): return 'frames'
    if key.endswith('_handle'): return 'hardware'
    return None


def material_color(obj, mat):
    if mat and mat.get('bs_role') in {'primary', 'secondary'} and not mat.get('bs_painted'):
        value = tuple(obj.color)
        return tuple(c * .52 for c in value[:3]) + (1,) if mat.get('bs_role') == 'secondary' else value
    return tuple(mat.diffuse_color) if mat else (.5, .5, .5, 1)


def mesh_role(obj):
    return obj.material_slots[0].material.get('bs_role', 'primary') if obj.material_slots and obj.material_slots[0].material else 'primary'


def root_of(obj):
    return core.asset_root(obj)


def group_meshes(root, group):
    meshes = owned_meshes(root)
    if root.get('bs_kind') == 'room':
        return [o for o in meshes if arch_group(o.get('bs_arch_key', o.get('bs_room_part', ''))) == group]
    return [o for o in meshes if any(s.material and s.material.get('bs_role') == group for s in o.material_slots)]


def legacy_color(root, group):
    key = 'bs_color_' + group
    if key in root: return tuple(root[key])
    objects = group_meshes(root, group)
    if objects:
        obj = objects[0]
        mat = next((s.material for s in obj.material_slots if s.material and (root.get('bs_kind') == 'room' or s.material.get('bs_role') == group)), None)
        return material_color(obj, mat)
    return tuple(core.material(DEFAULT_ROLES.get(group, group)).diffuse_color)


def painted_material(owner, key, source, value):
    """One persistent material per edited group, copied on first edit of duplicates."""
    token = owner.get('bs_uid') or owner.get('bs_paint_uid')
    if not token:
        token = uuid.uuid4().hex; owner['bs_paint_uid'] = token
    stored_key = 'bs_color_material_' + key
    mat = owner.get(stored_key)
    if not isinstance(mat, bpy.types.Material) or mat.get('bs_paint_owner') != token:
        mat = source.copy() if source else core.material('light').copy()
        mat.name = 'BS / ' + owner.name + ' / ' + key.replace('_', ' ').title()
        mat['bs_paint_owner'] = token
        mat['bs_painted'] = True
        owner[stored_key] = mat
    mat.diffuse_color = value
    if mat.use_nodes:
        for node in mat.node_tree.nodes:
            if node.type == 'BSDF_PRINCIPLED':
                socket = node.inputs.get('Base Color')
                if socket:
                    for link in list(socket.links): mat.node_tree.links.remove(link)
                    socket.default_value = value
    return mat


def assign(obj, mat, role=None):
    if not obj.material_slots:
        if obj.data.users > 1: obj.data = obj.data.copy()
        obj.data.materials.append(mat)
    else:
        for slot in obj.material_slots:
            if role is None or (slot.material and slot.material.get('bs_role') == role):
                slot.link = 'OBJECT'; slot.material = mat
    # Also useful in Solid > Object color mode.
    obj.color = mat.diffuse_color


def viewport_colors(context):
    if not context: return
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces.active.shading.color_type = 'MATERIAL'
                area.tag_redraw()


def whole_group(root, group):
    if root.get('bs_kind') != 'room': return 'asset'
    return group if group in {'floor', 'ceiling'} else 'walls'


def architecture_group(key):
    """Frames, trim, door leaves and handles are part of the complete wall assembly."""
    group = arch_group(key)
    return group if group in {'floor', 'ceiling'} else 'walls' if group else None


def uniform_meshes(root, group):
    meshes = owned_meshes(root)
    if group == 'asset': return meshes
    return [obj for obj in meshes if architecture_group(obj.get('bs_arch_key', obj.get('bs_room_part', ''))) == group]


def read_color(root, group):
    group = whole_group(root, group)
    key = 'bs_uniform_color_' + group
    if key in root: return tuple(root[key])
    # Preserve the existing appearance until the user chooses a whole-object color.
    if group == 'asset' and not group_meshes(root, 'primary'):
        objects = owned_meshes(root)
        if objects:
            obj = objects[0]
            return material_color(obj, obj.material_slots[0].material if obj.material_slots else None)
    return legacy_color(root, 'primary' if group == 'asset' else group)


def paint_mesh(root, obj, group, value):
    """Use the same base color in every slot while retaining each surface's roughness."""
    if not obj.material_slots:
        assign(obj, painted_material(root, 'uniform_' + group + '_light', core.material('light'), value))
    else:
        for slot in obj.material_slots:
            source = slot.material
            role = source.get('bs_role', 'custom') if source else 'light'
            mat = painted_material(root, 'uniform_' + group + '_' + role, source, value)
            slot.link = 'OBJECT'; slot.material = mat
    obj.color = value


def clear_previous_colors(root, group, objects):
    if group == 'asset':
        for role in ROLES:
            key = 'bs_color_' + role
            if key in root: del root[key]
    else:
        for previous_group in ROOM_GROUPS:
            if whole_group(root, previous_group) == group:
                key = 'bs_color_' + previous_group
                if key in root: del root[key]
        # Includes currently hidden or removed generated parts, so they cannot
        # regain an old override when a ceiling or opening is re-created.
        for key in list(root.keys()):
            if key.startswith('bs_color_part_') and architecture_group(key[len('bs_color_part_'):]) == group:
                del root[key]
    for obj in objects:
        if 'bs_part_color' in obj: del obj['bs_part_color']


def write_color(root, group, value):
    root = root_of(root) or root
    group = whole_group(root, group)
    value = tuple(value[:3]) + (1,)
    objects = uniform_meshes(root, group)
    clear_previous_colors(root, group, objects)
    root['bs_uniform_color_' + group] = value
    for obj in objects: paint_mesh(root, obj, group, value)
    viewport_colors(bpy.context)


def restore_arch_part(root, obj, key):
    """Uniform colors win over any legacy part override after regeneration."""
    group = architecture_group(key)
    uniform_key = 'bs_uniform_color_' + str(group)
    if group and uniform_key in root:
        paint_mesh(root, obj, group, tuple(root[uniform_key]))
        return
    # Opening a 0.2.1 file does not recolor it. Its old appearance is supported
    # until a new whole-assembly color is explicitly chosen.
    legacy_group = arch_group(key)
    part_key = 'bs_color_part_' + key
    if part_key in root:
        source = obj.material_slots[0].material if obj.material_slots else None
        assign(obj, painted_material(root, 'part_' + key, source, tuple(root[part_key])))
    elif legacy_group and 'bs_color_' + legacy_group in root:
        source = obj.material_slots[0].material if obj.material_slots else None
        assign(obj, painted_material(root, legacy_group, source, tuple(root['bs_color_' + legacy_group])))


def read_surface(obj):
    root = root_of(obj)
    key = obj.get('bs_arch_key', obj.get('bs_room_part', ''))
    if root and key and 'bs_color_part_' + key in root: return tuple(root['bs_color_part_' + key])
    if 'bs_part_color' in obj: return tuple(obj['bs_part_color'])
    mat = obj.material_slots[0].material if obj.material_slots else None
    return material_color(obj, mat)


def write_surface(obj, value):
    root = root_of(obj)
    if not root: return
    key = obj.get('bs_arch_key', obj.get('bs_room_part', ''))
    write_color(root, architecture_group(key) or 'asset', value)


class BS_ColorSettings(bpy.types.PropertyGroup):
    surface: FloatVectorProperty(name='Object Color', description='Compatibility control; colors the entire asset or room assembly', size=4, subtype='COLOR', min=0, max=1,
        get=lambda self: read_surface(self.id_data), set=lambda self, v: write_surface(self.id_data, v))


def color_getter(key):
    def get(self): return read_color(self.id_data, key)
    return get

def color_setter(key):
    def set(self, value): write_color(self.id_data, key, value)
    return set


for _group in dict.fromkeys(('asset',) + ROLES + ROOM_GROUPS):
    BS_ColorSettings.__annotations__[_group] = FloatVectorProperty(
        name={'asset': 'Object Color', 'walls': 'Walls Color', 'floor': 'Floor Color', 'ceiling': 'Ceiling Color'}.get(_group, 'Object Color'),
        description='Color the entire asset or room assembly, including all of its parts',
        size=4, subtype='COLOR', min=0, max=1,
        get=color_getter(_group), set=color_setter(_group))


def draw_colors(layout, context):
    root = root_of(context.object)
    if root is None:
        layout.label(text='Select a Blockstage asset.', icon='INFO'); return
    col = layout.column(align=True)
    col.use_property_split = True; col.use_property_decorate = False
    if root.get('bs_kind') == 'room':
        col.label(text='Room Colors', icon='COLOR')
        for group in ('walls', 'floor', 'ceiling'):
            col.prop(root.bs_colors, group, text=group.title() + ' Color')
    else:
        col.label(text=root.name, icon='COLOR')
        col.prop(root.bs_colors, 'asset', text='Furniture Color' if root.get('bs_kind') == 'prop' else 'Object Color')


class BS_PT_colors(bpy.types.Panel):
    bl_label = 'Colors'; bl_idname = 'BS_PT_colors'
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = 'Blockstage'; bl_order = -5
    def draw(self, context): draw_colors(self.layout, context)


class BS_PT_properties(bpy.types.Panel):
    bl_label = 'Blockstage'; bl_idname = 'BS_PT_properties'
    bl_space_type = 'PROPERTIES'; bl_region_type = 'WINDOW'; bl_context = 'object'
    @classmethod
    def poll(cls, context): return context.object is not None
    def draw(self, context):
        from . import previews, room_tools
        l = self.layout
        if room_tools.active_room(context):
            s = context.scene.bs_editor
            l.prop(s, 'category', text='Library'); l.prop(s, 'search', text='', icon='VIEWZOOM')
            previews.draw_picker(l, context, 'interior')
        else:
            s = context.scene.bs_settings
            l.prop(s, 'category', text='Library'); l.prop(s, 'search', text='', icon='VIEWZOOM')
            previews.draw_picker(l, context, 'library')
        l.separator()
        draw_colors(l, context)


classes = (BS_ColorSettings, BS_PT_colors, BS_PT_properties)


def register():
    for cls in classes: bpy.utils.register_class(cls)
    bpy.types.Object.bs_colors = PointerProperty(type=BS_ColorSettings)


def unregister():
    del bpy.types.Object.bs_colors
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
