"""Interactive room drawing, placement, object editing and compact sidebar."""
import math
import bpy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty,
                       PointerProperty, StringProperty)
from mathutils import Vector,Quaternion
from bpy_extras import view3d_utils
from . import core,props,plan,interiors

CATALOG=[i for i in props.ASSET_ITEMS if i[3]=='FURNITURE']+interiors.EXTRA_ITEMS


def room_for(context):
    obj=context.object
    while obj:
        if obj.get('bs_kind')=='room':return obj
        obj=obj.parent
    return context.scene.bs_editor.room


def active_room(context):
    r=room_for(context)
    return r if r and r.get('bs_plan_version') else None


class BS_Editor(bpy.types.PropertyGroup):
    room: PointerProperty(name='Room',type=bpy.types.Object,
        poll=lambda self,obj:obj.get('bs_kind')=='room')
    grid: FloatProperty(name='Grid step',default=.1,min=.01,max=2,unit='LENGTH')
    wall_snap: BoolProperty(name='Snap to walls',default=True)
    category: EnumProperty(name='Library',items=[(s,s.title(),'') for s in
        ('FURNITURE','KITCHEN','BATHROOM','LIGHTING')])
    search: StringProperty(name='Search',options={'TEXTEDIT_UPDATE'})
    layout: EnumProperty(name='Layout',items=[(s,s.title(),'') for s in
        ('LIVING','BEDROOM','OFFICE','DINING','KITCHEN','BATHROOM')])


class BS_OT_room_new(bpy.types.Operator):
    bl_idname='blockstage.room_new';bl_label='New Room';bl_options={'REGISTER','UNDO'}
    shape: EnumProperty(items=[('RECT','Rectangle',''),('L','L-shaped','')])
    width: FloatProperty(name='Width',default=6,min=1.5,unit='LENGTH')
    depth: FloatProperty(name='Depth',default=5,min=1.5,unit='LENGTH')
    def execute(self,context):
        root=plan.create(context,self.shape,width=self.width,depth=self.depth)
        context.scene.bs_editor.room=root;core.select_root(context,root)
        return {'FINISHED'}


class BS_OT_room_upgrade(bpy.types.Operator):
    bl_idname='blockstage.room_upgrade';bl_label='Upgrade Room to 0.2';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        r=room_for(context)
        if not r:return {'CANCELLED'}
        if not r.get('bs_plan_version'):plan.upgrade(r)
        context.scene.bs_editor.room=r;core.select_root(context,r)
        return {'FINISHED'}


class BS_OT_room_select(bpy.types.Operator):
    bl_idname='blockstage.room_select';bl_label='Select Room'
    def execute(self,context):
        r=room_for(context)
        if r:core.select_root(context,r)
        return {'FINISHED'}


class BS_OT_room_view(bpy.types.Operator):
    bl_idname='blockstage.room_view';bl_label='Frame Room'
    view: EnumProperty(items=[('ISO','Perspective overview',''),('TOP','Floor Plan','')])
    def execute(self,context):
        r=active_room(context)
        if not r or context.area.type!='VIEW_3D':return {'CANCELLED'}
        pts=plan.outline(r)
        center=Vector(((min(x for x,y in pts)+max(x for x,y in pts))/2,(min(y for x,y in pts)+max(y for x,y in pts))/2,r.bs_room.height*.5))
        rv=context.space_data.region_3d
        rv.view_location=r.matrix_world@center
        rv.view_distance=max(max(x for x,y in pts)-min(x for x,y in pts),max(y for x,y in pts)-min(y for x,y in pts))*2.0+r.bs_room.height*.3
        rv.view_perspective='ORTHO'
        rv.view_rotation=Quaternion((1,0,0,0)) if self.view=='TOP' else Vector((1,-1.4,1.2)).to_track_quat('Z','Y')
        if self.view=='TOP':r.bs_plan.view='TOP'
        return {'FINISHED'}


class BS_OT_corner(bpy.types.Operator):
    bl_idname='blockstage.room_corner';bl_label='Edit Plan Corner';bl_options={'REGISTER','UNDO'}
    action: EnumProperty(items=[('CUSTOM','Edit outline',''),('INSERT','Split wall',''),('REMOVE','Remove corner','')])
    def execute(self,context):
        r=active_room(context)
        if not r:return {'CANCELLED'}
        p=r.bs_plan
        if self.action=='CUSTOM':
            p.shape='CUSTOM';return {'FINISHED'}
        if p.shape!='CUSTOM':p.shape='CUSTOM'
        i=min(p.active_point,len(p.points)-1)
        if self.action=='REMOVE' and len(p.points)<=3:
            self.report({'WARNING'},'Keep at least 3 corners.');return {'CANCELLED'}
        if len(p.openings):
            self.report({'WARNING'},'Remove openings before changing the number of walls; moving corners is always available.')
            return {'CANCELLED'}
        with plan.batch(r):
            if self.action=='INSERT':
                a,b=p.points[i],p.points[(i+1)%len(p.points)]
                x,y=(a.x+b.x)/2,(a.y+b.y)/2
                n=p.points.add();n.x=x;n.y=y
                p.points.move(len(p.points)-1,i+1);p.active_point=i+1
            else:p.points.remove(i);p.active_point=max(0,i-1)
        plan.rebuild(r)
        return {'FINISHED'}


class BS_OT_opening(bpy.types.Operator):
    bl_idname='blockstage.opening_edit';bl_label='Edit Opening';bl_options={'REGISTER','UNDO'}
    action: EnumProperty(items=[('ADD_DOOR','Add door',''),('ADD_WINDOW','Add window',''),
        ('ADD_PASSAGE','Add passage',''),('REMOVE','Delete opening',''),('DUPLICATE','Duplicate opening',''),('SELECT','Select opening','')])
    def execute(self,context):
        r=active_room(context)
        if not r:return {'CANCELLED'}
        p=r.bs_plan;i=p.active_opening
        if self.action.startswith('ADD_'):
            wi=min(p.active_point,len(p.points)-1)
            plan.add_opening(r,self.action[4:],wi+1,plan.wall_basis(r,wi)[3]/2)
        elif not 0<=i<len(p.openings):return {'CANCELLED'}
        elif self.action=='REMOVE':
            # Index-based door animation paths must be remapped before removal.
            _remap_opening_animation(r,i)
            p.openings.remove(i);p.active_opening=max(0,i-1);plan.rebuild(r)
        elif self.action=='DUPLICATE':
            src=p.openings[i]
            values={key:getattr(src,key) for key in ('kind','wall','offset','width','height','sill','hinge','columns','rows','angle')}
            with plan.batch(r):
                op=plan.add_opening(r,values['kind'],values['wall'],values['offset']+values['width']+.2)
                for key in values:
                    if key!='offset':setattr(op,key,values[key])
            plan.rebuild(r)
        elif self.action=='SELECT':
            ob=next((o for o in r.children if o.get('bs_opening_uid')==p.openings[i].uid),None)
            if ob:core.select_root(context,ob)
        return {'FINISHED'}


def _remap_opening_animation(root,index):
    """Keep later door animation attached to the same opening after a deletion."""
    ad=root.animation_data
    if not ad:return
    actions=set()
    if ad.action:actions.add(ad.action)
    for track in ad.nla_tracks:
        for strip in track.strips:
            if strip.action:actions.add(strip.action)
    for action in actions:
        containers=[]
        if hasattr(action,'layers') and action.layers:
            for layer in action.layers:
                for strip in layer.strips:
                    for bag in getattr(strip,'channelbags',[]):containers.append(bag.fcurves)
        elif hasattr(action,'fcurves'):containers.append(action.fcurves)
        for curves in containers:
            for fc in list(curves):
                for n in range(index,len(root.bs_plan.openings)):
                    old=f'bs_plan.openings[{n}]'
                    if fc.data_path.startswith(old):
                        if n==index:curves.remove(fc)
                        else:fc.data_path=fc.data_path.replace(old,f'bs_plan.openings[{n-1}]',1)
                        break


def _window_region(context):
    return next((r for r in context.area.regions if r.type=='WINDOW'),None)


def _ray(context,event):
    region=_window_region(context)
    coord=(event.mouse_x-region.x,event.mouse_y-region.y)
    rv=context.space_data.region_3d
    return (view3d_utils.region_2d_to_origin_3d(region,rv,coord),
            view3d_utils.region_2d_to_vector_3d(region,rv,coord))


def _floor_hit(context,event,root=None,z=None):
    origin,direction=_ray(context,event)
    if root:
        inv=root.matrix_world.inverted_safe()
        origin=inv@origin;direction=inv.to_3x3()@direction;level=0
    else:level=context.scene.cursor.location.z if z is None else z
    if abs(direction.z)<1e-7:return None
    t=(level-origin.z)/direction.z
    return origin+direction*t if t>0 else None


def nearest_wall(root,point):
    result=[]
    for i in range(len(plan.outline(root))):
        a,axis,inside,length=plan.wall_basis(root,i)
        u=max(0,min(length,(point-a).dot(axis)))
        q=a+axis*u
        result.append(((Vector((point.x,point.y,0))-q).length,i,u,q,inside))
    return min(result,key=lambda x:x[0])


def wall_hit(context,event,root):
    origin,direction=_ray(context,event)
    inv=root.matrix_world.inverted_safe();origin=inv@origin;direction=inv.to_3x3()@direction
    candidates=[]
    for i in range(len(plan.outline(root))):
        wall=next((o for o in root.children if o.get('bs_arch_key')==f'wall_{i}'),None)
        if wall is None or wall.hide_get():continue
        a,axis,inside,length=plan.wall_basis(root,i)
        denom=direction.dot(inside)
        if abs(denom)<1e-7:continue
        t=(a-origin).dot(inside)/denom
        hit=origin+direction*t;u=(hit-a).dot(axis)
        if t>0 and 0<=u<=length and 0<=hit.z<=root.bs_room.height:
            candidates.append((t,i,u,hit))
    if candidates:
        _,i,u,hit=min(candidates)
        return i,u,hit
    hit=_floor_hit(context,event,root)
    if hit is None:return None
    distance,i,u,q,_=nearest_wall(root,hit)
    return (i,u,q) if distance<.8 else None


def _draw_lines(operator):
    if not getattr(operator,'lines',None):return
    import gpu
    from gpu_extras.batch import batch_for_shader
    shader=gpu.shader.from_builtin('UNIFORM_COLOR')
    batch=batch_for_shader(shader,'LINES',{'pos':operator.lines})
    gpu.state.depth_test_set('NONE');gpu.state.line_width_set(3)
    shader.bind();shader.uniform_float('color',(.15,.85,1,1));batch.draw(shader)
    gpu.state.line_width_set(1);gpu.state.depth_test_set('LESS_EQUAL')


class _Modal:
    def start(self,context):
        self.area=context.area;self.lines=[]
        self.handle=bpy.types.SpaceView3D.draw_handler_add(_draw_lines,(self,),'WINDOW','POST_VIEW')
        context.window_manager.modal_handler_add(self)
    def finish(self,context):
        bpy.types.SpaceView3D.draw_handler_remove(self.handle,'WINDOW')
        self.area.header_text_set(None);self.area.tag_redraw()
    def navigation(self,event):
        return event.type in {'MIDDLEMOUSE','WHEELUPMOUSE','WHEELDOWNMOUSE','TRACKPADPAN','TRACKPADZOOM','NDOF_MOTION'}


class BS_OT_draw_room(_Modal,bpy.types.Operator):
    bl_idname='blockstage.draw_room';bl_label='Draw Room';bl_options={'REGISTER','UNDO','BLOCKING'}
    bl_description='Click corners on the floor, Enter to close. Ctrl: free angles. Shift: disable grid. Esc: cancel'
    @classmethod
    def poll(cls,context):return context.area is not None and context.area.type=='VIEW_3D'
    def invoke(self,context,event):
        self.points=[];self.hover=None;self.start(context)
        self.area.header_text_set('DRAW ROOM | Click corners | Enter: close | Backspace: undo corner | Ctrl: free angles | Esc: cancel')
        return {'RUNNING_MODAL'}
    def modal(self,context,event):
        if self.navigation(event):return {'PASS_THROUGH'}
        if event.type in {'ESC','RIGHTMOUSE'}:
            self.finish(context);return {'CANCELLED'}
        if event.type=='BACK_SPACE' and event.value=='PRESS':
            if self.points:self.points.pop()
        hit=_floor_hit(context,event)
        if hit is not None:
            if not event.shift:
                grid=context.scene.bs_editor.grid
                hit.x=round(hit.x/grid)*grid;hit.y=round(hit.y/grid)*grid
            if self.points and not event.ctrl:
                last=self.points[-1]
                if abs(hit.x-last.x)>=abs(hit.y-last.y):hit.y=last.y
                else:hit.x=last.x
            self.hover=hit
        close=event.type in {'RET','NUMPAD_ENTER'} and event.value=='PRESS'
        if event.type=='LEFTMOUSE' and event.value=='PRESS' and self.hover is not None:
            if len(self.points)>=3 and (self.hover-self.points[0]).length<.15:close=True
            elif not self.points or (self.hover-self.points[-1]).length>=.1:self.points.append(self.hover.copy())
        if close:
            points=[(v.x-context.scene.cursor.location.x,v.y-context.scene.cursor.location.y) for v in self.points]
            if plan.signed_area(points)<0:points.reverse()
            error=plan.validate(points)
            if error:self.report({'WARNING'},error)
            else:
                r=plan.create(context,'CUSTOM',points=points)
                context.scene.bs_editor.room=r;core.select_root(context,r)
                self.finish(context);return {'FINISHED'}
        display=self.points+([self.hover] if self.hover is not None else [])
        self.lines=[p for a,b in zip(display,display[1:]) for p in (a,b)]
        if len(self.points)>=3:self.lines.extend((display[-1],display[0]))
        self.area.tag_redraw();return {'RUNNING_MODAL'}


class BS_OT_place_opening(_Modal,bpy.types.Operator):
    bl_idname='blockstage.place_opening';bl_label='Place Opening';bl_options={'REGISTER','UNDO','BLOCKING'}
    kind: EnumProperty(items=[('DOOR','Door',''),('WINDOW','Window',''),('PASSAGE','Passage','')])
    reposition: BoolProperty(default=False)
    @classmethod
    def poll(cls,context):return active_room(context) is not None and context.area is not None and context.area.type=='VIEW_3D'
    def invoke(self,context,event):
        self.root=active_room(context);self.hit=None;self.start(context)
        self.area.header_text_set('PLACE '+self.kind+' | Hover a wall and click | Esc: cancel | Works in top view too')
        return {'RUNNING_MODAL'}
    def modal(self,context,event):
        if self.navigation(event):return {'PASS_THROUGH'}
        if event.type in {'ESC','RIGHTMOUSE'}:self.finish(context);return {'CANCELLED'}
        self.hit=wall_hit(context,event,self.root)
        self.lines=[]
        if self.hit:
            wi,u,_=self.hit
            grid=context.scene.bs_editor.grid;u=round(u/grid)*grid
            a,axis,inside,length=plan.wall_basis(self.root,wi)
            width,height,bottom=(1.5,1.2,.9) if self.kind=='WINDOW' else (.95,2.15,0)
            if self.reposition and self.root.bs_plan.openings:
                op=self.root.bs_plan.openings[self.root.bs_plan.active_opening]
                width,height,bottom=op.width,op.height,op.sill if op.kind=='WINDOW' else 0
            u=max(width/2+.1,min(length-width/2-.1,u))
            corners=[self.root.matrix_world@(a+axis*x+Vector((0,0,z))) for x,z in
                ((u-width/2,bottom),(u+width/2,bottom),(u+width/2,bottom+height),(u-width/2,bottom+height))]
            self.lines=[v for x,y in zip(corners,corners[1:]+corners[:1]) for v in (x,y)]
            if event.type=='LEFTMOUSE' and event.value=='PRESS':
                if self.reposition and self.root.bs_plan.openings:
                    op=self.root.bs_plan.openings[self.root.bs_plan.active_opening]
                    with plan.batch(self.root):op.wall=wi+1;op.offset=u
                    plan.rebuild(self.root)
                else:plan.add_opening(self.root,self.kind,wi+1,u)
                self.root.bs_plan.active_point=wi
                core.select_root(context,self.root)
                self.finish(context);return {'FINISHED'}
        self.area.tag_redraw();return {'RUNNING_MODAL'}


def place_asset(context,obj,root,point,rotation=0,snap=True):
    kind=obj['bs_asset'];obj.location.x=point.x;obj.location.y=point.y
    if kind not in interiors.CEILING:obj.location.z=1.45 if kind in interiors.WALL else 0
    obj.rotation_euler.z=rotation
    if snap and kind not in interiors.CEILING:
        dist,i,u,q,inside=nearest_wall(root,point)
        if dist<.65:
            _,axis,_,length=plan.wall_basis(root,i)
            low,high=interiors.bounds(obj)
            u=max((high.x-low.x)/2+.04,min(length-(high.x-low.x)/2-.04,u))
            a=plan.wall_basis(root,i)[0]
            loc=a+axis*u+inside*(high.y*obj.scale.y+.025)
            obj.location.x=loc.x;obj.location.y=loc.y
            obj.rotation_euler.z=math.atan2(axis.y,axis.x)+math.pi


class BS_OT_place_furniture(_Modal,bpy.types.Operator):
    bl_idname='blockstage.place_furniture';bl_label='Place Furniture';bl_options={'REGISTER','UNDO','BLOCKING'}
    asset: StringProperty(default='sofa')
    interactive: BoolProperty(default=True)
    @classmethod
    def poll(cls,context):return active_room(context) is not None
    def execute(self,context):
        if self.asset not in {i[0] for i in CATALOG}:return {'CANCELLED'}
        root=active_room(context);obj=interiors.mount_asset(context,self.asset,root)
        point=root.matrix_world.inverted_safe()@context.scene.cursor.location
        place_asset(context,obj,root,point,snap=False)
        core.select_root(context,obj);return {'FINISHED'}
    def invoke(self,context,event):
        if not self.interactive or context.area.type!='VIEW_3D':return self.execute(context)
        if self.asset not in {i[0] for i in CATALOG}:return {'CANCELLED'}
        self.root=active_room(context);self.obj=interiors.mount_asset(context,self.asset,self.root)
        self.rotation=0;self.valid=False;core.select_root(context,self.obj);self.start(context)
        self.area.header_text_set('PLACE '+self.asset.replace('_',' ').upper()+' | Click: place | R: turn 90 degrees | Alt: no wall snap | Shift: no grid | Esc: cancel')
        return {'RUNNING_MODAL'}
    def modal(self,context,event):
        if self.navigation(event):return {'PASS_THROUGH'}
        if event.type in {'ESC','RIGHTMOUSE'}:
            plan.remove_tree(self.obj);core.select_root(context,self.root);self.finish(context);return {'CANCELLED'}
        if event.type=='R' and event.value=='PRESS':self.rotation+=math.pi/2
        hit=_floor_hit(context,event,self.root)
        if hit is not None:
            grid=context.scene.bs_editor.grid
            if not event.shift:hit.x=round(hit.x/grid)*grid;hit.y=round(hit.y/grid)*grid
            place_asset(context,self.obj,self.root,hit,self.rotation,context.scene.bs_editor.wall_snap and not event.alt)
            self.valid=True
        if event.type=='LEFTMOUSE' and event.value=='PRESS' and self.valid:
            self.finish(context);return {'FINISHED'}
        self.area.tag_redraw();return {'RUNNING_MODAL'}


class BS_OT_asset_action(bpy.types.Operator):
    bl_idname='blockstage.interior_action';bl_label='Edit Furnishing';bl_options={'REGISTER','UNDO'}
    action: EnumProperty(items=[('SELECT','Select entire furnishing',''),('ROTATE','Rotate 90 degrees',''),('DELETE','Delete furnishing','')])
    def execute(self,context):
        ob=core.asset_root(context.object)
        if not ob or ob.get('bs_kind')!='prop':return {'CANCELLED'}
        if self.action=='DELETE':
            r=active_room(context);plan.remove_tree(ob)
            if r:core.select_root(context,r)
        elif self.action=='ROTATE':ob.rotation_euler.z+=math.pi/2
        else:core.select_root(context,ob)
        return {'FINISHED'}


class BS_OT_interior_size(bpy.types.Operator):
    bl_idname='blockstage.interior_size';bl_label='Furniture Dimensions';bl_options={'REGISTER','UNDO'}
    width: FloatProperty(name='Width',default=1,min=.01,unit='LENGTH')
    depth: FloatProperty(name='Depth',default=1,min=.01,unit='LENGTH')
    height: FloatProperty(name='Height',default=1,min=.01,unit='LENGTH')
    def invoke(self,context,event):
        ob=core.asset_root(context.object)
        lo,hi=interiors.bounds(ob)
        self.width,self.depth,self.height=[(hi[i]-lo[i])*ob.scale[i] for i in range(3)]
        return context.window_manager.invoke_props_dialog(self)
    def execute(self,context):
        ob=core.asset_root(context.object)
        if not ob or ob.get('bs_kind')!='prop':return {'CANCELLED'}
        lo,hi=interiors.bounds(ob)
        ob.scale=[value/max(.001,hi[i]-lo[i]) for i,value in enumerate((self.width,self.depth,self.height))]
        return {'FINISHED'}


class BS_OT_layout(bpy.types.Operator):
    bl_idname='blockstage.interior_layout';bl_label='Add Furniture Layout';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        r=active_room(context)
        if not r:return {'CANCELLED'}
        p=plan.outline(r)
        if r.bs_plan.shape!='RECT' or r.bs_room.width<4.8 or r.bs_room.depth<4.8:
            self.report({'WARNING'},'Automatic layouts need a rectangular room at least 4.8 x 4.8 m. Place individual furniture in other plans.')
            return {'CANCELLED'}
        w,d=r.bs_room.width/2,r.bs_room.depth/2
        layouts={
          'LIVING':[('sofa',(0,d-.58,0),0),('rug',(0,d-1.7,0),0),('coffee_table',(0,d-1.65,0),0),
                    ('armchair',(-w+.70,d-1.9,0),-.35),('plant',(w-.4,d-.42,0),0),('chandelier',(0,d-1.4,0),0)],
          'BEDROOM':[('bed',(0,d-1.15,0),0),('cabinet',(-w+.6,d-1,0),0),('wardrobe',(w-.38,0,0),math.pi/2),('pendant',(0,0,0),0)],
          'OFFICE':[('desk',(0,d-.6,0),0),('dining_chair',(0,d-1.5,0),math.pi),('bookcase',(-w+.7,d-.35,0),0),('ceiling_light',(0,0,0),0)],
          'DINING':[('dining_table',(0,0,0),0),('dining_chair',(-.55,-.85,0),math.pi),('dining_chair',(.55,-.85,0),math.pi),
                    ('dining_chair',(-.55,.85,0),0),('dining_chair',(.55,.85,0),0),('pendant',(0,0,0),0)],
          'KITCHEN':[('fridge',(-1.5,d-.43,0),0),('sink_unit',(-.55,d-.36,0),0),('kitchen_counter',(.4,d-.36,0),0),
                    ('stove',(1.35,d-.36,0),0),('wall_cabinet',(.4,d-.2,1.5),0),('ceiling_light',(0,0,0),0)],
          'BATHROOM':[('bathtub',(0,d-.5,0),0),('toilet',(-w+.5,0,0),-math.pi/2),('sink_unit',(w-.4,0,0),math.pi/2),('ceiling_light',(0,0,0),0)],
        }
        for asset,location,angle in layouts[context.scene.bs_editor.layout]:
            ob=interiors.mount_asset(context,asset,r);ob.location.x,ob.location.y=location[:2]
            if asset not in interiors.CEILING:ob.location.z=location[2]
            ob.rotation_euler.z=angle
        core.select_root(context,r);return {'FINISHED'}


class BS_UL_walls(bpy.types.UIList):
    def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index):
        layout.prop(item,'enabled',text='')
        layout.label(text=item.name)


class BS_UL_openings(bpy.types.UIList):
    def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index):
        layout.prop(item,'enabled',text='')
        layout.prop(item,'name',text='',emboss=False,icon='MOD_BOOLEAN')
        layout.label(text='Wall '+str(item.wall))


class BS_PT_rooms(bpy.types.Panel):
    bl_label='ROOM BUILDER / 0.2'
    bl_idname='BS_PT_rooms';bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Blockstage';bl_order=-10
    def draw(self,context):
        l=self.layout;s=context.scene.bs_editor
        row=l.row(align=True)
        row.operator('blockstage.room_new',text='Rectangle',icon='MESH_PLANE').shape='RECT'
        row.operator('blockstage.room_new',text='L-shaped').shape='L'
        l.operator('blockstage.draw_room',text='Draw Room',icon='GREASEPENCIL')
        l.prop(s,'grid')
        row=l.row(align=True);row.prop(s,'room',text='Active Room')
        row.operator('blockstage.room_select',text='',icon='RESTRICT_SELECT_OFF')
        r=room_for(context)
        if not r:
            l.label(text='Create a room to start.',icon='INFO');return
        if not r.get('bs_plan_version'):
            l.operator('blockstage.room_upgrade',icon='FILE_REFRESH');return
        p=r.bs_plan;rs=r.bs_room
        l.prop(r,'name',text='Name')
        row=l.row(align=True)
        row.operator('blockstage.room_view',text='Overview',icon='VIEW_ORTHO').view='ISO'
        row.operator('blockstage.room_view',text='Floor Plan',icon='AXIS_TOP').view='TOP'
        l.prop(p,'view',expand=True)
        l.label(text='View modes also apply to renders.',icon='INFO')
        col=l.column(align=True)
        if p.shape!='CUSTOM':
            col.prop(rs,'width');col.prop(rs,'depth')
        col.prop(rs,'height')
        if p.shape=='L':col.prop(p,'notch_width');col.prop(p,'notch_depth')
        row=l.row(align=True);row.prop(rs,'ceiling');row.prop(rs,'trim',text='Trim')
        row=l.row(align=True);row.prop(rs,'wall_thickness',text='Walls');row.prop(rs,'floor_thickness',text='Floor')
        if p.error:
            box=l.box();box.alert=True;box.label(text='Invalid outline',icon='ERROR')
            box.label(text=p.error)


class BS_PT_walls(bpy.types.Panel):
    bl_label='Walls & Corners';bl_idname='BS_PT_walls';bl_parent_id='BS_PT_rooms'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Blockstage';bl_options={'DEFAULT_CLOSED'}
    @classmethod
    def poll(cls,context):return active_room(context) is not None
    def draw(self,context):
        l=self.layout;r=active_room(context);p=r.bs_plan
        l.template_list('BS_UL_walls','',p,'points',p,'active_point',rows=4)
        if p.shape!='CUSTOM':
            l.operator('blockstage.room_corner',text='Edit Outline',icon='EDITMODE_HLT').action='CUSTOM'
        elif p.points:
            item=p.points[min(p.active_point,len(p.points)-1)]
            row=l.row(align=True);row.prop(item,'x');row.prop(item,'y')
            row=l.row(align=True)
            row.operator('blockstage.room_corner',text='Split Wall',icon='ADD').action='INSERT'
            row.operator('blockstage.room_corner',text='Remove Corner',icon='REMOVE').action='REMOVE'
        l.label(text='Wall numbering follows the outline.')


class BS_PT_openings(bpy.types.Panel):
    bl_label='Doors & Windows';bl_idname='BS_PT_openings';bl_parent_id='BS_PT_rooms'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Blockstage'
    @classmethod
    def poll(cls,context):return active_room(context) is not None
    def draw(self,context):
        l=self.layout;r=active_room(context);p=r.bs_plan
        row=l.row(align=True)
        for kind in ('DOOR','WINDOW','PASSAGE'):
            row.operator('blockstage.place_opening',text=kind.title()).kind=kind
        l.label(text='Choose a tool, then click a wall.')
        l.template_list('BS_UL_openings','',p,'openings',p,'active_opening',rows=3)
        if 0<=p.active_opening<len(p.openings):
            op=p.openings[p.active_opening]
            row=l.row(align=True)
            row.operator('blockstage.opening_edit',text='',icon='RESTRICT_SELECT_OFF').action='SELECT'
            row.operator('blockstage.opening_edit',text='Duplicate',icon='DUPLICATE').action='DUPLICATE'
            row.operator('blockstage.opening_edit',text='',icon='TRASH').action='REMOVE'
            move=l.operator('blockstage.place_opening',text='Reposition on Wall',icon='ORIENTATION_LOCAL');move.reposition=True;move.kind=op.kind
            col=l.column(align=True);col.prop(op,'wall');col.prop(op,'offset')
            row=l.row(align=True);row.prop(op,'width');row.prop(op,'height')
            if op.kind=='DOOR':
                row=l.row(align=True);row.prop(op,'hinge');row.prop(op,'angle')
                l.label(text='Right-click Open Angle to add keys.',icon='KEY_HLT')
            if op.kind=='WINDOW':
                l.prop(op,'sill');row=l.row(align=True);row.prop(op,'columns');row.prop(op,'rows')
        if p.status:
            box=l.box();box.label(text='Opening fit notices',icon='INFO')
            for message in p.status.split('; '):
                # Short wrapped labels keep the narrow sidebar usable.
                import textwrap
                for line in textwrap.wrap(message,38):box.label(text=line)


class BS_PT_interiors(bpy.types.Panel):
    bl_label='Furniture & Lighting';bl_idname='BS_PT_interiors';bl_parent_id='BS_PT_rooms'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Blockstage'
    @classmethod
    def poll(cls,context):return active_room(context) is not None
    def draw(self,context):
        l=self.layout;s=context.scene.bs_editor
        l.prop(s,'category',text='');l.prop(s,'search',text='',icon='VIEWZOOM');l.prop(s,'wall_snap')
        from . import previews
        previews.draw_picker(l, context, 'interior')
        l.label(text='Click to place / R to turn / Esc to cancel')
        row=l.row(align=True);row.prop(s,'layout',text='');row.operator('blockstage.interior_layout',text='Add Layout',icon='OUTLINER_COLLECTION')
        obj=core.asset_root(context.object)
        if obj and obj.get('bs_kind')=='prop':
            box=l.box();box.prop(obj,'name',text='')
            row=box.row(align=True)
            row.operator('blockstage.interior_action',text='Select Root').action='SELECT'
            row.operator('blockstage.interior_action',text='Turn 90').action='ROTATE'
            row.operator('blockstage.interior_action',text='',icon='TRASH').action='DELETE'
            row=box.row(align=True)
            row.operator('blockstage.duplicate',text='Duplicate',icon='DUPLICATE')
            row.operator('blockstage.interior_size',text='Dimensions')
            box.prop(obj,'location',text='Position')
            box.prop(obj,'rotation_euler',index=2,text='Rotation')
            if 'ceiling_drop' in obj:box.prop(obj,'["ceiling_drop"]',text='Ceiling Drop')
            light=next((o for o in obj.children if o.type=='LIGHT'),None)
            if light:box.prop(light.data,'energy',text='Light Power')


_last_selected=None


@bpy.app.handlers.persistent
def selection_sync(scene,depsgraph=None):
    global _last_selected
    obj=bpy.context.object
    token=(obj.as_pointer() if obj else None,scene.as_pointer())
    if token==_last_selected:return
    _last_selected=token
    uid=None;wi=None;root=obj
    while root and root.get('bs_kind')!='room':
        if root.get('bs_opening_uid'):uid=root['bs_opening_uid']
        if 'bs_wall_index' in root:wi=root['bs_wall_index']
        root=root.parent
    if root is None or not root.get('bs_plan_version') or root.name not in scene.objects:return
    if hasattr(scene,'bs_editor'):scene.bs_editor.room=root
    if wi is not None:root.bs_plan.active_point=wi
    if uid:
        for i,op in enumerate(root.bs_plan.openings):
            if op.uid==uid:root.bs_plan.active_opening=i;break


classes=(BS_Editor,BS_OT_room_new,BS_OT_room_upgrade,BS_OT_room_select,BS_OT_room_view,
 BS_OT_corner,BS_OT_opening,BS_OT_draw_room,BS_OT_place_opening,BS_OT_place_furniture,
 BS_OT_asset_action,BS_OT_interior_size,BS_OT_layout,BS_UL_walls,BS_UL_openings,
 BS_PT_rooms,BS_PT_walls,BS_PT_openings,BS_PT_interiors)


def register():
    for cls in classes:bpy.utils.register_class(cls)
    bpy.types.Scene.bs_editor=PointerProperty(type=BS_Editor)
    if selection_sync not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(selection_sync)


def unregister():
    if selection_sync in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(selection_sync)
    del bpy.types.Scene.bs_editor
    for cls in reversed(classes):bpy.utils.unregister_class(cls)
