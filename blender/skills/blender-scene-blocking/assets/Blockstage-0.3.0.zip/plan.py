"""Blockstage 0.2: editable room documents, persistent parts, multiple openings.

Original implementation. No Home Builder code or assets are bundled.
All plan coordinates are local meters; walls follow a counter-clockwise outline.
"""
import math
import uuid
from contextlib import contextmanager

import bpy
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty,
                       FloatProperty, IntProperty, PointerProperty, StringProperty)
from mathutils import Vector
from mathutils.geometry import tessellate_polygon

from . import core, room

_busy = set()


@contextmanager
def batch(root):
    key = root.as_pointer()
    already = key in _busy
    _busy.add(key)
    try:
        yield
    finally:
        if not already:
            _busy.discard(key)


def changed(self, context):
    root = self.id_data
    if isinstance(root, bpy.types.Object) and root.get('bs_plan_version'):
        rebuild(root)


class BS_PlanPoint(bpy.types.PropertyGroup):
    name: StringProperty(default='Wall')
    x: FloatProperty(name='X', unit='LENGTH', update=changed)
    y: FloatProperty(name='Y', unit='LENGTH', update=changed)
    enabled: BoolProperty(name='Wall', default=True, update=changed)


class BS_Opening(bpy.types.PropertyGroup):
    uid: StringProperty()
    name: StringProperty(default='Door')
    kind: EnumProperty(name='Type', items=[('DOOR','Door','Hinged door'),
        ('WINDOW','Window','Open frame without a glass shader'),
        ('PASSAGE','Passage','Unfilled wall opening')], update=changed)
    wall: IntProperty(name='Wall number', min=1, default=1, update=changed)
    offset: FloatProperty(name='From wall start', default=1.5, min=0,
        unit='LENGTH', description='Center distance measured along the wall', update=changed)
    width: FloatProperty(name='Width', default=.95, min=.25, max=20, unit='LENGTH', update=changed)
    height: FloatProperty(name='Height', default=2.15, min=.25, max=12, unit='LENGTH', update=changed)
    sill: FloatProperty(name='Sill height', default=.9, min=0, max=12, unit='LENGTH', update=changed)
    angle: FloatProperty(name='Open angle', default=0, min=-math.pi, max=math.pi,
        subtype='ANGLE', description='Keyframe this to animate the door')
    hinge: EnumProperty(name='Hinge', items=[('LEFT','Left','Hinge at start of wall'),
        ('RIGHT','Right','Hinge at end of wall')], update=changed)
    columns: IntProperty(name='Window columns', default=2, min=1, max=8, update=changed)
    rows: IntProperty(name='Window rows', default=1, min=1, max=6, update=changed)
    enabled: BoolProperty(name='Enabled', default=True, update=changed)


class BS_Plan(bpy.types.PropertyGroup):
    shape: EnumProperty(name='Plan', items=[('RECT','Rectangle','Width and depth'),
        ('L','L-shaped','Width and depth with a corner removed'),
        ('CUSTOM','Custom outline','Edit corners or draw a floor plan')], update=changed)
    notch_width: FloatProperty(name='Notch width', default=2, min=.3, unit='LENGTH', update=changed)
    notch_depth: FloatProperty(name='Notch depth', default=2, min=.3, unit='LENGTH', update=changed)
    points: CollectionProperty(type=BS_PlanPoint)
    active_point: IntProperty(default=0)
    openings: CollectionProperty(type=BS_Opening)
    active_opening: IntProperty(default=0)
    view: EnumProperty(name='View', items=[('CUT','Cutaway','Hide front and right walls and ceiling in viewport and render'),
        ('FULL','Complete','Show all enabled walls and ceiling'),
        ('TOP','Open top','Show walls, hide ceiling')], default='CUT', update=changed)
    error: StringProperty()
    status: StringProperty()


def outline(root):
    p, s = root.bs_plan, root.bs_room
    if p.shape == 'CUSTOM':
        return [(v.x, v.y) for v in p.points]
    w, d = s.width / 2, s.depth / 2
    if p.shape == 'L':
        nw, nd = min(p.notch_width, s.width - .5), min(p.notch_depth, s.depth - .5)
        return [(-w,-d), (w,-d), (w,d-nd), (w-nw,d-nd), (w-nw,d), (-w,d)]
    return [(-w,-d), (w,-d), (w,d), (-w,d)]


def signed_area(points):
    return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(points, points[1:]+points[:1])) / 2


def validate(points):
    if len(points) < 3:
        return 'A room needs at least 3 corners.'
    if len(points) > 64:
        return 'Use at most 64 corners per room.'
    def cross(a,b,c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    def on(a,b,c):
        return (abs(cross(a,b,c)) < 1e-7 and min(a[0],b[0])-1e-7 <= c[0] <= max(a[0],b[0])+1e-7
                and min(a[1],b[1])-1e-7 <= c[1] <= max(a[1],b[1])+1e-7)
    edges = list(zip(points,points[1:]+points[:1]))
    for i,(a,b) in enumerate(edges):
        if math.dist(a,b) < .1:
            return 'Each wall must be at least 0.10 m long.'
        for j,(c,d) in enumerate(edges):
            if j <= i or (j-i) in (1,len(edges)-1):
                continue
            if (cross(a,b,c)*cross(a,b,d) < 0 and cross(c,d,a)*cross(c,d,b) < 0) or any((on(a,b,c),on(a,b,d),on(c,d,a),on(c,d,b))):
                return 'Outline crosses itself. Move a corner; the last valid room is kept.'
    if signed_area(points) < .1:
        return 'Corners must run counter-clockwise and enclose at least 0.10 square meters.'
    return ''


def wall_basis(root, index):
    pts = outline(root)
    a, b = Vector((*pts[index],0)), Vector((*pts[(index+1)%len(pts)],0))
    direction = (b-a).normalized()
    return a, direction, Vector((-direction.y,direction.x,0)), (b-a).length


def fit_openings(root):
    """Fit to the wall and avoid overlap; warn rather than silently lose apertures."""
    count = len(outline(root))
    result = {i: [] for i in range(count)}
    warnings = []
    for op in root.bs_plan.openings:
        if not op.enabled:
            continue
        wi = op.wall-1
        if wi not in result:
            warnings.append(op.name + ': choose an existing wall')
            continue
        length = wall_basis(root,wi)[3]
        margin = .10
        width = min(op.width,length-2*margin)
        bottom = min(op.sill,root.bs_room.height-.35) if op.kind == 'WINDOW' else 0
        top = min(bottom+op.height,root.bs_room.height-.10)
        center = max(margin+width/2,min(length-margin-width/2,op.offset))
        spans = [(margin,length-margin)]
        for existing in result[wi]:
            x0,x1,z0,z1,_ = existing
            if bottom >= z1+margin or top <= z0-margin:
                continue
            updated = []
            for l,r in spans:
                if x1+margin <= l or x0-margin >= r:
                    updated.append((l,r))
                else:
                    if x0-margin > l: updated.append((l,min(r,x0-margin)))
                    if x1+margin < r: updated.append((max(l,x1+margin),r))
            spans = updated
        fits = [(l,r) for l,r in spans if r-l >= width-1e-6]
        if not fits or width < .25:
            warnings.append(op.name + ': no space on wall ' + str(op.wall))
            continue
        l,r = min(fits,key=lambda sp: abs(max(sp[0]+width/2,min(sp[1]-width/2,center))-center))
        actual = max(l+width/2,min(r-width/2,center))
        if abs(actual-op.offset)>.001 or width < op.width-.001 or top-bottom < op.height-.001:
            warnings.append(op.name + ': fitted to available wall space')
        result[wi].append((actual-width/2,actual+width/2,bottom,top,op))
    return result, warnings


def _mesh(root, key, vertices, faces, role, previous, parent=None):
    obj = previous.pop(key,None)
    mesh = bpy.data.meshes.new('BS / '+key)
    mesh.from_pydata(vertices,[],faces)
    mesh.update()
    mesh.materials.append(core.material(role))
    if obj is None:
        obj = bpy.data.objects.new(key.replace('_',' ').title(),mesh)
        root.users_collection[0].objects.link(obj)
        obj['bs_arch_key'] = key
    else:
        old = obj.data
        obj.data = mesh
        if old and old.users == 0: bpy.data.meshes.remove(old)
    obj.parent = parent or root
    obj.location = (0,0,0)
    obj.rotation_euler = (0,0,0)
    obj.scale = (1,1,1)
    obj.color = core.material(role).diffuse_color
    from . import appearance
    appearance.restore_arch_part(root, obj, key)
    return obj


def _empty(root,key,previous,parent=None):
    obj = previous.pop(key,None)
    if obj is None:
        obj = bpy.data.objects.new(key.replace('_',' ').title(),None)
        root.users_collection[0].objects.link(obj)
        obj['bs_arch_key'] = key
        obj.empty_display_size=.12
    obj.parent=parent or root
    return obj


def remove_tree(root):
    for obj in reversed(core.descendants(root)):
        data = obj.data
        bpy.data.objects.remove(obj,do_unlink=True)
        if isinstance(data,bpy.types.Mesh) and data.users == 0:
            bpy.data.meshes.remove(data)


def _slab(points, z, thick):
    n=len(points)
    vs=[(x,y,level) for level in (z,z+thick) for x,y in points]
    vectors=[Vector((x,y,0)) for x,y in points]
    ids={tuple(v):i for i,v in enumerate(vectors)}
    triangles=[[(v if isinstance(v,int) else ids[tuple(v)]) for v in tri] for tri in tessellate_polygon([vectors])]
    fs=[tuple(reversed(t)) for t in triangles]+[tuple(i+n for i in t) for t in triangles]
    fs += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    return vs,fs


def _box(vs,fs,a,b,c,d,thickness,y=None):
    room._append_box(vs,fs,((a+b)/2, -thickness/2 if y is None else y,(c+d)/2),
                     (b-a,thickness,d-c))


def _visibility(obj, hidden):
    obj.hide_render=hidden
    obj.hide_set(hidden)


def rebuild(root):
    if not root or root.as_pointer() in _busy:
        return
    with batch(root):
        s,p=root.bs_room,root.bs_plan
        root['bs_ceiling_height']=s.height
        pts=outline(root)
        error=validate(pts)
        p.error=error
        if error: return
        while len(p.points)<len(pts):
            p.points.add()
        # Preset wall toggles remain stable on dimension edits.
        if p.shape != 'CUSTOM':
            while len(p.points)>len(pts): p.points.remove(len(p.points)-1)
            for item,xy in zip(p.points,pts): item.x,item.y=xy
        for i,v in enumerate(p.points): v.name=f'Wall {i+1:02d} / {math.dist(pts[i],pts[(i+1)%len(pts)]):.2f} m'
        previous={o['bs_arch_key']:o for o in core.descendants(root)[1:] if o.get('bs_arch_key')}
        floor=_mesh(root,'floor',*_slab(pts,-s.floor_thickness,s.floor_thickness),'wood',previous)
        _visibility(floor,False)
        if s.ceiling:
            ob=_mesh(root,'ceiling',*_slab(pts,s.height,s.floor_thickness),'light',previous)
            _visibility(ob,p.view!='FULL')
        holes,warnings=fit_openings(root)
        p.status='; '.join(warnings)
        for wi in range(len(pts)):
            a,axis,inside,length=wall_basis(root,wi)
            hide=(not p.points[wi].enabled) or (p.view=='CUT' and -inside.dot(Vector((.8,-1,0)))>.05)
            theta=math.atan2(axis.y,axis.x)
            vs,fs=[],[]
            cuts=holes[wi]
            xs=sorted({0,length,*(x for cut in cuts for x in cut[:2])})
            zs=sorted({0,s.height,*(z for cut in cuts for z in cut[2:4])})
            for l,r in zip(xs,xs[1:]):
                for b,t in zip(zs,zs[1:]):
                    if any(h[0]<(l+r)/2<h[1] and h[2]<=(b+t)/2<h[3] for h in cuts): continue
                    _box(vs,fs,l,r,b,t,s.wall_thickness)
            wall=_mesh(root,f'wall_{wi}',vs,fs,'light',previous)
            wall.location=a; wall.rotation_euler.z=theta; wall['bs_wall_index']=wi
            _visibility(wall,hide)
            if s.trim:
                vs,fs=[],[]
                for l,r in zip(xs,xs[1:]):
                    if not any(h[2]<.09 and h[0]<(l+r)/2<h[1] for h in cuts):
                        _box(vs,fs,l,r,0,.085,.035,y=.017)
                _box(vs,fs,0,length,s.height-.07,s.height,.035,y=.017)
                obj=_mesh(root,f'trim_{wi}',vs,fs,'dark',previous,parent=wall)
                _visibility(obj,hide)
            for l,r,b,t,op in cuts:
                key='opening_'+op.uid
                mount=_empty(root,key,previous)
                mount.location=a+axis*l
                mount.rotation_euler=(0,0,theta)
                mount['bs_opening_uid']=op.uid
                mount.name=op.name
                _visibility(mount,hide)
                width=r-l; edge=.055
                vs,fs=[],[]
                for x0,x1,z0,z1 in [(-edge,0,b,t+edge),(width,width+edge,b,t+edge),(0,width,t,t+edge)]:
                    _box(vs,fs,x0,x1,z0,z1,s.wall_thickness+.045,y=-s.wall_thickness/2)
                if op.kind=='WINDOW':
                    _box(vs,fs,-edge,width+edge,b-edge,b,s.wall_thickness+.16,y=-s.wall_thickness/2+.045)
                    for col in range(1,op.columns):
                        x=width*col/op.columns
                        _box(vs,fs,x-.018,x+.018,b,t,.055,y=-s.wall_thickness/2)
                    for row in range(1,op.rows):
                        z=b+(t-b)*row/op.rows
                        _box(vs,fs,0,width,z-.018,z+.018,.055,y=-s.wall_thickness/2)
                frame=_mesh(root,key+'_frame',vs,fs,'dark',previous,parent=mount)
                _visibility(frame,hide)
                if op.kind=='DOOR':
                    hinge=_empty(root,key+'_hinge',previous,parent=mount)
                    hinge.location=(width if op.hinge=='RIGHT' else 0,-s.wall_thickness/2,0)
                    hinge.rotation_mode='XYZ'
                    hinge.rotation_euler.x=hinge.rotation_euler.y=0
                    hinge.driver_remove('rotation_euler',2)
                    fc=hinge.driver_add('rotation_euler',2)
                    var=fc.driver.variables.new(); var.name='angle'; var.type='SINGLE_PROP'
                    var.targets[0].id=root
                    index=list(p.openings).index(op)
                    var.targets[0].data_path=f'bs_plan.openings[{index}].angle'
                    fc.driver.expression='-angle' if op.hinge=='RIGHT' else 'angle'
                    sign=-1 if op.hinge=='RIGHT' else 1
                    vs,fs=[],[]
                    room._append_box(vs,fs,(sign*width/2,0,(t+b)/2),(width-.014,.045,t-b-.014))
                    leaf=_mesh(root,key+'_leaf',vs,fs,'primary',previous,parent=hinge)
                    vs,fs=[],[]
                    room._append_box(vs,fs,(sign*(width-.12),.055,min(1,t*.47)),(.12,.10,.025))
                    handle=_mesh(root,key+'_handle',vs,fs,'metal',previous,parent=hinge)
                    for obj in (hinge,leaf,handle): _visibility(obj,hide)
        # Fill the outside miters where two convex wall strips meet. Without
        # these wedges a closed room has pinholes at its exterior corners.
        for i,point in enumerate(pts):
            prev=(i-1)%len(pts)
            _,a,na,_=wall_basis(root,prev)
            _,b,nb,_=wall_basis(root,i)
            turn=a.x*b.y-a.y*b.x
            if turn<=1e-6:continue
            v=Vector((*point,0));n0,n1=-na,-nb
            offset=(n0+n1)*s.wall_thickness/max(.25,1+n0.dot(n1))
            corner=[tuple(q[:2]) for q in (v,v+n0*s.wall_thickness,v+offset,v+n1*s.wall_thickness)]
            if signed_area(corner)<0:corner.reverse()
            obj=_mesh(root,f'corner_{i}',*_slab(corner,0,s.height),'light',previous)
            hidden=not(p.points[prev].enabled and p.points[i].enabled)
            if p.view=='CUT':hidden=hidden or any(-n.dot(Vector((.8,-1,0)))>.05 for n in (na,nb))
            _visibility(obj,hidden)
        # Remove only parts owned by this room generator; retain attached user work.
        for obj in list(previous.values()):
            for child in list(obj.children):
                if child.get('bs_arch_key') not in previous:
                    world=child.matrix_world.copy(); child.parent=root; child.matrix_world=world
            data=obj.data
            bpy.data.objects.remove(obj,do_unlink=True)
            if isinstance(data,bpy.types.Mesh) and data.users==0: bpy.data.meshes.remove(data)


def create(context,shape='RECT',points=None,width=6,depth=5):
    collection=core.asset_collection(context,'Rooms / New Room')
    root=bpy.data.objects.new('Room',None); collection.objects.link(root)
    root.empty_display_type='PLAIN_AXES'; root.empty_display_size=.3
    root['bs_root']=True; root['bs_kind']='room'; root['bs_asset']='room'; root['bs_plan_version']=2
    with batch(root):
        root.bs_room.width=width; root.bs_room.depth=depth; root.bs_room.ceiling=True
        root.bs_plan.shape=shape
        if points:
            pts=list(points)
            if signed_area(pts)<0: pts.reverse()
            for x,y in pts:
                pt=root.bs_plan.points.add(); pt.x=x;pt.y=y
    root.location=context.scene.cursor.location
    core.identify(root,context.scene)
    rebuild(root)
    return root


def add_opening(root,kind='DOOR',wall=1,offset=1.5):
    with batch(root):
        op=root.bs_plan.openings.add()
        op.uid=uuid.uuid4().hex[:12]; op.kind=kind
        op.name=f'{kind.title()} {len(root.bs_plan.openings):02d}'
        op.wall=wall;op.offset=offset
        if kind=='WINDOW': op.width=1.5;op.height=1.2
        root.bs_plan.active_opening=len(root.bs_plan.openings)-1
    rebuild(root)
    return op


def upgrade(root):
    """Explicit migration. Old aperture settings stay readable; props stay put."""
    s=root.bs_room
    old_door=(s.door_wall,s.door_width,s.door_height,s.door_offset)
    old_window=(s.window_wall,s.window_width,s.window_height,s.window_offset,s.window_sill)
    for ob in list(root.children):
        if ob.get('bs_room_part'):
            for child in list(ob.children):
                world=child.matrix_world.copy();child.parent=root;child.matrix_world=world
            remove_tree(ob)
    root['bs_plan_version']=2
    with batch(root):
        root.bs_plan.shape='RECT'
        for old,kind in ((old_door,'DOOR'),(old_window,'WINDOW')):
            wall=old[0]
            if wall=='NONE': continue
            wi={'FRONT':0,'RIGHT':1,'BACK':2,'LEFT':3}[wall]
            length=s.width if wi in (0,2) else s.depth
            offset=length/2+old[3]*(1 if wi in (0,1) else -1)
            op=add_opening(root,kind,wi+1,offset)
            op.width=old[1];op.height=old[2]
            if kind=='WINDOW':op.sill=old[4]
    rebuild(root)
    for i,side in enumerate(('front','right','back','left')):
        root.bs_plan.points[i].enabled=getattr(s,side)


classes=(BS_PlanPoint,BS_Opening,BS_Plan)


def register():
    for cls in classes:bpy.utils.register_class(cls)
    bpy.types.Object.bs_plan=PointerProperty(type=BS_Plan)


def unregister():
    del bpy.types.Object.bs_plan
    for cls in reversed(classes):bpy.utils.unregister_class(cls)
    _busy.clear()
