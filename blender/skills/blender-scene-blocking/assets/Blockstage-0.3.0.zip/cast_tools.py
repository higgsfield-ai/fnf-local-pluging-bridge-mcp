"""Integrated controls for the four supplied Cast rigs, inside Blockstage."""
import bpy
from bpy.props import EnumProperty, FloatProperty, StringProperty
from . import core, characters, cast_rig


def active_actor(context):
    obj = context.object
    while obj:
        if characters.is_cast(obj): return obj
        obj = obj.parent
    return None


def select_actor(context, actor, pose=True):
    core.select_root(context, actor)
    if pose: bpy.ops.object.mode_set(mode='POSE')


class BS_OT_cast_control(bpy.types.Operator):
    bl_idname = 'blockstage.cast_control'
    bl_label = 'Select Actor Control'
    bl_description = 'Select the matching control and activate its move or rotate gizmo'
    bl_options = {'UNDO'}
    control: StringProperty()
    @classmethod
    def poll(cls, context): return active_actor(context) is not None
    def execute(self, context):
        actor = active_actor(context); select_actor(context, actor)
        name = cast_rig.control_name(actor, self.control)
        bone = actor.data.bones.get(name)
        if not bone:
            self.report({'ERROR'}, 'Control unavailable: ' + name); return {'CANCELLED'}
        bpy.ops.pose.select_all(action='DESELECT')
        cast_rig.reveal_control(actor, name)
        actor.data.bones.active = bone
        pb = actor.pose.bones[name]
        if hasattr(pb, 'select'): pb.select = True
        else: bone.select = True
        if context.area and context.area.type == 'VIEW_3D':
            tool = cast_rig.control_tool(actor, name)
            bpy.ops.wm.tool_set_by_id(name='builtin.move' if tool == 'MOVE' else 'builtin.rotate')
        return {'FINISHED'}


class BS_OT_cast_grip(bpy.types.Operator):
    bl_idname = 'blockstage.cast_grip'; bl_label = 'Set Actor Hand Grip'
    bl_description = 'Curl the selected hand; every finger remains independently editable'
    bl_options = {'REGISTER', 'UNDO'}
    side: EnumProperty(items=[('L', 'Left', ''), ('R', 'Right', ''), ('BOTH', 'Both', '')])
    amount: FloatProperty(default=0, min=0, max=1)
    @classmethod
    def poll(cls, context): return active_actor(context) is not None
    def execute(self, context):
        characters.set_hand_grip(active_actor(context), self.amount, self.side)
        return {'FINISHED'}


class BS_OT_cast_mode(bpy.types.Operator):
    bl_idname = 'blockstage.cast_mode'; bl_label = 'Match and Switch IK/FK'
    bl_description = 'Match the target controls to the current pose, then switch; an unsupported twist leaves the pose unchanged'
    bl_options = {'REGISTER', 'UNDO'}
    limb: EnumProperty(items=[('arm', 'Arm', ''), ('leg', 'Leg', '')])
    side: EnumProperty(items=[('L', 'Left', ''), ('R', 'Right', '')])
    mode: EnumProperty(items=[('IK', 'IK', 'Move hands or feet'), ('FK', 'FK', 'Rotate each joint')])
    @classmethod
    def poll(cls, context): return active_actor(context) is not None
    def execute(self, context):
        try: cast_rig.set_ik_fk(active_actor(context), self.limb, self.side, 0 if self.mode == 'IK' else 1, snap=True)
        except (ValueError, RuntimeError) as error:
            self.report({'WARNING'}, str(error)); return {'CANCELLED'}
        return {'FINISHED'}


class BS_OT_cast_frame(bpy.types.Operator):
    bl_idname = 'blockstage.cast_frame'; bl_label = 'Frame Actor'
    bl_description = 'Bring the selected actor into view'
    @classmethod
    def poll(cls, context): return active_actor(context) is not None and context.area and context.area.type == 'VIEW_3D'
    def execute(self, context):
        actor = active_actor(context); select_actor(context, actor, pose=False)
        for obj in actor.children_recursive:
            if obj.get('mm_body'): obj.select_set(True)
        region = next(r for r in context.area.regions if r.type == 'WINDOW')
        with context.temp_override(region=region): bpy.ops.view3d.view_selected(use_all_regions=False)
        select_actor(context, actor)
        return {'FINISHED'}


def draw_controls(layout, context, actor):
    row = layout.row(align=True)
    row.operator('blockstage.pose_mode', text='Pose Controls', icon='POSE_HLT')
    row.operator('blockstage.cast_frame', text='', icon='VIEWZOOM')
    for pairs in (
        [('Move All', 'CTRL_root'), ('Hips', 'CTRL_pelvis')],
        [('Chest', 'CTRL_chest'), ('Head', 'CTRL_head')],
        [('Shoulder L', 'CTRL_clavicle.L'), ('Shoulder R', 'CTRL_clavicle.R')]):
        row = layout.row(align=True)
        for label, name in pairs: row.operator('blockstage.cast_control', text=label).control = name
    for part, label in [('hand', 'Hand'), ('foot', 'Foot'), ('elbow', 'Elbow'), ('knee', 'Knee')]:
        row = layout.row(align=True)
        for side in ('L', 'R'): row.operator('blockstage.cast_control', text=label + ' ' + side).control = 'CTRL_' + part + '.' + side
    box = layout.box(); box.label(text='Hand Grip', icon='VIEW_PAN')
    for side, label in [('L', 'Left'), ('R', 'Right')]:
        row = box.row(align=True); row.label(text=label)
        for title, amount in [('Open', 0), ('Hold', .5), ('Fist', 1)]:
            op = row.operator('blockstage.cast_grip', text=title); op.side = side; op.amount = amount
    row = layout.row(align=True)
    row.prop(context.scene.bs_settings, 'pose', text='')
    row.operator('blockstage.apply_pose', text='', icon='CHECKMARK')
    layout.operator('blockstage.key_pose', icon='KEY_HLT')


class BS_PT_rig_details(bpy.types.Panel):
    bl_label = 'Rig Details'; bl_idname = 'BS_PT_rig_details'; bl_parent_id = 'BS_PT_selected'
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = 'Blockstage'
    bl_options = {'DEFAULT_CLOSED'}
    @classmethod
    def poll(cls, context): return characters.is_cast(core.asset_root(context.object))
    def draw(self, context):
        layout = self.layout; actor = active_actor(context)
        for col in actor.data.collections:
            if 'deform' not in col.name.lower() and 'mechan' not in col.name.lower():
                layout.prop(col, 'is_visible', text=col.name)
        layout.separator()
        for limb in ('arm', 'leg'):
            for side in ('L', 'R'):
                row = layout.row(align=True); row.label(text=limb.title() + ' ' + side)
                blend = cast_rig.get_ik_fk(actor, limb, side)
                for mode in ('IK', 'FK'):
                    op = row.operator('blockstage.cast_mode', text='Snap to ' + mode, depress=blend < .5 if mode == 'IK' else blend >= .5)
                    op.limb = limb; op.side = side; op.mode = mode
        for side in ('L', 'R'):
            hand = actor.pose.bones['CTRL_hand.' + side]
            foot = actor.pose.bones['CTRL_foot.' + side]
            box = layout.box(); box.label(text=('Left' if side == 'L' else 'Right') + ' Hand / Foot')
            for key in ('curl', 'spread'): box.prop(hand, '["' + key + '"]', text=key.title(), slider=True)
            for key in ('roll_degrees', 'bank_degrees'):
                box.prop(foot, '["' + key + '"]', text=key.replace('_degrees', '').title())
        layout.label(text='Enable Fingers to edit each phalanx.')


classes = (BS_OT_cast_control, BS_OT_cast_grip, BS_OT_cast_mode, BS_OT_cast_frame, BS_PT_rig_details)


def register():
    for cls in classes: bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
