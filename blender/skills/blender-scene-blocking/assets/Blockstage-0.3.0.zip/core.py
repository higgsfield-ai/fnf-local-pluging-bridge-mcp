"""Shared geometry, identity and non-destructive asset operations. Units: meters."""
import colorsys
import math
import uuid

import bpy
from mathutils import Matrix

PALETTE = (
    ("Coral", "E95851"), ("Lagoon", "37B7BA"), ("Saffron", "E8B34F"),
    ("Iris", "9386DC"), ("Leaf", "79B880"), ("Rose", "D978A5"),
    ("Sky", "638FDB"), ("Terracotta", "C97D52"),
)


def linear_color(hex_value):
    values = [int(hex_value[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return tuple(v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in values) + (1,)


def palette_color(index):
    if index < len(PALETTE):
        return linear_color(PALETTE[index][1])
    # Beyond the base swatches, avoid repeating exactly the same ID color.
    rgb = colorsys.hsv_to_rgb((index * .61803398875) % 1, .56, .84)
    return tuple(v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in rgb) + (1,)


def material(role, color_index=0):
    """Primary/secondary use per-object color in both render engines."""
    name = 'BS / ' + role.title()
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat['bs_role'] = role
    shader = mat.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Roughness'].default_value = .72
    fixed = {'dark': '263039', 'light': 'DCD8CB', 'wood': '96775D',
             'glass': '456773', 'metal': '63707B'}
    mat.diffuse_color = linear_color(fixed.get(role, PALETTE[color_index % len(PALETTE)][1]))
    shader.inputs['Base Color'].default_value = mat.diffuse_color
    if role in {'primary', 'secondary'}:
        info = mat.node_tree.nodes.new('ShaderNodeObjectInfo')
        if role == 'secondary':
            multiply = mat.node_tree.nodes.new('ShaderNodeMixRGB')
            multiply.blend_type = 'MULTIPLY'
            multiply.inputs[0].default_value = 1
            multiply.inputs[2].default_value = (.52, .52, .52, 1)
            mat.node_tree.links.new(info.outputs['Color'], multiply.inputs[1])
            mat.node_tree.links.new(multiply.outputs[0], shader.inputs['Base Color'])
        else:
            mat.node_tree.links.new(info.outputs['Color'], shader.inputs['Base Color'])
    if role == 'metal':
        shader.inputs['Metallic'].default_value = .3
    return mat


def attach(obj, parent):
    obj.parent = parent
    obj.matrix_parent_inverse = Matrix.Identity(4)
    return obj


def mesh_object(name, verts, faces, mat, collection, parent=None):
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    if mat:
        obj.data.materials.append(mat)
    if parent:
        attach(obj, parent)
    return obj


def box(name, location, dimensions, mat, collection, parent=None, bevel=.02):
    x, y, z = (max(abs(d), .0001) / 2 for d in dimensions)
    verts = [(-x,-y,-z), (x,-y,-z), (x,y,-z), (-x,y,-z),
             (-x,-y,z), (x,-y,z), (x,y,z), (-x,y,z)]
    faces = [(3,2,1,0), (0,1,5,4), (1,2,6,5), (2,3,7,6), (3,0,4,7), (4,5,6,7)]
    obj = mesh_object(name, verts, faces, mat, collection, parent)
    obj.location = location
    if bevel:
        mod = obj.modifiers.new('Soft silhouette', 'BEVEL')
        mod.width = min(bevel, min(dimensions) / 3)
        mod.segments = 1
    return obj


def cylinder(name, location, radius, depth, mat, collection, parent=None, vertices=12, rotation=None):
    verts = [(radius * math.cos(2*math.pi*i/vertices), radius * math.sin(2*math.pi*i/vertices), z)
             for z in (-depth/2, depth/2) for i in range(vertices)]
    faces = [tuple(reversed(range(vertices))), tuple(range(vertices,2*vertices))]
    faces += [(i,(i+1)%vertices,(i+1)%vertices+vertices,i+vertices) for i in range(vertices)]
    obj = mesh_object(name, verts, faces, mat, collection, parent)
    obj.location = location
    if rotation is not None:
        obj.rotation_euler = rotation
    return obj


def descendants(root):
    result = [root]
    for obj in result:
        result.extend(list(obj.children))
    return result


def asset_root(obj):
    seen = set()
    while obj and obj.as_pointer() not in seen:
        if obj.get('bs_root'):
            return obj
        seen.add(obj.as_pointer())
        obj = obj.parent
    return None


def asset_collection(context, label):
    parent = next((c for c in context.scene.collection.children
                   if c.get('bs_library_root') or c.name == 'BLOCKSTAGE'
                   or c.name.startswith('BLOCKSTAGE.')), None)
    if parent is None:
        parent = bpy.data.collections.new('BLOCKSTAGE')
        context.scene.collection.children.link(parent)
    parent['bs_library_root'] = True
    col = bpy.data.collections.new(label)
    parent.children.link(col)
    return col


def recolor(root, index=None):
    if index is not None:
        root['bs_color_index'] = index
    color = palette_color(int(root.get('bs_color_index', 0)))
    objects = [root]
    for obj in objects:
        objects.extend(child for child in obj.children if not child.get('bs_root'))
        obj.color = color
    if root.get('bs_cast_variant'):
        from . import appearance
        appearance.write_color(root, 'asset', color)


def identify(root, scene, new=True):
    if new or not root.get('bs_uid'):
        index = int(scene.get('bs_next_identity', 0))
        scene['bs_next_identity'] = index + 1
        root['bs_uid'] = uuid.uuid4().hex
        root['bs_identity'] = index + 1
        root['bs_color_index'] = index
        label = 'Character' if root.get('bs_kind') == 'character' else root.get('bs_asset', 'Asset').replace('_', ' ').title()
        label = root.get('bs_cast_label', label)
        root.name = f'{label} {index + 1:02d}'
    recolor(root)


def select_root(context, root):
    if context.object and context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for obj in context.selected_objects:
        obj.select_set(False)
    root.hide_set(False)
    root.select_set(True)
    context.view_layer.objects.active = root


def duplicate_asset(context, root):
    """Copy hierarchy, armature, constraints, drivers and animation independently."""
    collection = asset_collection(context, root.name + ' copy')
    mapping = {}
    actions = {}
    def copy_action(action):
        if action not in actions:
            actions[action] = action.copy()
        return actions[action]
    for source in descendants(root):
        obj = source.copy()
        if source.data:
            obj.data = source.data.copy()
        if source.animation_data and source.animation_data.action:
            obj.animation_data.action = copy_action(source.animation_data.action)
        if obj.animation_data:
            for track in obj.animation_data.nla_tracks:
                for strip in track.strips:
                    if strip.action:
                        strip.action = copy_action(strip.action)
        collection.objects.link(obj)
        obj.hide_set(source.hide_get())
        mapping[source] = obj
    for source, obj in mapping.items():
        if source.parent in mapping:
            obj.parent = mapping[source.parent]
        for modifier in obj.modifiers:
            if hasattr(modifier, 'object') and modifier.object in mapping:
                modifier.object = mapping[modifier.object]
        owners = [obj] + (list(obj.pose.bones) if obj.pose else [])
        for owner in owners:
            if hasattr(owner,'custom_shape') and owner.custom_shape in mapping:
                owner.custom_shape = mapping[owner.custom_shape]
            for constraint in owner.constraints:
                if hasattr(constraint, 'target') and constraint.target in mapping:
                    constraint.target = mapping[constraint.target]
                if hasattr(constraint, 'pole_target') and constraint.pole_target in mapping:
                    constraint.pole_target = mapping[constraint.pole_target]
        if obj.animation_data:
            for fc in obj.animation_data.drivers:
                for variable in fc.driver.variables:
                    for target in variable.targets:
                        if target.id in mapping:
                            target.id = mapping[target.id]
    copy = mapping[root]
    copy.location.x += 1.2 if root.get('bs_kind') == 'character' else 2
    identify(copy, context.scene)
    select_root(context, copy)
    return copy


_syncing = False
_known_roots = {}


@bpy.app.handlers.persistent
def sync_duplicate_colors(scene, depsgraph=None):
    """Native hierarchy Shift-D gets a new stable ID; no per-frame material copies."""
    global _syncing
    if _syncing or bpy.app.is_job_running('RENDER'):
        return
    _syncing = True
    try:
        groups = {}
        for root in scene.objects:
            if root.get('bs_root') and root.get('bs_uid'):
                groups.setdefault(root['bs_uid'], []).append(root)
        for uid, roots in groups.items():
            owner = next((r for r in roots if r.as_pointer() == _known_roots.get(uid)), roots[0])
            _known_roots[uid] = owner.as_pointer()
            for root in roots:
                if root != owner:
                    identify(root, scene)
                    _known_roots[root['bs_uid']] = root.as_pointer()
        live = {r['bs_uid'] for roots in groups.values() for r in roots}
        for uid in set(_known_roots) - live:
            del _known_roots[uid]
    finally:
        _syncing = False


@bpy.app.handlers.persistent
def reset_identity_tracking(_unused=None):
    _known_roots.clear()


def register():
    for handlers, fn in ((bpy.app.handlers.depsgraph_update_post, sync_duplicate_colors),
                         (bpy.app.handlers.load_post, reset_identity_tracking),
                         (bpy.app.handlers.undo_post, reset_identity_tracking),
                         (bpy.app.handlers.redo_post, reset_identity_tracking)):
        if fn not in handlers:
            handlers.append(fn)


def unregister():
    for handlers, fn in ((bpy.app.handlers.depsgraph_update_post, sync_duplicate_colors),
                         (bpy.app.handlers.load_post, reset_identity_tracking),
                         (bpy.app.handlers.undo_post, reset_identity_tracking),
                         (bpy.app.handlers.redo_post, reset_identity_tracking)):
        if fn in handlers:
            handlers.remove(fn)
    _known_roots.clear()
