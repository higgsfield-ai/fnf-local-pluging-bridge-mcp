"""Additional blockout furniture and ceiling fixtures; reuse existing materials."""
import math
import bpy
from mathutils import Vector
from . import props,core

EXTRA_ITEMS=[
 ('wardrobe','Wardrobe','Tall two-door wardrobe','FURNITURE'),
 ('kitchen_counter','Kitchen Counter','Base cabinet with a countertop','KITCHEN'),
 ('sink_unit','Sink Unit','Counter with an open sink and faucet','KITCHEN'),
 ('fridge','Refrigerator','Two-door refrigerator blockout','KITCHEN'),
 ('stove','Stove / Oven','Four burners and an oven','KITCHEN'),
 ('wall_cabinet','Wall Cabinet','Upper kitchen cabinet','KITCHEN'),
 ('toilet','Toilet','Toilet and cistern blockout','BATHROOM'),
 ('bathtub','Bathtub','Open tub with thick sides','BATHROOM'),
 ('shower','Shower','Tray and an open shower frame','BATHROOM'),
 ('pendant','Pendant Light','Pendant hanging from the ceiling','LIGHTING'),
 ('chandelier','Chandelier','Six-arm ceiling chandelier','LIGHTING'),
 ('ceiling_light','Ceiling Light','Shallow ceiling fixture','LIGHTING'),
 ('wall_sconce','Wall Sconce','Wall-mounted light fixture','LIGHTING'),
 ('rug','Rug','Thin rectangular floor block','FURNITURE'),
]
CEILING={'pendant','chandelier','ceiling_light'}
WALL={'wall_cabinet','wall_sconce'}


def cabinet(b,tall=False,wall=False,sink=False,stove=False):
    w,d,h=(1.5,.60,2.1) if tall else ((.9,.35,.7) if wall else (.9,.62,.9))
    b.box('Cabinet carcass',(0,0,h/2),(w,d,h),'secondary',.015)
    if not wall: b.box('Recessed plinth',(0,.025,.05),(w-.09,d-.07,.1),'dark',.005)
    if not sink:b.box('Top',(0,-.01,h+.015),(w+.025,d+.035,.04),'light',.01)
    for x in (-w/4,w/4):
        b.box('Door',(x,-d/2-.015,h/2+.04),(w/2-.025,.035,h-.12),'primary',.01)
        b.box('Handle',(x+(-.14 if x>0 else .14),-d/2-.047,h*.6),(.025,.03,.20),'dark',.004)
    if sink:
        # Rim strips leave an actual open basin.
        for x in (-.325,.325):b.box('Counter side',(x,0,.925),(.25,.66,.05),'light',.005)
        for y in (-.245,.245):b.box('Counter edge',(0,y,.925),(.42,.17,.05),'light',.005)
        b.box('Basin',(0,-.01,.895),(.4,.33,.015),'dark',.006)
        b.cyl('Tap stem',(.25,.20,1.02),.023,.20,'metal',8)
        b.beam('Faucet',(.25,.20,1.12),(.08,.20,1.12),.033,'metal')
    if stove:
        for x in (-.23,.23):
            for y in (-.16,.16):b.cyl('Burner',(x,y,h+.043),.108,.012,'dark',12)
        b.box('Oven window',(0,-d/2-.043,.46),(.6,.02,.38),'dark',.012)
        b.box('Oven pull',(0,-d/2-.08,.72),(.55,.04,.035),'metal',.004)


def fridge(b):
    b.box('Fridge',(0,0,.92),(.8,.75,1.84),'light',.035)
    for z,h in ((.59,1.10),(1.49,.60)):
        b.box('Door',(0,-.393,z),(.75,.05,h),'primary',.015)
        b.box('Pull',(-.26,-.445,z),(.028,.045,.28),'dark',.006)


def bathroom(b,kind):
    if kind=='toilet':
        b.taper('Pedestal',(0,0,.21),.18,.24,.42,'light',10)
        b.box('Seat',(0,-.05,.44),(.42,.58,.075),'light',.05)
        b.box('Seat inset',(0,-.085,.481),(.25,.32,.013),'dark',.035)
        b.box('Cistern',(0,.30,.57),(.43,.20,.52),'light',.025)
        b.box('Flush',(0,.30,.84),(.075,.04,.012),'metal',.004)
    elif kind=='bathtub':
        b.box('Tub bottom',(0,0,.08),(1.75,.8,.16),'light',.035)
        for y in (-.365,.365):b.box('Tub side',(0,y,.33),(1.75,.095,.5),'light',.035)
        for x in (-.8275,.8275):b.box('Tub end',(x,0,.33),(.095,.67,.5),'light',.025)
        b.box('Tub interior',(0,0,.18),(1.55,.60,.04),'secondary',.03)
    else:
        b.box('Shower tray',(0,0,.055),(.95,.95,.11),'light',.015)
        for x,y in ((-.45,.45),(.45,.45),(.45,-.45)):
            b.box('Shower upright',(x,y,1.05),(.035,.035,2.0),'metal',.003)
        for x in (-.45,.45):b.box('Top rail',(x,0,2.04),(.035,.93,.035),'metal',.003)
        b.box('Top rail',(0,.45,2.04),(.93,.035,.035),'metal',.003)
        b.beam('Shower pipe',(-.25,.39,.8),(-.25,.39,1.93),.035,'metal')
        b.cyl('Shower head',(-.25,.23,1.93),.10,.025,'dark',12)


def fixture(b,kind):
    # Origin is the ceiling attachment; all geometry hangs down.
    if kind=='ceiling_light':
        b.cyl('Ceiling base',(0,0,-.035),.26,.07,'dark',16)
        b.taper('Diffuser',(0,0,-.11),.22,.26,.08,'light',16)
        return
    if kind=='wall_sconce':
        b.box('Wall plate',(0,0,.15),(.13,.08,.28),'dark',.01)
        b.box('Bracket',(0,-.11,.08),(.04,.22,.04),'metal',.004)
        b.taper('Shade',(0,-.20,.23),.13,.10,.23,'light',8)
        return
    b.cyl('Ceiling canopy',(0,0,-.025),.12,.05,'dark',12)
    b.cyl('Suspension',(0,0,-.36),.016,.67,'dark',8)
    if kind=='pendant':
        b.taper('Pendant shade',(0,0,-.78),.32,.08,.28,'primary',12)
        b.cyl('Light face',(0,0,-.925),.29,.015,'light',12)
    else:
        b.cyl('Central hub',(0,0,-.72),.105,.20,'dark',12)
        for i in range(6):
            angle=i*math.tau/6
            x,y=.43*math.cos(angle),.43*math.sin(angle)
            b.beam('Chandelier arm',(0,0,-.75),(x,y,-.75),.03,'metal')
            b.cyl('Candle',(x,y,-.65),.026,.19,'light',8)
            b.taper('Lampshade',(x,y,-.55),.11,.065,.15,'light',8)


BUILDERS={
 'wardrobe':lambda b:cabinet(b,tall=True),
 'kitchen_counter':cabinet,
 'sink_unit':lambda b:cabinet(b,sink=True),
 'wall_cabinet':lambda b:cabinet(b,wall=True),
 'stove':lambda b:cabinet(b,stove=True),
 'fridge':fridge,
 'toilet':lambda b:bathroom(b,'toilet'),
 'bathtub':lambda b:bathroom(b,'bathtub'),
 'shower':lambda b:bathroom(b,'shower'),
 'pendant':lambda b:fixture(b,'pendant'),
 'chandelier':lambda b:fixture(b,'chandelier'),
 'ceiling_light':lambda b:fixture(b,'ceiling_light'),
 'wall_sconce':lambda b:fixture(b,'wall_sconce'),
 'rug':lambda b:b.box('Rug',(0,0,.012),(2.5,1.7,.024),'primary',.012),
}


def create(context,kind,collection):
    if kind not in BUILDERS:return props.create_asset(context,kind,collection)
    root=bpy.data.objects.new(next(i[1] for i in EXTRA_ITEMS if i[0]==kind),None)
    collection.objects.link(root)
    root.empty_display_type='PLAIN_AXES';root.empty_display_size=.25
    root['bs_root']=True;root['bs_kind']='prop';root['bs_asset']=kind
    BUILDERS[kind](props._Build(root,collection,0))
    if kind in CEILING or kind=='wall_sconce':
        data=bpy.data.lights.new('Fixture Light','POINT');data.energy=80;data.shadow_soft_size=.18
        light=bpy.data.objects.new('Fixture Light',data);collection.objects.link(light);light.parent=root
        light.location=(0,-.23,.08) if kind=='wall_sconce' else (0,0,-1.02 if kind in {'pendant','chandelier'} else -.22)
    return root


def bounds(root):
    inv=root.matrix_world.inverted_safe()
    pts=[inv@ob.matrix_world@Vector(corner) for ob in core.descendants(root)
         if ob.type=='MESH' for corner in ob.bound_box]
    if not pts:return Vector((0,0,0)),Vector((1,1,1))
    return Vector([min(p[i] for p in pts) for i in range(3)]),Vector([max(p[i] for p in pts) for i in range(3)])


def mount_to_ceiling(obj,root):
    obj['ceiling_drop']=0.0
    obj.id_properties_ui('ceiling_drop').update(min=0,max=10,description='Extra distance below the ceiling in meters')
    fc=obj.driver_add('location',2)
    for name,target,path in [('h',root,'["bs_ceiling_height"]'),('drop',obj,'["ceiling_drop"]')]:
        var=fc.driver.variables.new();var.name=name;var.type='SINGLE_PROP'
        var.targets[0].id=target;var.targets[0].data_path=path
    fc.driver.expression='h-drop'


def mount_asset(context,kind,room_root):
    col=core.asset_collection(context,'Furniture / '+kind.replace('_',' ').title())
    obj=create(context,kind,col)
    core.attach(obj,room_root)
    core.identify(obj,context.scene)
    if kind in CEILING:mount_to_ceiling(obj,room_root)
    context.view_layer.update()
    low,high=bounds(obj)
    obj['bs_base_dimensions']=list(high-low)
    return obj
