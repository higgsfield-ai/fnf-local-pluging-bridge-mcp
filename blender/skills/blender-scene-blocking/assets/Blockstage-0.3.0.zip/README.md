# Blockstage 0.3.0

A Blender add-on for building editable room blockouts, placing low-poly furniture, and staging animated characters and cameras. All controls, tooltips, operator messages and included guides are in English.

Includes 4 rigged character variants, 42 generated props and furnishings, 46 asset thumbnails, procedural rooms, doors, windows, ceiling fixtures and six furniture layouts. Models are generated locally; no external Python packages or online account are required.

## Install

1. Open Blender **Edit > Preferences > Get Extensions**.
2. Open the dropdown menu and choose **Install from Disk**.
3. Select **Blockstage-0.3.0.zip** without extracting it, then enable Blockstage.
4. In the 3D View, press **N** and open **Blockstage**.

When replacing an already loaded version manually, save your scene and restart Blender after installation. Do not enable both a legacy copy and an extension copy.

Installation-unlocked variant: the installer version threshold is 4.2.0, the baseline for Blender extensions. This metadata change does not certify runtime compatibility with earlier Blender releases. The functional code and actor library are unchanged; they were verified on Blender 5.2.0 LTS for macOS. The bundled actor library cannot be read by Blender versions older than 4.5.

## Whole-object colors

Select any part of a furnishing, then open **N > Blockstage > Colors** or **Object Properties > Blockstage**.

- **Furniture Color** changes the complete furnishing, including upholstery, feet, handles and every other mesh part.
- **Walls Color** changes the entire room's wall assemblies, including corners, trim, frames, door leaves and handles.
- **Floor Color** changes the complete floor.
- **Ceiling Color** changes the complete ceiling.

There are no separate part, accent, wood or metal color controls in the panel. A newly chosen whole-object color replaces old per-part overrides. Existing scenes retain their appearance until you choose a new color. Separate furniture assets remain independent, including objects placed on another asset.

All material slots receive the same base color. Surface roughness, metallic settings and lighting can still create natural shading differences. Colors remain after saving, reopening, resizing rooms, adding openings and recreating ceilings. Geometry and animation are not rebuilt by color controls.

## Preview library

Choose a category and click the large thumbnail to browse the visual catalog. Select a thumbnail, then press **Place [Name]** in the Furniture & Lighting sidebar. Click to place, **R** to turn, and **Esc** to cancel. Search filters the catalog.

In **Object Properties > Blockstage**, **Add [Name]** places the asset at the 3D Cursor. The original **BLOCKSTAGE / BASE 01** library also includes thumbnail previews for characters, props, vehicles and set pieces.

Thumbnails show the default generated models. Your custom scene colors and dimensions are displayed on the actual scene objects.

## Rooms and furniture

Create a **Rectangle**, **L-shaped** room, or use **Draw Room** to click its outline. Edit dimensions, corners, wall visibility and openings in **Room Builder**. Furniture can be placed with wall and grid snapping. The complete workflow is described in [Room Builder Guide](ROOM_BUILDER.md).

To remove a wall from the viewport and render, uncheck its box in **Walls & Corners**. Check the box again to restore it. The floor outline remains unchanged. Deleting generated wall geometry with X is temporary because the room generator recreates it during later edits.

## Characters and staging

The character catalog contains exactly **Man, Woman, Heavy Man and Heavy Woman**, imported from the supplied Blockstage Cast library. Each has the original 141-bone armature, 30 editable finger bones, separate arm and leg IK/FK chains, hand curl/spread, and foot roll/bank controls. The supplied body meshes, vertex weights and rest skeletons are preserved. Select a character and open **Selected Asset > Pose Controls**. Use the pose presets as starting poses, edit the controls manually, and press **Key Pose** at each required frame. Presets do not create complete animation cycles.

**Duplicate Asset** copies the whole hierarchy, rig and animation. For native Shift+D duplication, first use **Select Entire Asset** so that all parts are selected. A copied asset can be recolored independently.

Use **Attach to Hand** to parent a prop to an actor's hand. Place it in the grip and adjust its local position as needed.

**Shot & Reference** creates camera motion and soft lighting, or exports local reference images, video and shot notes. Creating a shot camera applies the chosen duration, lens and frame settings. Exported references are saved locally and are not uploaded to an external service.

These are lightweight blockout rigs. Extreme deformation or close-up hand animation may require manual adjustment.

## Documentation and validation

- [Preview and Color Guide](PREVIEWS_AND_COLORS.md)
- [Room Builder Guide](ROOM_BUILDER.md)
- [Character Rig Guide](CHARACTERS.md)
- [Changelog](CHANGELOG.md)

Version 0.3.0 passed 71 integration checks covering the exact four-actor catalog, source geometry and weights, rig dependencies, finger deformation, IK/FK matching, foot roll, pose presets, animation keys, duplicate independence, prop attachment, room/color tools, previews and save/reopen. Four new cast thumbnails replace the old character previews; the library still contains 46 previews.

The four body meshes and rig data come from the user-supplied Blockstage-Cast-1.0.0.zip. Model provenance metadata is retained in the actor library. The combined add-on is self-contained and does not require Blockstage Cast to be installed separately.

Code license: GPL-3.0-or-later. See LICENSE.
