# Blockstage 0.2 — Room Builder

All controls, tooltips, and operator messages are in English.
Built for scene blocking, using meters. No new shaders or textures are included;
architectural parts and new furniture reuse Blockstage's existing simple materials.
The installation-unlocked variant relaxes the installer threshold only. Room tools were tested in Blender 5.2.0 LTS; earlier versions remain unverified.

## Install / update

1. In Blender: Edit → Preferences → Add-ons → menu → Install from Disk.
2. Select `Blockstage-0.3.0.zip` without extracting it, and enable Blockstage.
3. Open the 3D View sidebar with N, then choose **Blockstage**.
4. Start with **ROOM BUILDER / 0.2**. The original cast, props, camera and export
   tools remain below it.

If a development copy was loaded manually into the current session, save your
scene and restart Blender after installing. Do not enable both a legacy copy and
an extension copy at the same time.

## Create a room

- **Rectangle**: create a room at the 3D Cursor, then edit Width, Depth, Height.
- **L-shaped**: adds an editable corner notch, with Notch Width and Notch Depth.
- **Draw Room**: click the outline corners on the floor. Enter closes the room;
  clicking near the first corner also closes it. Backspace removes the last
  corner. Esc/right-click cancels without leaving objects behind.
- Grid snapping uses **Grid Step**. Hold Shift to disable it, Ctrl for free angles.
- Draw a single, simple closed contour. Self-intersections are rejected.
- **Walls & Corners → Edit Outline** unlocks individual corner coordinates.
  **Split Wall** inserts a corner; **Remove Corner** removes one. Remove openings
  before changing the number of walls so their wall assignments are not ambiguous.
  Moving existing corners remains available with openings present.
- Wall checkboxes hide individual wall geometry. **Overview** frames the room;
  **Floor Plan** shows it from above. Neither changes scene cameras.

### Visibility

**Cutaway** hides front/right-facing walls and the ceiling for staging.
**Complete** shows all enabled walls and the ceiling.
**Open Top** keeps the walls and hides the ceiling.
These modes affect BOTH viewport visibility and renders. Choose Complete before
an enclosed interior render. Ceiling fixtures remain visible in a cutaway.
Ceiling and Trim checkboxes control whether those parts are generated.

## Doors and windows

Click **Door**, **Window**, or **Passage**, then click a wall. Top view placement
also works near a wall edge. A blue outline previews the position.

Use the opening list to select an item. Adjust **Wall Number**, **From Wall Start**
(the opening center), **Width**, **Height**, and, for windows, **Sill Height**,
**Window Columns**, and **Window Rows**. Dimensions update real holes in the mesh,
without Boolean modifiers. Windows have open frames, with no glass shader.

Use **Reposition on Wall** to move a fitted opening. Do not move its generated
mesh with G: the next parameter update restores generated transforms. Duplicate
and delete openings with the buttons beside the list. Selecting a door or frame
in the viewport selects its settings in the panel.

The generator fits openings inside the available wall span and separates
conflicting openings. Notices explain adjusted or temporarily omitted openings;
no-space items remain in the list and can be moved or resized.

Doors have left/right hinges and **Open Angle**. Right-click Open Angle to insert
keyframes. Door drivers and animation survive room resizing, duplication, and
removal of other openings. Structural dimensions are layout controls, not a
per-frame geometry animation system.

## Furniture and lighting

The room library contains 29 interior assets across Furniture, Kitchen, Bathroom,
and Lighting. Click the large thumbnail, select an item, press Place, then move the mouse over the floor and click to place.

- **R**: rotate the preview by 90 degrees.
- **Alt**: temporarily disable wall snapping.
- **Shift**: temporarily disable grid snapping.
- **Esc / right-click**: cancel and remove the preview.
- **Snap to Walls** aligns items near the room boundary.

Furniture remains independent and stays in place when room dimensions change.
To move a complete furnishing after placement, click any part and use
**Select Root**, then G/R. **Dimensions** sets its overall width, depth and height;
this proportionally scales its blockout rather than redesigning individual parts.
**Duplicate**, **Turn 90**, and the trash button act on the complete furnishing.

Pendant Light, Chandelier, and Ceiling Light attach to the room height.
**Ceiling Drop** adjusts the extra distance below the ceiling. Each fixture has
an actual light with **Light Power** in the selected furnishing controls.
Wall cabinets and sconces start at wall height, which can be adjusted in Position.

Six automatic furniture layouts: Living, Bedroom, Office, Dining, Kitchen, Bathroom.
These require a rectangular room of at least 4.8 × 4.8 m. They add independent
objects and do not replace existing furniture. They are starting layouts: check
door swing clearance and adjust placement for your particular shot.

## Old scenes and editability

Version 0.1 rooms remain supported. Select one and click **Upgrade Room to 0.2**
to retain its dimensions, original openings and attached furniture. Save a copy
before migrating production scenes. Existing character rigs are not rebuilt.

Generated architectural geometry is derived from the room settings. Use these
controls for architecture; direct mesh edits to generated walls/frames will be
replaced on the next rebuild. Manually added furniture is preserved. Use Blender's
normal Save and Undo. Rooms duplicate with independent data and drivers.

The demonstration file contains three separate scenes: Living Room, Drawn Plan,
and Kitchen. Install/enable the extension before opening it to edit room settings.
The visible meshes also open without the add-on.

## Whole-object colors

Use Colors in the sidebar or Object Properties > Blockstage. Furniture Color affects the complete asset. Walls Color affects all wall assemblies, including frames, trim and door parts; Floor Color and Ceiling Color are separate. Old part overrides are replaced when you choose a new whole-object color. See PREVIEWS_AND_COLORS.md.
