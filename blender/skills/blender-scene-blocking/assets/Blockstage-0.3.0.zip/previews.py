"""Bundled, locally rendered asset thumbnails and stable filtered pickers."""
from pathlib import Path
import bpy
import bpy.utils.previews
from bpy.props import EnumProperty, PointerProperty
from . import props, interiors, characters

_catalog = []
_icons = None
_items = {}
_EMPTY = [('NONE', 'No matches', 'Try another category or search', 0, 0)]


def filtered(scene, section):
    settings = scene.bs_editor if section == 'interior' else scene.bs_settings
    query = settings.search.strip().lower()
    allowed = set(i[0] for i in props.ASSET_ITEMS if i[3] == 'FURNITURE') | set(i[0] for i in interiors.EXTRA_ITEMS)
    return [item for item in _catalog if item[3] == settings.category
            and (section != 'interior' or item[0] in allowed)
            and (not query or query in (item[1] + ' ' + item[2]).lower())]


def enum_items(self, context, section):
    rows = filtered(self.id_data, section)
    return [_items[r[0]] for r in rows] or _EMPTY


def enum_get(self, section):
    rows = enum_items(self, None, section)
    stored = self.get(section + '_selection', 0)
    return stored if any(item[4] == stored for item in rows) else rows[0][4]


def enum_set(self, value, section):
    self[section + '_selection'] = value


class BS_PreviewSettings(bpy.types.PropertyGroup):
    interior: EnumProperty(name='Furniture Preview',
        description='Click the preview to browse furniture thumbnails',
        items=lambda self, ctx: enum_items(self, ctx, 'interior'),
        get=lambda self: enum_get(self, 'interior'),
        set=lambda self, value: enum_set(self, value, 'interior'))
    library: EnumProperty(name='Asset Preview',
        description='Click the preview to browse asset thumbnails',
        items=lambda self, ctx: enum_items(self, ctx, 'library'),
        get=lambda self: enum_get(self, 'library'),
        set=lambda self, value: enum_set(self, value, 'library'))


class BS_OT_preview_add(bpy.types.Operator):
    bl_idname = 'blockstage.preview_add'
    bl_label = 'Add Previewed Asset'
    bl_description = 'Place the asset shown in the preview; viewing thumbnails never creates objects'
    bl_options = {'REGISTER', 'UNDO'}
    section: EnumProperty(items=[('interior', 'Furniture', ''), ('library', 'Library', '')])

    def run(self, context, interactive):
        chosen = getattr(context.scene.bs_previews, self.section)
        if chosen == 'NONE':
            return {'CANCELLED'}
        if self.section == 'interior':
            mode = 'INVOKE_DEFAULT' if interactive and context.area and context.area.type == 'VIEW_3D' else 'EXEC_DEFAULT'
            return bpy.ops.blockstage.place_furniture(mode, asset=chosen)
        if chosen in {i[0] for i in characters.CHARACTER_ITEMS}:
            return bpy.ops.blockstage.add_character(variant=chosen)
        return bpy.ops.blockstage.add_asset(asset=chosen)

    def invoke(self, context, event):
        return self.run(context, True)

    def execute(self, context):
        return self.run(context, False)


def draw_picker(layout, context, section):
    rows = filtered(context.scene, section)
    if not rows:
        layout.label(text='No matching assets.', icon='INFO')
        return
    p = context.scene.bs_previews
    box = layout.box()
    row = box.row()
    row.alignment = 'CENTER'
    row.template_icon_view(p, section, show_labels=True, scale=5.0, scale_popup=5.0)
    selected = getattr(p, section)
    label = next((r[1] for r in rows if r[0] == selected), rows[0][1])
    row = box.row(); row.alignment = 'CENTER'; row.label(text=label)
    row = box.row(); row.alignment = 'CENTER'; row.label(text=f'Browse {len(rows)} assets', icon='TRIA_DOWN')
    in_view = context.area and context.area.type == 'VIEW_3D'
    row = layout.row(); row.scale_y = 1.25
    row.operator_context = 'INVOKE_DEFAULT'
    op = row.operator('blockstage.preview_add', text=('Place ' if section == 'interior' and in_view else 'Add ') + label, icon='ADD')
    op.section = section


classes = (BS_PreviewSettings, BS_OT_preview_add)


def register():
    global _icons, _catalog
    _catalog = list(props.ASSET_ITEMS) + list(interiors.EXTRA_ITEMS) + [(*i, 'CHARACTERS') for i in characters.CHARACTER_ITEMS]
    _icons = bpy.utils.previews.new()
    folder = Path(__file__).parent / 'thumbnails'
    for number, (key, label, description, category) in enumerate(_catalog, 1):
        path = folder / (key + '.png')
        icon = _icons.load(key, str(path), 'IMAGE').icon_id if path.is_file() else 0
        # Keep all strings and item tuples alive for Blender's dynamic enums.
        _items[key] = (key, label, description, icon, number)
    for cls in classes: bpy.utils.register_class(cls)
    bpy.types.Scene.bs_previews = PointerProperty(type=BS_PreviewSettings)


def unregister():
    global _icons
    del bpy.types.Scene.bs_previews
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
    if _icons is not None:
        bpy.utils.previews.remove(_icons)
        _icons = None
    _items.clear()
