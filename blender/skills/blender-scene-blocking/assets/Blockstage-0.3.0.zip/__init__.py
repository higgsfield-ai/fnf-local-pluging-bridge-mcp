"""Blockstage: an original low-poly staging kit for reference-video workflows."""
bl_info = {
    'name': 'Blockstage — AI Blocking Kit',
    'author': 'Blockstage',
    'version': (0, 3, 0),
    'blender': (4, 2, 0),
    'location': '3D View > Sidebar > Blockstage',
    'description': 'Rigged cast, low-poly props, adjustable rooms and reference-video handoff',
    'category': '3D View',
}

from datetime import datetime
from pathlib import Path

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty

from . import core, characters, props, room, staging, plan, interiors, room_tools, previews, appearance, cast_tools


class BS_Settings(bpy.types.PropertyGroup):
    pack: EnumProperty(name='Pack', items=[('BASE','Base / 01','Everyday film blocking essentials')])
    category: EnumProperty(name='Library', items=[
        ('CHARACTERS','Characters','Rigged performers'), ('FURNITURE','Furniture','Interior library'),
        ('PROPS','Props','Handheld and story objects'), ('VEHICLES','Vehicles','Simple street vehicles'),
        ('SET','Set','Architectural and street elements')])
    search: StringProperty(name='Search', options={'TEXTEDIT_UPDATE'})
    pose: EnumProperty(name='Pose', items=characters.POSE_ITEMS)
    grip: FloatProperty(name='Hand curl', default=0, min=0, max=1, subtype='FACTOR')
    camera_move: EnumProperty(name='Move', items=staging.CAMERA_ITEMS)
    duration: IntProperty(name='Seconds', default=5, min=1, max=120)
    fps: IntProperty(name='FPS', default=24, min=1, max=120)
    lens: FloatProperty(name='Lens', default=40, min=12, max=200, subtype='NONE')
    notes: StringProperty(name='Director notes', description='Action, timing, contact points and final look')
    layout_preset: EnumProperty(name='Layout',items=[('LIVING','Living room','Sofa, table and lighting'),
        ('OFFICE','Office','Desk, chair and shelves'),('BEDROOM','Bedroom','Bed and bedside furniture')])
    attach_rig: PointerProperty(name='Actor',type=bpy.types.Object,
        poll=lambda self,obj: obj.type == 'ARMATURE' and obj.get('bs_kind') == 'character')
    attach_hand: EnumProperty(name='Hand',items=[('R','Right','Right hand'),('L','Left','Left hand')])


def current_root(context):
    return core.asset_root(context.object)


def object_mode(context):
    if context.object and context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')


class BS_OT_add_character(bpy.types.Operator):
    bl_idname = 'blockstage.add_character'
    bl_label = 'Add Character'
    bl_description = 'Add an independently rigged performer at the 3D cursor'
    bl_options = {'REGISTER','UNDO'}
    variant: EnumProperty(items=characters.CHARACTER_ITEMS)

    def execute(self, context):
        object_mode(context)
        collection = core.asset_collection(context, 'Cast / ' + self.variant.title())
        root = characters.create_character(context, self.variant, collection)
        root.location = context.scene.cursor.location
        core.identify(root, context.scene)
        core.select_root(context, root)
        return {'FINISHED'}


class BS_OT_add_asset(bpy.types.Operator):
    bl_idname = 'blockstage.add_asset'
    bl_label = 'Add Asset'
    bl_description = 'Add an editable low-poly asset at the 3D cursor'
    bl_options = {'REGISTER','UNDO'}
    asset: EnumProperty(items=[item[:3] for item in props.ASSET_ITEMS])

    def execute(self, context):
        object_mode(context)
        collection = core.asset_collection(context, 'Library / ' + self.asset.replace('_',' ').title())
        root = props.create_asset(context, self.asset, collection)
        root.location = context.scene.cursor.location
        core.identify(root, context.scene)
        core.select_root(context, root)
        return {'FINISHED'}


class BS_OT_add_room(bpy.types.Operator):
    bl_idname = 'blockstage.add_room'
    bl_label = 'Add Procedural Room'
    bl_description = 'Create a room with editable dimensions, openings and individual walls'
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        object_mode(context)
        root = plan.create(context)
        context.scene.bs_editor.room = root
        core.select_root(context, root)
        return {'FINISHED'}


class BS_OT_duplicate(bpy.types.Operator):
    bl_idname = 'blockstage.duplicate'
    bl_label = 'Duplicate Asset'
    bl_description = 'Copy the complete hierarchy with independent rig, animation and a new ID color'
    bl_options = {'REGISTER','UNDO'}

    @classmethod
    def poll(cls, context):
        return current_root(context) is not None

    def execute(self, context):
        root = current_root(context)
        object_mode(context)
        core.duplicate_asset(context,root)
        return {'FINISHED'}


class BS_OT_furnish(bpy.types.Operator):
    bl_idname = 'blockstage.furnish_room'
    bl_label = 'Add Furniture Layout'
    bl_description = 'Place independent furniture inside the selected room'
    bl_options = {'REGISTER','UNDO'}

    @classmethod
    def poll(cls,context):
        root = current_root(context)
        return root is not None and root.get('bs_kind') == 'room'

    def execute(self,context):
        root = current_root(context)
        s = root.bs_room
        if s.width < 3.6 or s.depth < 3.6:
            self.report({'WARNING'},'Furniture layouts need at least a 3.6 × 3.6 m room; individual assets fit smaller sets.')
            return {'CANCELLED'}
        rear = s.depth/2
        side = s.width/2
        layouts = {
            'LIVING':[('sofa',(0,rear-.62,0)),('coffee_table',(0,rear-1.85,0)),
                      ('floor_lamp',(-side+.5,rear-.55,0)),('plant',(side-.45,rear-.5,0)),
                      ('armchair',(-side+.68,rear-2,0))],
            'OFFICE':[('desk',(0,rear-.65,0)),('dining_chair',(0,rear-1.65,0)),
                      ('laptop',(0,rear-.65,.76)),('bookcase',(-side+.7,rear-.3,0)),
                      ('plant',(side-.45,rear-.5,0))],
            'BEDROOM':[('bed',(0,rear-1.1,0)),('cabinet',(-side+.6,0,0)),
                       ('table_lamp',(-side+.6,0,.8)),('plant',(side-.45,rear-.5,0))],
        }
        collection = core.asset_collection(context,'Layout / ' + context.scene.bs_settings.layout_preset.title())
        for id_,location in layouts[context.scene.bs_settings.layout_preset]:
            obj = props.create_asset(context,id_,collection)
            core.attach(obj,root)
            obj.location = location
            core.identify(obj,context.scene)
        core.select_root(context,root)
        return {'FINISHED'}


class BS_OT_attach(bpy.types.Operator):
    bl_idname = 'blockstage.attach_to_hand'
    bl_label = 'Attach to Hand'
    bl_description = 'Attach the selected prop to an actor hand while keeping its current world position; move the prop into the grip'
    bl_options = {'REGISTER','UNDO'}

    @classmethod
    def poll(cls,context):
        root = current_root(context)
        return root is not None and root.get('bs_kind') == 'prop' and context.scene.bs_settings.attach_rig is not None

    def execute(self,context):
        root = current_root(context)
        rig = context.scene.bs_settings.attach_rig
        hand = 'hand.' + context.scene.bs_settings.attach_hand
        if hand not in rig.pose.bones:
            self.report({'ERROR'},'This actor has no matching hand bone.')
            return {'CANCELLED'}
        world = root.matrix_world.copy()
        root.parent = rig
        root.parent_type = 'BONE'
        root.parent_bone = hand
        context.view_layer.update()
        root.matrix_world = world
        return {'FINISHED'}


class BS_OT_recolor(bpy.types.Operator):
    bl_idname = 'blockstage.next_color'
    bl_label = 'Next ID Color'
    bl_options = {'REGISTER','UNDO'}

    @classmethod
    def poll(cls, context):
        return current_root(context) is not None

    def execute(self, context):
        root = current_root(context)
        core.recolor(root, int(root.get('bs_color_index',0)) + 1)
        appearance.write_color(root, 'walls' if root.get('bs_kind') == 'room' else 'asset', core.palette_color(root['bs_color_index']))
        return {'FINISHED'}


class BS_OT_select_hierarchy(bpy.types.Operator):
    bl_idname = 'blockstage.select_hierarchy'
    bl_label = 'Select Entire Asset'
    bl_description = 'Select root and every part for native Shift-D, moving or deleting'

    @classmethod
    def poll(cls, context):
        return current_root(context) is not None

    def execute(self, context):
        root = current_root(context)
        core.select_root(context,root)
        for obj in core.descendants(root):
            obj.select_set(True)
        return {'FINISHED'}


class BS_OT_pose(bpy.types.Operator):
    bl_idname = 'blockstage.apply_pose'
    bl_label = 'Apply Pose'
    bl_description = 'Set a starting pose; keyframes are inserted only by Key Pose'
    bl_options = {'REGISTER','UNDO'}

    @classmethod
    def poll(cls, context):
        root = current_root(context)
        return root is not None and root.type == 'ARMATURE' and root.get('bs_kind') == 'character'

    def execute(self, context):
        root = current_root(context)
        characters.apply_pose(root, context.scene.bs_settings.pose)
        context.view_layer.update()
        return {'FINISHED'}


class BS_OT_grip(bpy.types.Operator):
    bl_idname = 'blockstage.hand_curl'
    bl_label = 'Set Hand Curl'
    bl_options = {'REGISTER','UNDO'}
    poll = classmethod(lambda cls,context: BS_OT_pose.poll(context))

    def execute(self, context):
        characters.set_hand_grip(current_root(context), context.scene.bs_settings.grip)
        context.view_layer.update()
        return {'FINISHED'}


class BS_OT_pose_mode(bpy.types.Operator):
    bl_idname = 'blockstage.pose_mode'
    bl_label = 'Pose Controls'
    bl_description = 'Enter Pose Mode to move hand/foot IK and rotate body/finger controls'
    poll = classmethod(lambda cls,context: BS_OT_pose.poll(context))

    def execute(self, context):
        root = current_root(context)
        core.select_root(context, root)
        bpy.ops.object.mode_set(mode='POSE')
        return {'FINISHED'}


class BS_OT_key_pose(bpy.types.Operator):
    bl_idname = 'blockstage.key_pose'
    bl_label = 'Key Pose'
    bl_description = 'Insert body, IK and finger transform keys at the current frame'
    bl_options = {'REGISTER','UNDO'}
    poll = classmethod(lambda cls,context: BS_OT_pose.poll(context))

    def execute(self, context):
        characters.key_pose(current_root(context), context.scene.frame_current)
        return {'FINISHED'}


class BS_OT_camera(bpy.types.Operator):
    bl_idname = 'blockstage.add_camera'
    bl_label = 'Create Shot Camera'
    bl_description = 'Add a camera aimed above the 3D cursor and set shot duration, frame rate and 720p output'
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        object_mode(context)
        s = context.scene.bs_settings
        staging.create_camera(context,s.camera_move,s.duration,s.fps,s.lens)
        return {'FINISHED'}


class BS_OT_lights(bpy.types.Operator):
    bl_idname = 'blockstage.add_lights'
    bl_label = 'Add Soft Lighting'
    bl_description = 'Add three area lights around the 3D cursor and a neutral world'
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        staging.create_lights(context)
        return {'FINISHED'}


class BS_OT_camera_view(bpy.types.Operator):
    bl_idname = 'blockstage.camera_view'
    bl_label = 'View Camera'

    @classmethod
    def poll(cls, context):
        return context.scene.camera is not None and context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        bpy.ops.view3d.view_camera()
        return {'FINISHED'}


class BS_OT_export(bpy.types.Operator):
    bl_idname = 'blockstage.export_reference'
    bl_label = 'Export Reference Pack'
    bl_description = 'Export shot notes, color ID manifest and optional start/middle/end PNGs to a new subfolder'
    directory: StringProperty(subtype='DIR_PATH')
    filter_folder: BoolProperty(default=True, options={'HIDDEN'})
    render_stills: BoolProperty(name='Render three keyframes', default=True)
    video: BoolProperty(default=False, options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return context.scene.camera is not None and not bpy.app.is_job_running('RENDER')

    def invoke(self, context, event):
        self.directory = bpy.path.abspath('//') if bpy.data.is_saved else str(Path.home())
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        directory = Path(bpy.path.abspath(self.directory)) / ('blockstage_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
        try:
            staging.write_handoff(context.scene,directory,context.scene.bs_settings.notes)
            if self.video:
                staging.set_reference_render(context.scene,directory / 'blocking.mp4',video=True)
                bpy.ops.render.render('INVOKE_DEFAULT',animation=True)
                self.report({'INFO'},f'Rendering blocking video to {directory}')
            else:
                if self.render_stills:
                    staging.render_keyframes(context.scene,directory)
                self.report({'INFO'},f'Reference pack saved: {directory}')
        except Exception as exc:
            self.report({'ERROR'},f'Export did not complete: {exc}')
            return {'CANCELLED'}
        return {'FINISHED'}


class BS_PT_library(bpy.types.Panel):
    bl_label = 'BLOCKSTAGE / BASE 01'
    bl_idname = 'BS_PT_library'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Blockstage'

    def draw(self, context):
        layout = self.layout
        s = context.scene.bs_settings
        layout.label(text='Simple shapes. Directed motion.',icon='OUTLINER_OB_CAMERA')
        layout.prop(s,'pack',text='')
        layout.prop(s,'category',text='')
        layout.prop(s,'search',text='',icon='VIEWZOOM')
        previews.draw_picker(layout, context, 'library')
        if s.category == 'CHARACTERS':
            layout.label(text='Body + hands rigged / no face rig', icon='INFO')
        layout.separator()
        layout.operator('blockstage.add_room',icon='CUBE')


class BS_PT_selected(bpy.types.Panel):
    bl_label = 'Selected Asset'
    bl_idname = 'BS_PT_selected'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Blockstage'
    bl_parent_id = 'BS_PT_library'

    def draw(self, context):
        layout = self.layout
        root = current_root(context)
        if root is None:
            layout.label(text='Select an asset or one of its parts.')
            return
        layout.prop(root,'name',text='')
        row = layout.row(align=True)
        row.operator('blockstage.duplicate',icon='DUPLICATE')
        row.operator('blockstage.next_color',text='',icon='COLOR')
        layout.operator('blockstage.select_hierarchy',icon='OUTLINER_OB_EMPTY')
        if characters.is_cast(root):
            cast_tools.draw_controls(layout, context, root)
        elif root.get('bs_kind') == 'character':
            s = context.scene.bs_settings
            layout.operator('blockstage.pose_mode',icon='POSE_HLT')
            row = layout.row(align=True)
            row.prop(s,'pose',text='')
            row.operator('blockstage.apply_pose',text='',icon='CHECKMARK')
            row = layout.row(align=True)
            row.prop(s,'grip')
            row.operator('blockstage.hand_curl',text='',icon='CHECKMARK')
            layout.operator('blockstage.key_pose',icon='KEY_HLT')
        elif root.get('bs_kind') == 'room':
            if root.get('bs_plan_version'):
                layout.label(text='Edit in Room Builder above.', icon='INFO')
            else:
                room.draw_room_settings(layout,root)
            layout.prop(context.scene.bs_settings,'layout_preset',text='')
            layout.operator('blockstage.furnish_room',icon='OUTLINER_COLLECTION')
        elif root.get('bs_kind') == 'prop':
            s = context.scene.bs_settings
            layout.prop(s,'attach_rig')
            layout.prop(s,'attach_hand',expand=True)
            layout.operator('blockstage.attach_to_hand',icon='CONSTRAINT_BONE')


class BS_PT_shot(bpy.types.Panel):
    bl_label = 'Shot & Reference'
    bl_idname = 'BS_PT_shot'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Blockstage'
    bl_parent_id = 'BS_PT_library'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        s = context.scene.bs_settings
        layout.prop(s,'camera_move')
        row = layout.row(align=True)
        row.prop(s,'duration')
        row.prop(s,'fps')
        layout.prop(s,'lens',text='Lens / mm')
        layout.operator('blockstage.add_camera',icon='CAMERA_DATA')
        row = layout.row(align=True)
        row.operator('blockstage.add_lights',icon='LIGHT_AREA')
        row.operator('blockstage.camera_view',text='',icon='VIEW_CAMERA')
        layout.prop(s,'notes')
        layout.separator()
        layout.operator('blockstage.export_reference',icon='RENDER_STILL')
        op = layout.operator('blockstage.export_reference',text='Render Reference Video',icon='RENDER_ANIMATION')
        op.video = True
        op.render_stills = False
        layout.label(text='Local export / upload to your video tool',icon='INFO')


classes = (BS_Settings,BS_OT_add_character,BS_OT_add_asset,BS_OT_add_room,BS_OT_duplicate,BS_OT_furnish,BS_OT_attach,BS_OT_recolor,
           BS_OT_select_hierarchy,BS_OT_pose,BS_OT_grip,BS_OT_pose_mode,BS_OT_key_pose,BS_OT_camera,
           BS_OT_lights,BS_OT_camera_view,BS_OT_export,BS_PT_library,BS_PT_selected,BS_PT_shot)


def register():
    room.register()
    plan.register()
    room_tools.register()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.bs_settings = PointerProperty(type=BS_Settings)
    previews.register()
    appearance.register()
    cast_tools.register()
    core.register()


def unregister():
    cast_tools.unregister()
    appearance.unregister()
    previews.unregister()
    core.unregister()
    del bpy.types.Scene.bs_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    room_tools.unregister()
    plan.unregister()
    room.unregister()


if __name__ == '__main__':
    register()
