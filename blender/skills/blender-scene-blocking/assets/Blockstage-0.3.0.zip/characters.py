"""The four supplied adult Cast actors, appended with their authored rigs intact."""
from pathlib import Path
import uuid
import bpy
from . import core, cast_rig, legacy_pose

CHARACTER_ITEMS = (
    ('MAN', 'Man', 'Adult man with body, finger, IK and FK controls'),
    ('WOMAN', 'Woman', 'Adult woman with body, finger, IK and FK controls'),
    ('HEAVY_MAN', 'Heavy Man', 'Heavy adult man with body, finger, IK and FK controls'),
    ('HEAVY_WOMAN', 'Heavy Woman', 'Heavy adult woman with body, finger, IK and FK controls'),
)
POSE_ITEMS = (
    ('NEUTRAL', 'Neutral', 'Reset to the supplied neutral pose'),
    ('WALK', 'Walk', 'One editable walking contact pose'),
    ('SIT', 'Sit', 'An editable seated starting pose'),
    ('REACH', 'Reach', 'Reach forward with one arm'),
    ('HOLD', 'Hold Prop', 'Hold an object with both hands'),
)


def is_cast(actor):
    return bool(cast_rig.is_rig(actor) and actor.get('bs_cast_variant'))


def create_character(context, variant, collection, color_index=0):
    variant = variant.upper()
    labels = {item[0]: item[1] for item in CHARACTER_ITEMS}
    if variant not in labels:
        raise ValueError('Unknown character: ' + variant)
    library = Path(__file__).parent / 'data' / 'cast_library.blend'
    if not library.is_file():
        raise RuntimeError('The actor library is missing. Install the complete Blockstage ZIP.')
    collection_name = 'CAST_' + variant.lower()
    with bpy.data.libraries.load(str(library), link=False) as (source, target):
        if collection_name not in source.collections:
            raise RuntimeError('Actor is missing from the library: ' + labels[variant])
        target.collections = [collection_name]
    imported = target.collections[0]
    collection.children.link(imported)
    actors = [o for o in imported.all_objects if cast_rig.is_rig(o)]
    if len(actors) != 1:
        raise RuntimeError('The actor collection must contain exactly one rig.')
    actor = actors[0]
    actor.name = labels[variant]
    actor['bs_root'] = True
    actor['bs_kind'] = 'character'
    actor['bs_asset'] = variant
    actor['bs_cast_variant'] = variant
    actor['bs_cast_label'] = labels[variant]
    actor['bs_rig_version'] = 2
    actor['bs_height_scale'] = float(actor.get('mm_height_scale', 1))
    actor['bs_hand_grip'] = float(actor.get('mm_hand_grip', 0))
    actor['bs_pose'] = str(actor.get('mm_pose', 'NEUTRAL'))
    actor['bs_bone_count'] = len(actor.data.bones)
    actor['mm_instance'] = uuid.uuid4().hex
    actor['bs_rig_notes'] = 'Body and finger controls; matched IK/FK switches. Use Selected Asset and Rig Details in Blockstage.'
    # All included widgets are children of the actor. Tag them for Blockstage's
    # whole-object color, duplicate and export tools; never treat them as body meshes.
    for obj in list(imported.all_objects):
        if obj.get('mm_widget'):
            obj['bs_widget'] = True
            obj.hide_render = True
            obj.hide_set(True)
        if obj.get('mm_body'):
            obj['bs_body'] = True
    actor['bs_triangle_count'] = sum(sum(len(face.vertices)-2 for face in obj.data.polygons)
        for obj in imported.all_objects if obj.get('mm_body'))
    core.recolor(actor, color_index)
    return actor


def apply_pose(actor, pose):
    if is_cast(actor):
        cast_rig.apply_pose(actor, pose)
        actor['bs_pose'] = actor.get('mm_pose', 'NEUTRAL')
    else:
        legacy_pose.apply_pose(actor, pose)


def set_hand_grip(actor, amount, side='BOTH'):
    if is_cast(actor):
        cast_rig.set_hand_grip(actor, amount, side)
        actor['bs_hand_grip'] = float(amount)
    else:
        legacy_pose.set_hand_grip(actor, amount)


def key_pose(actor, frame):
    for path in ('location', 'scale', 'rotation_quaternion' if actor.rotation_mode == 'QUATERNION' else 'rotation_euler'):
        actor.keyframe_insert(path, frame=frame, group='Actor')
    controls = cast_rig.animation_controls(actor) if is_cast(actor) else actor.pose.bones
    for bone in controls:
        for path in ('location', 'scale', 'rotation_quaternion' if bone.rotation_mode == 'QUATERNION' else 'rotation_euler'):
            bone.keyframe_insert(path, frame=frame, group=bone.name)
        if is_cast(actor):
            for key, value in bone.items():
                if isinstance(value, (int, float)):
                    bone.keyframe_insert('["' + bpy.utils.escape_identifier(key) + '"]', frame=frame, group=bone.name)
        else:
            for constraint in bone.constraints:
                if constraint.type == 'IK': constraint.keyframe_insert('influence', frame=frame)
