"""Camera blocking and reference handoff. No generation service or API required."""
import json
import math
from pathlib import Path

import bpy
from mathutils import Vector

from . import core

CAMERA_ITEMS = (
    ('STATIC', 'Locked-off', 'A static camera with an editable aim target'),
    ('DOLLY', 'Dolly in', 'A gentle five-second push toward the action'),
    ('TRUCK', 'Track sideways', 'A lateral camera move, keeping the aim target'),
    ('ORBIT', 'Arc around', 'A restrained 35-degree arc around the subject'),
)


def create_camera(context, move='STATIC', duration=5, fps=24, lens=40):
    scene = context.scene
    collection = core.asset_collection(context, 'Camera / ' + move.title())
    target = bpy.data.objects.new('BS / Aim target', None)
    collection.objects.link(target)
    target.empty_display_type = 'SPHERE'
    target.empty_display_size = .16
    center = context.scene.cursor.location.copy()
    center.z += 1.05
    target.location = center
    camera_data = bpy.data.cameras.new('BS / Blocking lens')
    camera = bpy.data.objects.new('BS / Camera', camera_data)
    collection.objects.link(camera)
    camera_data.lens = lens
    camera_data.clip_end = 500
    camera_data.passepartout_alpha = .9
    camera_data.show_composition_thirds = True
    camera['bs_camera'] = True
    camera['bs_move'] = move
    camera.location = center + Vector((4.6, -7.6, 2.2))
    aim = camera.constraints.new('TRACK_TO')
    aim.name = 'Aim at action'
    aim.target = target
    aim.track_axis = 'TRACK_NEGATIVE_Z'
    aim.up_axis = 'UP_Y'
    scene.camera = camera
    scene.render.fps = fps
    scene.render.fps_base = 1
    scene.frame_start = 1
    scene.frame_end = max(2, int(duration * fps))
    scene.render.resolution_x = 1280
    scene.render.resolution_y = 720
    scene.render.resolution_percentage = 100
    if move != 'STATIC':
        start = camera.location.copy()
        steps = 12 if move == 'ORBIT' else 1
        for i in range(steps + 1):
            t = i / steps
            if move == 'DOLLY':
                camera.location = start.lerp(center + (start - center) * .72, t)
            elif move == 'TRUCK':
                camera.location = start + Vector((-3 * t, 0, 0))
            else:
                angle = math.radians(35) * t
                d = start - center
                camera.location = center + Vector((d.x*math.cos(angle)-d.y*math.sin(angle),
                                                   d.x*math.sin(angle)+d.y*math.cos(angle),d.z))
            camera.keyframe_insert('location', frame=1 + round((scene.frame_end-1)*t), group='Blocking camera')
        # The default Bezier interpolation provides a soft start and stop.
    scene.frame_set(1)
    core.select_root(context, camera)
    return camera


def create_lights(context):
    collection = core.asset_collection(context, 'Studio lights')
    cursor = context.scene.cursor.location
    for name, location, power, size in (
        ('Key', (1,-4,7), 1500, 7), ('Fill', (-5,-1,4), 700, 5), ('Edge', (2,4,6), 1200, 4)):
        data = bpy.data.lights.new('BS / ' + name, 'AREA')
        data.energy = power
        data.shape = 'DISK'
        data.size = size
        obj = bpy.data.objects.new(data.name, data)
        collection.objects.link(obj)
        obj.location = cursor + Vector(location)
        obj.rotation_euler = (cursor + Vector((0,0,1)) - obj.location).to_track_quat('-Z','Y').to_euler()
    if context.scene.world is None:
        context.scene.world = bpy.data.worlds.new('BS / World')
    context.scene.world.use_nodes = True
    background = context.scene.world.node_tree.nodes.get('Background')
    if background:
        background.inputs[0].default_value = (.16,.18,.21,1)
        background.inputs[1].default_value = .4
    return collection


def set_reference_render(scene, filepath, video=False):
    scene.render.engine = 'BLENDER_EEVEE_NEXT' if bpy.app.version < (5, 0, 0) else 'BLENDER_EEVEE'
    scene.render.film_transparent = False
    scene.render.use_file_extension = True
    scene.render.filepath = str(filepath)
    if hasattr(scene.render.image_settings,'media_type'):
        scene.render.image_settings.media_type = 'VIDEO' if video else 'IMAGE'
    if video:
        if not hasattr(scene.render.image_settings,'media_type'):
            scene.render.image_settings.file_format = 'FFMPEG'
        scene.render.ffmpeg.format = 'MPEG4'
        scene.render.ffmpeg.codec = 'H264'
        scene.render.ffmpeg.constant_rate_factor = 'MEDIUM'
        scene.render.ffmpeg.audio_codec = 'NONE'
    else:
        scene.render.image_settings.file_format = 'PNG'
        scene.render.image_settings.color_mode = 'RGB'


def reference_manifest(scene, notes=''):
    fps = scene.render.fps / scene.render.fps_base
    cast = []
    for obj in scene.objects:
        if obj.get('bs_root'):
            index = int(obj.get('bs_color_index',0))
            color_name = core.PALETTE[index][0] if index < len(core.PALETTE) else 'Custom ID ' + str(index+1)
            cast.append({'name':obj.name, 'asset':obj.get('bs_asset',''), 'kind':obj.get('bs_kind',''),
                         'id':obj.get('bs_identity',0), 'color':color_name,
                         'linear_rgba':list(obj.color), 'position_meters':list(obj.location)})
    return {'tool':'Blockstage 0.1.0', 'purpose':'3D blocking reference', 'units':'meters',
            'fps':fps, 'first_frame':scene.frame_start, 'last_frame':scene.frame_end,
            'duration_seconds':(scene.frame_end-scene.frame_start+1)/fps,
            'resolution':[round(scene.render.resolution_x*scene.render.resolution_percentage/100),
                          round(scene.render.resolution_y*scene.render.resolution_percentage/100)],
            'camera':{'name':scene.camera.name,'lens_mm':scene.camera.data.lens} if scene.camera else None,
            'assets':cast, 'director_notes':notes}


def prompt_text(manifest):
    cast = '\n'.join(f"- {a['name']}: {a['asset']}; blocking ID color {a['color']}. Replace with: [describe final appearance]."
                     for a in manifest['assets'] if a['kind'] == 'character')
    return ("Use the uploaded BLOCKING VIDEO as the reference for camera trajectory, framing, "
            "subject positions, screen direction, timing and physical contacts.\n"
            "Use the separate LOOK REFERENCES for the final characters, clothing, materials and location. "
            "The low-poly meshes and flat colors indicate staging and role IDs; replace them with the described final look.\n"
            "Keep the number of people, their relative scale, hand-object contacts and visible entrances/exits. "
            "Do not add cuts unless requested. Preserve the start and end composition.\n\n"
            f"CAST MAPPING\n{cast or '[Add character descriptions]'}\n\n"
            f"DIRECTOR NOTES\n{manifest['director_notes'] or '[Describe the action and final visual style]'}\n\n"
            "Review the generated take against this reference: camera, timing, anatomy, contacts and cast identity. "
            "A reference guides the model; it does not guarantee exact reconstruction.\n")


def write_handoff(scene, directory, notes=''):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    manifest = reference_manifest(scene, notes)
    (directory / 'shot.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    (directory / 'prompt.txt').write_text(prompt_text(manifest),encoding='utf-8')
    return manifest


def render_keyframes(scene, directory):
    """Three clean PNGs, restoring the artist's render settings even on failure."""
    directory = Path(directory)
    frames = sorted({scene.frame_start, (scene.frame_start+scene.frame_end)//2, scene.frame_end})
    old = {'frame':scene.frame_current, 'filepath':scene.render.filepath, 'engine':scene.render.engine,
           'format':scene.render.image_settings.file_format,'mode':scene.render.image_settings.color_mode,
           'transparent':scene.render.film_transparent, 'extension':scene.render.use_file_extension}
    if hasattr(scene.render.image_settings,'media_type'):
        old['media_type'] = scene.render.image_settings.media_type
    try:
        for frame in frames:
            scene.frame_set(frame)
            set_reference_render(scene,directory / f'frame_{frame:04d}.png')
            bpy.ops.render.render(write_still=True, scene=scene.name)
    finally:
        scene.render.engine = old['engine']
        scene.render.filepath = old['filepath']
        if 'media_type' in old:
            scene.render.image_settings.media_type = old['media_type']
        if old.get('media_type','IMAGE') == 'IMAGE':
            scene.render.image_settings.file_format = old['format']
        scene.render.image_settings.color_mode = old['mode']
        scene.render.film_transparent = old['transparent']
        scene.render.use_file_extension = old['extension']
        scene.frame_set(old['frame'])
