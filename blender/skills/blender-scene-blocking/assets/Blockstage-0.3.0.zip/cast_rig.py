"""New body and finger armature for the supplied Man_Mesh anatomy.

This module builds its own bone graph from the supplied Man_Mesh rest landmarks.
It does not append the old rig, its widgets, actions, drivers or embedded UI.
FK and IK are separate editable chains. Endpoint mode switches match controls
and verify the resulting matrices before accepting a snap. Explicit continuous
blending is also available; unsupported FK twists are rejected transactionally.
"""
from math import atan2, cos, pi, radians, sin

import bpy
from mathutils import Matrix, Vector

RIG_TYPE = 'MAN_MESH_NEW'
FINGERS = ('thumb', 'index', 'middle', 'ring', 'pinky')
PRIMARY = {
    'root': 'CTRL_root', 'pelvis': 'CTRL_pelvis', 'spine': 'CTRL_waist',
    'chest': 'CTRL_chest', 'neck': 'CTRL_neck', 'head': 'CTRL_head',
}


def is_rig(rig):
    return bool(rig and rig.type == 'ARMATURE' and rig.get('mm_rig_type') == RIG_TYPE)


def control_name(rig, semantic):
    name = PRIMARY.get(semantic, semantic)
    # Primary hand/foot buttons follow the active endpoint controller. At an
    # intermediate blend both chains still contribute, so keep the IK target;
    # fully FK uses the matching wrist/ankle rotation control instead.
    if is_rig(rig):
        for part, limb in (('hand', 'arm'), ('foot', 'leg')):
            if name in {'CTRL_' + part + '.L', 'CTRL_' + part + '.R'}:
                side = name[-1]
                if get_ik_fk(rig, limb, side) >= .999:
                    return 'CTRL_' + part + '_fk.' + side
    return name


def control_tool(rig, name):
    name = control_name(rig, name)
    return 'MOVE' if name in {'CTRL_root', 'CTRL_pelvis'} or any(
        name.startswith(prefix) for prefix in ('CTRL_hand.', 'CTRL_foot.', 'CTRL_elbow.', 'CTRL_knee.')
    ) else 'ROTATE'


def animation_controls(rig):
    return [bone for bone in rig.pose.bones if bone.name.startswith('CTRL_') or
            bone.name.split('.')[0] in FINGERS]


def animation_properties(rig):
    """Owner/path pairs to key alongside control transforms, never driven bones."""
    return [(rig.pose.bones['CTRL_hand.'+side], '["'+prop+'"]')
            for side in ('L','R') for prop in ('curl','spread')] + [
            (rig.pose.bones['CTRL_foot.'+side], '["'+prop+'"]')
            for side in ('L','R') for prop in ('roll_degrees','bank_degrees')]


def _property_driver(rig, bone, channel, index, control, prop, expression):
    driver = rig.pose.bones[bone].driver_add(channel,index).driver
    driver.type = 'SCRIPTED'
    driver.expression = expression
    variable = driver.variables.new()
    variable.name = 'value'
    variable.type = 'SINGLE_PROP'
    variable.targets[0].id = rig
    variable.targets[0].data_path = 'pose.bones["'+control+'"]["'+prop+'"]'
    return driver


def _native_property(bone,name,value,minimum,maximum,description):
    bone[name] = value
    bone.id_properties_ui(name).update(min=minimum,max=maximum,
                                       soft_min=minimum,soft_max=maximum,
                                       description=description)


def reveal_control(rig, name):
    bone = rig.data.bones.get(control_name(rig, name))
    if bone:
        bone.hide = False
        for collection in bone.collections:
            collection.is_visible = True


def _bone(data, name, start, end, parent=None, deform=False, connected=False,
          roll_axis=(0, -1, 0)):
    bone = data.edit_bones.new(name)
    bone.head, bone.tail = Vector(start), Vector(end)
    bone.use_deform = deform
    if parent:
        bone.parent = data.edit_bones[parent]
        bone.use_connect = connected
    bone.align_roll(Vector(roll_axis))
    return bone


def _copy(rig, owner, target, influence=1.0, name='Follow control'):
    constraint = rig.pose.bones[owner].constraints.new('COPY_TRANSFORMS')
    constraint.name = name
    constraint.target, constraint.subtarget = rig, target
    constraint.owner_space = 'POSE'
    constraint.target_space = 'POSE'
    constraint.influence = influence
    return constraint


def _blend_driver(constraint, rig, mode):
    driver = constraint.driver_add('influence').driver
    driver.type = 'SCRIPTED'
    driver.expression = '1.0-min(1.0,max(0.0,fk))'
    variable = driver.variables.new()
    variable.name, variable.type = 'fk', 'TRANSFORMS'
    target = variable.targets[0]
    target.id, target.bone_target = rig, mode
    target.transform_type = 'LOC_Y'
    target.transform_space = 'LOCAL_SPACE'


def _pole_rest_angle(bone, end, pole):
    """Project the desired bend plane onto the root bone's own local axes."""
    direction = Vector(end) - bone.head
    bend_normal = direction.cross(Vector(pole) - bone.head)
    pole_axis = bend_normal.cross(bone.tail - bone.head).normalized()
    x_axis = bone.x_axis.normalized()
    along = (bone.tail - bone.head).normalized()
    return -atan2(along.dot(x_axis.cross(pole_axis)), x_axis.dot(pole_axis))


def _pole_position(start, middle, end, distance):
    line = (end - start).normalized()
    bend = middle - start - line * (middle - start).dot(line)
    if bend.length < 1e-5:
        bend = Vector((0, -1, 0))
    return middle + bend.normalized() * distance


def _widget(collection, rig, label, style):
    if style in ('ring','root','torso'):
        vertices = [(cos(i*pi/12), 0, sin(i*pi/12)) for i in range(24)]
        edges = [(i, (i+1) % 24) for i in range(24)]
        if style == 'root':
            vertices += [(-.20,0,1.06),(0,0,1.33),(.20,0,1.06),(-1.15,0,0),(-.86,0,0),(1.15,0,0),(.86,0,0),(0,0,-1.15),(0,0,-.86)]
            edges += [(24,25),(25,26),(26,24),(27,28),(29,30),(31,32)]
        elif style == 'torso':
            vertices = [(x*1.18,y,z*.72) for x,y,z in vertices]
            vertices += [(-1.30,0,0),(-1.05,0,0),(1.05,0,0),(1.30,0,0)]
            edges += [(24,25),(26,27)]
    elif style == 'diamond':
        # An octahedral wire retains the diamond silhouette when a pole's
        # local display plane turns edge-on to the front or side viewport.
        vertices = [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
        edges = [(a,b) for a in range(6) for b in range(a+1,6)
                 if a//2 != b//2]
    else:
        vertices = [(x, y, z) for z in (-.3, .3) for y in (-.75, .75) for x in (-1, 1)]
        edges = [(0, 1), (1, 3), (3, 2), (2, 0), (4, 5), (5, 7),
                 (7, 6), (6, 4), (0, 4), (1, 5), (2, 6), (3, 7)]
    mesh = bpy.data.meshes.new('Control display / ' + label)
    mesh.from_pydata(vertices, edges, [])
    widget = bpy.data.objects.new('Control display / ' + label, mesh)
    collection.objects.link(widget)
    widget.parent = rig
    widget.hide_render = True
    widget.hide_set(True)
    widget['mm_widget'] = True
    return widget


def _fitted_widget(collection,rig,side,kind,a,unit):
    """Fit displays to the visible shoulder, hand and foot regions."""
    name='CTRL_'+kind+'.'+side
    inverse=rig.data.bones[name].matrix_local.inverted()
    points=[];edges=[]
    if kind=='clavicle':
        # The clavicle rotates about its anatomical inner head, but the display
        # belongs on the shoulder. Build a front-facing cap in armature space
        # and convert it to the controller's local axes without moving its pivot.
        center=a['clavicle_origin'].lerp(a['shoulder'],.9)
        center.y=min(a['clavicle_origin'].y,a['shoulder'].y)-.045*unit
        center.z+=.035*unit
        for outer in (True,False):
            width=(.088 if outer else .075)*unit
            height=(.052 if outer else .041)*unit
            for i in range(17):
                angle=pi*i/16
                points.append(center+Vector((cos(angle)*width,0,sin(angle)*height)))
        edges=[(i,i+1) for i in range(16)]+[(i,i+1) for i in range(17,33)]+[(0,17),(16,33)]
    elif kind=='foot':
        lo=a['toe'].y-.030*unit;hi=a['heel'].y+.012*unit
        center=Vector((a['ankle'].x,(lo+hi)/2,a['heel'].z+.008*unit))
        half_width=.069*unit;half_length=(hi-lo)/2;radius=.022*unit
        for cx,cy,start in ((half_width-radius,half_length-radius,0),(-half_width+radius,half_length-radius,90),
                            (-half_width+radius,-half_length+radius,180),(half_width-radius,-half_length+radius,270)):
            for step in range(4):
                angle=radians(start+step*30)
                points.append(center+Vector((cx+radius*cos(angle),cy+radius*sin(angle),0)))
        edges=[(i,(i+1)%16) for i in range(16)]
        points += [center+Vector((-.024*unit,-half_length+.046*unit,0)),
                   center+Vector((0,-half_length+.018*unit,0)),
                   center+Vector((.024*unit,-half_length+.046*unit,0))]
        edges += [(16,17),(17,18)]
    else:
        center=a['wrist']+a['hand_dir']*.054*unit
        across=a['across'];along=a['hand_dir'];normal=a['palm_depth']
        for depth in (-.018*unit,.018*unit):
            for i in range(16):
                angle=2*pi*i/16
                # A rounded capsule reads as a palm rather than a generic box.
                x=cos(angle)*.062*unit;y=sin(angle)*.077*unit
                points.append(center+across*x+along*y+normal*depth)
        edges=[(i,(i//16)*16+(i+1)%16) for i in range(32)]
        edges += [(i,i+16) for i in (0,4,8,12)]
    mesh=bpy.data.meshes.new('Control display / '+kind+'.'+side)
    mesh.from_pydata([inverse@point for point in points],edges,[])
    widget=bpy.data.objects.new('Control display / '+kind+'.'+side,mesh)
    collection.objects.link(widget);widget.parent=rig;widget.hide_render=True;widget.hide_set(True);widget['mm_widget']=True
    return widget


def create_rig(context, collection, anatomy, finger_paths, profile, colorindex=0):
    """Build a new rig against geometry's already transformed variant landmarks."""
    fingers = finger_paths
    variant = profile.get('variant', 'MAN')
    height = float(profile['height'])
    unit = height / 1.8
    data = bpy.data.armatures.new('Body rig / ' + variant.title())
    rig = bpy.data.objects.new('Actor / ' + variant.title(), data)
    collection.objects.link(rig)
    rig.show_in_front = True
    data.display_type = 'STICK'
    rig.color = (.32, .60, .78, 1)
    metadata = {
        'mm_root': True, 'mm_kind': 'character', 'mm_asset': variant, 'mm_variant':variant,
        'mm_rig_type': RIG_TYPE, 'mm_rig_version': 1,
        'mm_height_scale': unit, 'mm_hand_grip': 0.0, 'mm_pose': 'NEUTRAL',
        'mm_provenance': 'Newly authored armature fitted to supplied Man_Mesh geometry and rest landmarks; body weights transferred, fingers newly weighted.',
        'mm_rig_notes': 'Hands/feet use two-bone IK and editable poles. FK/IK endpoint switches match and verify the pose; unsupported twist configurations leave it unchanged. Fingers remain individually editable alongside native curl/spread. Explicit blending can change a pose.',
        'mm_snap_policy':'Verified matrix matching; unsupported twists leave the pose intact. No collision or automatic gait solving.',
    }
    for key, value in metadata.items():
        rig[key] = value
    if context.object and context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for selected in context.selected_objects:
        selected.select_set(False)
    rig.select_set(True)
    context.view_layer.objects.active = rig
    bpy.ops.object.mode_set(mode='EDIT')
    _bone(data, 'CTRL_root', (0, 0, .015*unit), (0, 0, .18*unit))
    joints = profile['joints']
    body_chain = [('pelvis', 'spine.01', 'CTRL_pelvis'),
                  ('spine.01', 'spine.02', 'CTRL_waist'),
                  ('spine.02', 'neck', 'CTRL_chest'),
                  ('neck', 'head', 'CTRL_neck'), ('head', 'head_tip', 'CTRL_head')]
    parent_control, parent_deform = 'CTRL_root', 'CTRL_root'
    follows = []
    for start, end, control in body_chain:
        _bone(data, control, joints[start], joints[end], parent_control)
        _bone(data, start, joints[start], joints[end], parent_deform, deform=True)
        follows.append((start, control))
        parent_control, parent_deform = control, start

    ik_solvers, blend_pairs = [], []
    for side in ('L', 'R'):
        a = anatomy[side]
        clavicle = 'clavicle.' + side
        clavicle_control = 'CTRL_clavicle.' + side
        _bone(data, clavicle_control, a['clavicle_origin'], a['shoulder'], 'CTRL_chest')
        _bone(data, clavicle, a['clavicle_origin'], a['shoulder'], 'spine.02', deform=True)
        follows.append((clavicle, clavicle_control))
        for limb, segments, base_parent, pole_label, target_label in (
            ('arm', [('upper_arm', 'shoulder', 'elbow'), ('forearm', 'elbow', 'wrist'),
                     ('hand', 'wrist', 'palm_end')], clavicle, 'elbow', 'hand'),
            ('leg', [('thigh', 'hip', 'knee'), ('shin', 'knee', 'ankle'),
                     ('foot', 'ankle', 'ball'), ('toe', 'ball', 'toe')], 'pelvis', 'knee', 'foot'),
        ):
            start_key, joint_key, end_key = ('shoulder', 'elbow', 'wrist') if limb == 'arm' else ('hip', 'knee', 'ankle')
            pole = _pole_position(a[start_key], a[joint_key], a[end_key], .36*unit)
            pole_name = 'CTRL_' + pole_label + '.' + side
            _bone(data, pole_name, pole, pole + Vector((0, 0, .065*unit)), 'CTRL_root')
            target = 'CTRL_' + target_label + '.' + side
            endpoint = a['palm_end'] if limb == 'arm' else a['ball']
            _bone(data, target, a[end_key], endpoint, 'CTRL_root')
            mode = 'CTRL_mode_' + limb + '.' + side
            mode_start = a[start_key] + Vector((0, .13*unit, 0))
            _bone(data, mode, mode_start, mode_start + Vector((0, .045*unit, 0)), 'CTRL_root', roll_axis=(0, 0, 1))
            chains = {}
            for role in ('DEF', 'FK', 'IK'):
                parent = base_parent
                names = []
                for index, (part, start, end) in enumerate(segments):
                    name = part + '.' + side if role == 'DEF' else ('CTRL_' + part + '_fk.' + side if role == 'FK' else 'MCH_' + part + '_ik.' + side)
                    _bone(data, name, a[start], a[end], parent, deform=role == 'DEF', connected=index > 0)
                    names.append(name)
                    parent = name
                chains[role] = names
            for deform, fk, ik in zip(chains['DEF'], chains['FK'], chains['IK']):
                blend_pairs.append((deform, fk, ik, mode))
            solver_target = target
            if limb == 'leg':
                pivot_parent = target
                for pivot, key in [('bank', 'ankle'), ('heel', 'heel'), ('tip', 'toe'), ('ball', 'ball')]:
                    name = 'MCH_foot_' + pivot + '.' + side
                    _bone(data, name, a[key], a[key] + Vector((0, .085*unit, 0)), pivot_parent, roll_axis=(0, 0, 1))
                    pivot_parent = name
                solver_target = 'MCH_ankle_target.' + side
                _bone(data, solver_target, a['ankle'], a['ball'], pivot_parent)
                _bone(data, 'CTRL_toe_ik.' + side, a['ball'], a['toe'], 'MCH_foot_tip.' + side)
                follows.append((chains['IK'][3], 'CTRL_toe_ik.' + side))
            angle = _pole_rest_angle(data.edit_bones[chains['IK'][0]], a[end_key], pole)
            ik_solvers.append((chains['IK'][1], chains['IK'][2], solver_target, pole_name, angle))
        for finger in FINGERS:
            points, names, radius = fingers[(finger, side)]
            parent = 'hand.' + side
            for index, name in enumerate(names):
                curl = 'MCH_curl_' + name
                _bone(data, curl, points[index], points[index+1], parent,
                      roll_axis=-a['palm_depth'])
                _bone(data, name, points[index], points[index+1], curl,
                      deform=True, roll_axis=-a['palm_depth'])
                parent = name

    bpy.ops.object.mode_set(mode='OBJECT')
    for owner, target in follows:
        _copy(rig, owner, target)
    for deform, fk, ik, mode in blend_pairs:
        _copy(rig, deform, fk, name='FK pose')
        constraint = _copy(rig, deform, ik, name='IK pose blend')
        _blend_driver(constraint, rig, mode)
    for lower, end, target, pole, angle in ik_solvers:
        constraint = rig.pose.bones[lower].constraints.new('IK')
        constraint.name = 'Original two-bone IK'
        constraint.target, constraint.subtarget = rig, target
        constraint.pole_target, constraint.pole_subtarget = rig, pole
        constraint.pole_angle = angle
        constraint.chain_count = 2
        constraint.use_stretch = False
        constraint.iterations = 96
        rotation = rig.pose.bones[end].constraints.new('COPY_ROTATION')
        rotation.name = 'IK end orientation'
        rotation.target, rotation.subtarget = rig, target
        rotation.owner_space = 'POSE'
        rotation.target_space = 'POSE'
    for side in ('L','R'):
        hand = rig.pose.bones['CTRL_hand.'+side]
        foot = rig.pose.bones['CTRL_foot.'+side]
        _native_property(hand,'curl',0.0,0.0,1.0,'Curl all five fingers; individual phalanges remain editable')
        _native_property(hand,'spread',0.0,-1.0,1.0,'Spread or gather the fingers around their knuckles')
        _native_property(foot,'roll_degrees',0.0,-50.0,90.0,'IK foot roll in degrees around heel, ball and toe pivots')
        _native_property(foot,'bank_degrees',0.0,-40.0,40.0,'IK foot bank in degrees')
        for finger in FINGERS:
            # Thumb opposition brings it across the curled fingers; treating
            # the metacarpal like another finger hinge folds it back too far.
            angles = (10,38,35) if finger == 'thumb' else (57,76,54)
            for segment,angle in enumerate(angles,1):
                _property_driver(rig,f'MCH_curl_{finger}.{segment:02d}.{side}',
                                 'rotation_euler',0,hand.name,'curl',f'value*{radians(angle):.12f}')
            spread_angle = {'thumb':-.38,'index':-.16,'middle':-.04,'ring':.10,'pinky':.23}[finger]
            driver = _property_driver(rig,f'MCH_curl_{finger}.01.{side}', 'rotation_euler',2,
                                      hand.name,'spread',f'value*{spread_angle*(-1 if side=="L" else 1):.12f}')
            if finger == 'thumb':
                grip = driver.variables.new();grip.name='grip';grip.type='SINGLE_PROP'
                grip.targets[0].id=rig
                grip.targets[0].data_path='pose.bones["'+hand.name+'"]["curl"]'
                driver.expression += '+grip*'+str(-1.10 if side=='L' else 1.10)
        for part,expression in (
            ('heel','min(value,0.0)*0.017453292519943'),
            ('ball','min(max(value,0.0),45.0)*0.017453292519943'),
            ('tip','max(value-45.0,0.0)*0.017453292519943')):
            _property_driver(rig,'MCH_foot_'+part+'.'+side,'rotation_euler',0,foot.name,'roll_degrees',expression)
        _property_driver(rig,'MCH_foot_bank.'+side,'rotation_euler',1,foot.name,'bank_degrees',
                         'value*'+str(radians(1)*(1 if side=='L' else -1)))
    widgets = {style: _widget(collection, rig, style, style) for style in ('ring', 'diamond', 'root','torso')}
    fitted={(kind,side):_fitted_widget(collection,rig,side,kind,anatomy[side],unit)
            for side in ('L','R') for kind in ('clavicle','hand','foot')}
    groups = {name: data.collections.new(name) for name in (
        'Body controls', 'Hands and feet IK', 'Elbow and knee poles', 'Fingers',
        'FK limbs', 'IK FK mode', 'Deform skeleton', 'Mechanism')}
    for name in ('Fingers','FK limbs', 'IK FK mode', 'Deform skeleton', 'Mechanism'):
        groups[name].is_visible = False
    for bone in data.bones:
        pose = rig.pose.bones[bone.name]
        pose.rotation_mode = 'XYZ'
        name = bone.name
        if name.startswith('MCH_'):
            group = 'Mechanism'
        elif name.startswith('CTRL_mode_'):
            group = 'IK FK mode'
            pose.lock_location = (True, False, True)
            pose.lock_rotation = (True, True, True)
            pose.lock_scale = (True, True, True)
            limit = pose.constraints.new('LIMIT_LOCATION')
            limit.name = '0 IK / 1 FK'
            limit.use_min_y = limit.use_max_y = True
            limit.min_y, limit.max_y = 0.0, 1.0
            limit.owner_space = 'LOCAL'
        elif '_fk.' in name:
            group = 'FK limbs'
        elif name.startswith(('CTRL_elbow.', 'CTRL_knee.')):
            group = 'Elbow and knee poles'
        elif name.startswith(('CTRL_hand.', 'CTRL_foot.')):
            group = 'Hands and feet IK'
        elif name.startswith('CTRL_'):
            group = 'Body controls'
        elif name.split('.')[0] in FINGERS:
            group = 'Fingers'
        else:
            group = 'Deform skeleton'
        groups[group].assign(bone)
        bone.color.palette = 'CUSTOM'
        bone.color.custom.normal = (.18,.73,.95) if name.endswith('.L') else (.98,.37,.28) if name.endswith('.R') else (.96,.75,.35)
        bone.color.custom.select = (1.0,.88,.48)
        bone.color.custom.active = (1.0,1.0,.82)
        if group in {'Body controls', 'Hands and feet IK', 'Elbow and knee poles'}:
            if name.startswith('CTRL_clavicle.'):
                pose.custom_shape=fitted[('clavicle',name[-1])]
                pose.use_custom_shape_bone_size=False
                pose.custom_shape_scale_xyz=(1,1,1)
                continue
            if group == 'Hands and feet IK':
                pose.custom_shape=fitted[('hand' if name.startswith('CTRL_hand') else 'foot',name[-1])]
                pose.use_custom_shape_bone_size=False
                pose.custom_shape_scale_xyz=(1,1,1)
                continue
            style='diamond' if group=='Elbow and knee poles' else 'root' if name=='CTRL_root' else 'torso' if name in ('CTRL_pelvis','CTRL_chest') else 'ring'
            pose.custom_shape = widgets[style]
            pose.use_custom_shape_bone_size = False
            size = .31 if name == 'CTRL_root' else .19 if name in {'CTRL_pelvis', 'CTRL_chest'} else .095 if name=='CTRL_head' else .065
            if group == 'Elbow and knee poles':
                size = .038
            pose.custom_shape_scale_xyz = (size*unit,) * 3
    rig['mm_bone_count'] = len(data.bones)
    context.view_layer.update()
    return rig


def get_ik_fk(rig, limb, side):
    return min(1.0, max(0.0, rig.pose.bones['CTRL_mode_' + limb.lower() + '.' + side.upper()].location.y))


def set_ik_fk(rig, limb, side, blend, snap=True):
    """0 is IK, 1 is FK; endpoint switches match controls before changing mode.

Full matrix agreement is checked. Unrepresentable FK twists leave the original
pose intact and raise an explicit error; snap=False is an intentional blend.
"""
    limb, side = limb.lower(), side.upper()
    if limb not in ('arm', 'leg') or side not in ('L', 'R'):
        raise ValueError('Expected arm or leg and L or R')
    value = min(1.0, max(0.0, float(blend)))
    mode = rig.pose.bones['CTRL_mode_' + limb + '.' + side]
    saved = {bone.name:bone.matrix_basis.copy() for bone in rig.pose.bones}
    property_values = [(owner,path,owner.path_resolve(path)) for owner,path in animation_properties(rig)]
    parts = ('upper_arm','forearm','hand') if limb == 'arm' else ('thigh','shin','foot','toe')
    before = {part:rig.pose.bones[part+'.'+side].matrix.copy() for part in parts}
    if snap and value in (0.0,1.0) and abs(mode.location.y-value) > 1e-6:
        if value == 1:
            for part in parts:
                rig.pose.bones['CTRL_'+part+'_fk.'+side].matrix = before[part]
                bpy.context.view_layer.update()
        else:
            root_bone = rig.pose.bones[parts[0]+'.'+side]
            lower_bone = rig.pose.bones[parts[1]+'.'+side]
            pole = _pole_position(root_bone.head.copy(),root_bone.tail.copy(),lower_bone.tail.copy(),
                                  .36*float(rig.get('mm_height_scale',1)))
            pole_name = 'CTRL_'+('elbow' if limb=='arm' else 'knee')+'.'+side
            matrix = rig.pose.bones[pole_name].matrix.copy();matrix.translation = pole
            rig.pose.bones[pole_name].matrix = matrix
            if limb == 'leg':
                rig.pose.bones['CTRL_foot.'+side]['roll_degrees'] = 0.0
                rig.pose.bones['CTRL_foot.'+side]['bank_degrees'] = 0.0
            target = 'CTRL_'+('hand' if limb=='arm' else 'foot')+'.'+side
            rig.pose.bones[target].matrix = before[parts[2]]
            rig.update_tag();bpy.context.view_layer.update()
            if limb == 'leg':
                rig.pose.bones['CTRL_toe_ik.'+side].matrix = before['toe']
                bpy.context.view_layer.update()
    mode.location.y = value
    rig.update_tag();bpy.context.view_layer.update()
    maximum = 0.0
    if snap and value in (0.0,1.0):
        for part in parts:
            after = rig.pose.bones[part+'.'+side].matrix
            maximum = max(maximum,max(abs(after[row][column]-before[part][row][column])
                                      for row in range(4) for column in range(4)))
        if maximum > .002:
            for name,matrix in saved.items():rig.pose.bones[name].matrix_basis = matrix
            for owner,path,old in property_values:owner[path[2:-2]] = old
            rig.update_tag();bpy.context.view_layer.update()
            raise ValueError('This FK twist cannot be matched by the IK bend plane. Pose preserved; use explicit blend mode to change it.')
    if blend > 0:
        rig.data.collections['FK limbs'].is_visible = True
    bpy.context.view_layer.update()
    return {'mode':value,'snapped':bool(snap and value in (0.0,1.0)),'maximum_matrix_error':maximum}


def set_foot_roll(rig, side, roll, bank=0):
    """Roll in degrees around the authored heel/ball/toe contact landmarks."""
    side = side.upper()
    if side not in ('L', 'R'):
        raise ValueError('Expected L or R')
    roll = min(90.0, max(-50.0, float(roll)))
    bank = min(40.0, max(-40.0, float(bank)))
    target = rig.pose.bones['CTRL_foot.' + side]
    target['roll_degrees'], target['bank_degrees'] = roll, bank
    rig.update_tag()
    bpy.context.view_layer.update()


def set_hand_grip(rig, amount, side='BOTH'):
    amount = min(1.0, max(0.0, float(amount)))
    sides = ('L', 'R') if side.upper() == 'BOTH' else (side.upper(),)
    for direction in sides:
        if direction not in ('L','R'):
            raise ValueError('Expected L, R or BOTH')
        rig.pose.bones['CTRL_hand.'+direction]['curl'] = amount
    rig['mm_hand_grip'] = amount
    rig.update_tag()
    bpy.context.view_layer.update()


def set_hand_spread(rig, amount, side='BOTH'):
    sides = ('L','R') if side.upper() == 'BOTH' else (side.upper(),)
    for direction in sides:
        if direction not in ('L','R'):
            raise ValueError('Expected L, R or BOTH')
        rig.pose.bones['CTRL_hand.'+direction]['spread'] = min(1.0,max(-1.0,float(amount)))
    rig.update_tag()
    bpy.context.view_layer.update()


def reset_pose(rig):
    return apply_pose(rig,'NEUTRAL')


def _place(rig, name, position, direction=None):
    bone = rig.pose.bones[name]
    matrix = bone.bone.matrix_local.copy()
    if direction is not None:
        old_direction = (bone.bone.tail_local-bone.bone.head_local).normalized()
        rotation = old_direction.rotation_difference(Vector(direction).normalized())
        matrix = rotation.to_matrix().to_4x4() @ matrix
    matrix.translation = Vector(position)
    bone.matrix = matrix


def apply_pose(rig, pose):
    """A single hand-authored blocking pose, without animation or automatic gait."""
    if not is_rig(rig):
        return
    pose = pose.upper()
    unit = float(rig.get('mm_height_scale', 1.0))
    for bone in rig.pose.bones:
        bone.matrix_basis = Matrix.Identity(4)
    for side in ('L','R'):
        rig.pose.bones['CTRL_hand.'+side]['curl'] = 0.0
        rig.pose.bones['CTRL_hand.'+side]['spread'] = 0.0
        rig.pose.bones['CTRL_foot.'+side]['roll_degrees'] = 0.0
        rig.pose.bones['CTRL_foot.'+side]['bank_degrees'] = 0.0
    rig.update_tag()
    bpy.context.view_layer.update()
    def rest(name):
        return rig.data.bones[name].head_local.copy()
    def move(name, delta):
        _place(rig, name, rest(name) + Vector(delta)*unit)
    if pose == 'WALK':
        move('CTRL_pelvis', (0, 0, -.035))
        for side, sign in (('L', 1), ('R', -1)):
            move('CTRL_foot.' + side, (0, -.24*sign, .012 if sign == 1 else .045))
            move('CTRL_hand.' + side, (-.06*sign, .18*sign, .035))
        rig.pose.bones['CTRL_chest'].rotation_euler.y = radians(-5)
        set_hand_grip(rig, .18)
    elif pose == 'SIT':
        move('CTRL_pelvis', (0, .025, -.39))
        for side, sign in (('L', 1), ('R', -1)):
            move('CTRL_foot.' + side, (.025*sign, -.36, 0))
            move('CTRL_knee.' + side, (.025*sign, -.28, -.08))
            _place(rig, 'CTRL_hand.' + side, Vector((sign*.23, -.28, .72))*unit, (sign*.05, -.70, -.70))
        rig.pose.bones['CTRL_waist'].rotation_euler.x = radians(4)
        set_hand_grip(rig, .1)
    elif pose == 'REACH':
        _place(rig, 'CTRL_hand.R', Vector((-.27, -.48, 1.58))*unit, (-.1, -.8, .45))
        _place(rig, 'CTRL_elbow.R', Vector((-.65, -.25, 1.22))*unit)
        rig.pose.bones['CTRL_chest'].rotation_euler.x = radians(4)
        rig.pose.bones['CTRL_head'].rotation_euler.x = radians(-7)
        set_hand_grip(rig, .05)
    elif pose == 'HOLD':
        for side, sign in (('L', 1), ('R', -1)):
            _place(rig, 'CTRL_hand.' + side, Vector((sign*.15, -.34, 1.19))*unit, (0, -.7, -.7))
            _place(rig, 'CTRL_elbow.' + side, Vector((sign*.57, -.03, 1.05))*unit)
        set_hand_grip(rig, .78)
    else:
        pose = 'NEUTRAL'
        set_hand_grip(rig, 0.0)
    rig['mm_pose'] = pose
    bpy.context.view_layer.update()
