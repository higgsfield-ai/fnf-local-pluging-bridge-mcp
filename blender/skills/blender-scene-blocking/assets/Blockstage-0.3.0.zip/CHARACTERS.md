# Four Actor Rig Guide

## Add a character

1. Open **N > Blockstage > BLOCKSTAGE / BASE 01**.
2. Choose **Characters**, then click the large thumbnail.
3. Choose **Man**, **Woman**, **Heavy Man** or **Heavy Woman**.
4. Press **Add [Name]**. The independent actor appears at the 3D Cursor.
5. Select any part of the actor and open **Selected Asset > Pose Controls**.

These four characters replace the previous catalog entries. The bundled library contains exactly these four actors. Their geometry, skin weights, rest bones, native constraints and rig drivers come from the supplied Blockstage Cast add-on. No separate Cast installation or embedded Python script execution is required.

## Body and hands

**Move All** selects the root. **Hips**, **Chest**, **Head** and **Shoulder L/R** select their body controls. **Hand**, **Foot**, **Elbow** and **Knee** select the corresponding endpoint or pole control. The buttons choose move or rotate gizmos automatically. In FK mode, hand and foot buttons select the matching FK endpoint control.

**Hand Grip > Open / Hold / Fist** sets the left or right hand. Open **Rig Details**, enable **Fingers**, and rotate a phalanx for an individual finger pose. Every finger, including each thumb, has three editable bones. The hand Curl and Spread sliders remain available.

## IK/FK and feet

In **Rig Details**, each arm and leg has **Snap to IK** and **Snap to FK** buttons. These match the target controls to the current pose and switch modes. The imported rig verifies the resulting matrices. An FK twist that cannot be represented by the IK bend plane is rejected with the original pose preserved.

The **IK FK mode** bone collection exposes the authored continuous blend controls. Local Y location 0 is IK and 1 is FK. Manually blending can change the pose; use the snap buttons when you want to preserve it.

**Roll** and **Bank** control the IK feet in degrees. They use the original heel, ball and toe pivots.

## Animate, copy and attach props

Choose a frame, pose the actor and press **Key Pose**. This keys the actor transform, editable controls, finger bones and rig properties, including grip and foot settings. It does not key driven mechanism bones. Pose presets are editable starting poses, not complete animation cycles.

**Duplicate Asset** makes an independent mesh, armature, widgets and animation copy. Internal rig targets point to the duplicate, and the copy can be recolored independently with **Object Color**.

For a prop, choose the actor and hand in **Selected Asset**, then use **Attach to Hand**. The prop follows the imported hand bone.

## Existing files

Installing this version replaces the add-on's character catalog. Actors already stored in an existing .blend are not automatically substituted or deleted, so their existing animation can be retained. Older Blockstage actors keep their original pose-tool compatibility.

## Validation

All four meshes, vertex weights and rest skeletons were compared to the supplied library. Each has 141 bones. Integration tests cover finger curl, individual finger rotation, hand IK, neutral-pose IK/FK matching, foot roll, pose presets, keyed rig properties, independent duplicates, prop attachment and save/reopen. The combined package also retains room generation, furniture previews and whole-object colors.
