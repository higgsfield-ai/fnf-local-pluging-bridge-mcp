"""Editable architectural blockouts with actual, inexpensive wall openings.

The room root is the document: geometry children are derived from its settings.
Only children marked ``bs_room_part`` are replaced. Props, cameras and furniture
may therefore be parented to the room without being moved or deleted on resize.
"""

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, PointerProperty

from .core import material


_UPDATING = set()
_WALLS = ("front", "back", "left", "right")
_WALL_ITEMS = [
    ("NONE", "None", "Do not make an opening"),
    ("BACK", "Back", "Positive Y wall"),
    ("LEFT", "Left", "Negative X wall"),
    ("RIGHT", "Right", "Positive X wall"),
    ("FRONT", "Front", "Negative Y wall"),
]


def _on_change(self, context):
    root = self.id_data
    if isinstance(root, bpy.types.Object) and root.get("bs_kind") == "room":
        if root.get("bs_plan_version"):
            from . import plan
            plan.rebuild(root)
        else:
            update_room(root, context)


class BS_RoomSettings(bpy.types.PropertyGroup):
    width: FloatProperty(name="Width", description="Clear interior width in meters",
                         default=6, min=1.5, max=50, unit="LENGTH", update=_on_change)
    depth: FloatProperty(name="Depth", description="Clear interior depth in meters",
                         default=5, min=1.5, max=50, unit="LENGTH", update=_on_change)
    height: FloatProperty(name="Height", description="Floor-to-ceiling height in meters",
                          default=3, min=1.5, max=15, unit="LENGTH", update=_on_change)
    wall_thickness: FloatProperty(name="Wall Thickness", default=.15, min=.05,
                                  max=1, unit="LENGTH", update=_on_change)
    floor_thickness: FloatProperty(name="Floor Thickness", default=.12, min=.04,
                                   max=.75, unit="LENGTH", update=_on_change)
    front: BoolProperty(name="Front", default=False, update=_on_change)
    back: BoolProperty(name="Back", default=True, update=_on_change)
    left: BoolProperty(name="Left", default=True, update=_on_change)
    right: BoolProperty(name="Right", default=True, update=_on_change)
    ceiling: BoolProperty(name="Ceiling", default=False, update=_on_change)
    trim: BoolProperty(name="Architectural Trim", default=True, update=_on_change)
    door_wall: EnumProperty(name="Door Wall", items=_WALL_ITEMS,
                            default="BACK", update=_on_change)
    door_width: FloatProperty(name="Door Width", default=1, min=.4, max=6,
                              unit="LENGTH", update=_on_change)
    door_height: FloatProperty(name="Door Height", default=2.2, min=1, max=8,
                               unit="LENGTH", update=_on_change)
    door_offset: FloatProperty(name="Door Offset", description="Distance from the wall center; clamped to fit",
                               default=-1.65, min=-25, max=25, unit="LENGTH", update=_on_change)
    window_wall: EnumProperty(name="Window Wall", items=_WALL_ITEMS,
                              default="RIGHT", update=_on_change)
    window_width: FloatProperty(name="Window Width", default=1.8, min=.3, max=12,
                                unit="LENGTH", update=_on_change)
    window_height: FloatProperty(name="Window Height", default=1.2, min=.3, max=8,
                                 unit="LENGTH", update=_on_change)
    window_sill: FloatProperty(name="Sill Height", default=1, min=.1, max=8,
                               unit="LENGTH", update=_on_change)
    window_offset: FloatProperty(name="Window Offset", description="Distance from the wall center; clamped to fit",
                                 default=0, min=-25, max=25, unit="LENGTH", update=_on_change)
    window_mullion: BoolProperty(name="Window Crossbar", default=True, update=_on_change)


def _clamp(value, lo, hi):
    return max(lo, min(hi, value))


def opening_rectangles(settings, wall):
    """Return bounded (left, right, bottom, top, kind) opening rectangles.

    Openings retain requested dimensions in the UI and fit the current wall.
    A door and window sharing a wall are separated so neither frame crosses an
    opening. If the wall is too narrow, the door takes priority and the window
    is omitted until the room becomes wide enough again.
    """
    length = settings.width if wall in {"front", "back"} else settings.depth
    margin = .12
    low, high = -length / 2 + margin, length / 2 - margin
    available = high - low
    result = []
    if settings.door_wall.lower() == wall:
        size = min(settings.door_width, available)
        center = _clamp(settings.door_offset, low + size / 2, high - size / 2)
        result.append((center - size / 2, center + size / 2, 0,
                       min(settings.door_height, settings.height - margin), "door"))
    if settings.window_wall.lower() == wall:
        size = min(settings.window_width, available)
        bottom = min(settings.window_sill, settings.height - margin - .3)
        top = min(bottom + settings.window_height, settings.height - margin)
        center = _clamp(settings.window_offset, low + size / 2, high - size / 2)
        x0, x1 = center - size / 2, center + size / 2
        if result:
            door = result[0]
            if bottom < door[3] + margin and x1 > door[0] - margin and x0 < door[1] + margin:
                choices = [(low, door[0] - margin), (door[1] + margin, high)]
                choices = [span for span in choices if span[1] - span[0] >= .3]
                if not choices:
                    return result
                span = min(choices, key=lambda s: abs((s[0] + s[1]) / 2 - center))
                size = min(size, span[1] - span[0])
                center = _clamp(center, span[0] + size / 2, span[1] - size / 2)
                x0, x1 = center - size / 2, center + size / 2
        result.append((x0, x1, bottom, top, "window"))
    return result


def _append_box(vertices, faces, center, dimensions):
    x, y, z = center
    dx, dy, dz = [value / 2 for value in dimensions]
    if min(dx, dy, dz) <= .000001:
        return
    start = len(vertices)
    vertices.extend([
        (x-dx, y-dy, z-dz), (x+dx, y-dy, z-dz),
        (x+dx, y+dy, z-dz), (x-dx, y+dy, z-dz),
        (x-dx, y-dy, z+dz), (x+dx, y-dy, z+dz),
        (x+dx, y+dy, z+dz), (x-dx, y+dy, z+dz),
    ])
    faces.extend(tuple(start + index for index in face) for face in (
        (0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
        (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7),
    ))


def _wall_box(settings, wall, u0, u1, z0, z1, thickness=None, inset=0):
    """Wall-space cuboid; positive inset moves toward the room interior."""
    thickness = settings.wall_thickness if thickness is None else thickness
    u, z = (u0 + u1) / 2, (z0 + z1) / 2
    if wall in {"front", "back"}:
        sign = -1 if wall == "front" else 1
        center = (u, sign * (settings.depth / 2 + settings.wall_thickness / 2 - inset), z)
        size = (u1 - u0, thickness, z1 - z0)
    else:
        sign = -1 if wall == "left" else 1
        center = (sign * (settings.width / 2 + settings.wall_thickness / 2 - inset), u, z)
        size = (thickness, u1 - u0, z1 - z0)
    return center, size


def _wall_geometry(settings, wall, holes):
    """Partition the wall at rectangle boundaries, leaving real empty openings."""
    length = settings.width if wall in {"front", "back"} else settings.depth
    extra = settings.wall_thickness if wall in {"front", "back"} else 0
    u0, u1 = -length / 2 - extra, length / 2 + extra
    xs = sorted({u0, u1, *(x for hole in holes for x in hole[:2])})
    zs = sorted({0, settings.height, *(z for hole in holes for z in hole[2:4])})
    vertices, faces = [], []
    for left, right in zip(xs, xs[1:]):
        for bottom, top in zip(zs, zs[1:]):
            x, z = (left + right) / 2, (bottom + top) / 2
            if any(a < x < b and c <= z < d for a, b, c, d, _ in holes):
                continue
            _append_box(vertices, faces, *_wall_box(settings, wall, left, right, bottom, top))
    return vertices, faces


def _trim_geometry(settings, wall, holes):
    vertices, faces = [], []
    length = settings.width if wall in {"front", "back"} else settings.depth
    t, edge = settings.wall_thickness, .055
    # A cap and skirting define the simple wall silhouette. Skirting stops at doors.
    _append_box(vertices, faces, *_wall_box(settings, wall, -length / 2, length / 2,
                                          settings.height - .09, settings.height,
                                          thickness=t + .035))
    boundaries = sorted({-length / 2, length / 2,
                         *(x for hole in holes if hole[4] == "door" for x in hole[:2])})
    for a, b in zip(boundaries, boundaries[1:]):
        if any(h[4] == "door" and h[0] < (a + b) / 2 < h[1] for h in holes):
            continue
        _append_box(vertices, faces, *_wall_box(settings, wall, a, b, 0, .085,
                                              thickness=t + .035))
    for a, b, c, d, kind in holes:
        # Frames sit outside the clear opening and extend slightly beyond both faces.
        for bounds in [(a-edge, a, c, d+edge), (b, b+edge, c, d+edge), (a, b, d, d+edge)]:
            _append_box(vertices, faces, *_wall_box(settings, wall, *bounds, thickness=t + .055))
        if kind == "window":
            _append_box(vertices, faces, *_wall_box(settings, wall, a-edge, b+edge,
                                                  c-edge, c, thickness=t + .13))
            if settings.window_mullion:
                mid_x, mid_z = (a+b) / 2, (c+d) / 2
                for bounds in [(mid_x-.018, mid_x+.018, c, d), (a, b, mid_z-.018, mid_z+.018)]:
                    _append_box(vertices, faces, *_wall_box(settings, wall, *bounds, thickness=.045))
    return vertices, faces


def _put_part(root, collection, key, geometry, role, existing):
    vertices, faces = geometry
    mesh = bpy.data.meshes.new(f"Room · {key}")
    mesh.from_pydata(vertices, [], faces)
    mesh.materials.append(material(role))
    mesh.update()
    obj = existing.pop(key, None)
    if obj is None:
        obj = bpy.data.objects.new(f"Room · {key.replace('_', ' ').title()}", mesh)
        collection.objects.link(obj)
        obj.parent = root
        obj["bs_room_part"] = key
        if not key.startswith("wall_"):
            modifier = obj.modifiers.new("Soft Architectural Edges", "BEVEL")
            modifier.width = .008
            modifier.segments = 1
            modifier.limit_method = "ANGLE"
    else:
        old_mesh = obj.data
        obj.data = mesh
        if old_mesh and old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)
    # Wall cells meet flush around openings. Beveling each cell exposes their
    # internal subdivisions; also remove our old modifier when updating rooms.
    if key.startswith("wall_"):
        modifier = obj.modifiers.get("Soft Architectural Edges")
        if modifier and modifier.type == "BEVEL":
            obj.modifiers.remove(modifier)
    obj.location = (0, 0, 0)
    obj.rotation_euler = (0, 0, 0)
    obj.scale = (1, 1, 1)
    obj["bs_generated"] = True
    from . import appearance
    appearance.restore_arch_part(root, obj, key)
    return obj


def update_room(root, context=None):
    """Rebuild just this room's generated geometry, preserving root and props."""
    if not root or root.get("bs_kind") != "room":
        return
    key = root.as_pointer()
    if key in _UPDATING:
        return
    _UPDATING.add(key)
    try:
        settings = root.bs_room
        collection = next(iter(root.users_collection), None)
        if collection is None:
            return
        existing = {obj["bs_room_part"]: obj for obj in root.children if obj.get("bs_room_part")}
        vertices, faces = [], []
        _append_box(vertices, faces, (0, 0, -settings.floor_thickness / 2),
                    (settings.width + 2 * settings.wall_thickness,
                     settings.depth + 2 * settings.wall_thickness, settings.floor_thickness))
        _put_part(root, collection, "floor", (vertices, faces), "wood", existing)
        if settings.ceiling:
            vertices, faces = [], []
            _append_box(vertices, faces, (0, 0, settings.height + settings.floor_thickness / 2),
                        (settings.width + 2 * settings.wall_thickness,
                         settings.depth + 2 * settings.wall_thickness, settings.floor_thickness))
            _put_part(root, collection, "ceiling", (vertices, faces), "light", existing)
        for wall in _WALLS:
            if not getattr(settings, wall):
                continue
            holes = opening_rectangles(settings, wall)
            _put_part(root, collection, f"wall_{wall}", _wall_geometry(settings, wall, holes), "light", existing)
            if settings.trim:
                _put_part(root, collection, f"trim_{wall}", _trim_geometry(settings, wall, holes), "dark", existing)
        for obj in existing.values():
            mesh = obj.data
            # Any manually parented child remains in place if its wall disappears.
            for child in list(obj.children):
                world = child.matrix_world.copy()
                child.parent = root
                child.matrix_world = world
            bpy.data.objects.remove(obj, do_unlink=True)
            if mesh and mesh.users == 0:
                bpy.data.meshes.remove(mesh)
    finally:
        _UPDATING.discard(key)


def create_room(context, collection, width=6, depth=5, height=3):
    """Create an independent room centered at the origin, with its floor at Z=0."""
    root = bpy.data.objects.new("Room · Studio", None)
    collection.objects.link(root)
    root.empty_display_type = "CUBE"
    root.empty_display_size = .25
    root["bs_root"] = True
    root["bs_kind"] = "room"
    root["bs_asset"] = "room"
    root["bs_label"] = "Procedural Room"
    key = root.as_pointer()
    _UPDATING.add(key)
    try:
        root.bs_room.width = width
        root.bs_room.depth = depth
        root.bs_room.height = height
    finally:
        _UPDATING.discard(key)
    update_room(root, context)
    return root


def draw_room_settings(layout, root):
    settings = root.bs_room
    column = layout.column(align=True)
    column.prop(settings, "width")
    column.prop(settings, "depth")
    column.prop(settings, "height")
    column.label(text="Dimensions keep furniture in place.", icon="INFO")
    row = layout.row(align=True)
    for wall in _WALLS:
        row.prop(settings, wall, toggle=True)
    row = layout.row(align=True)
    row.prop(settings, "ceiling", toggle=True)
    row.prop(settings, "trim", toggle=True)
    layout.prop(settings, "wall_thickness")
    layout.prop(settings, "floor_thickness")
    for kind in ("door", "window"):
        box = layout.box()
        box.prop(settings, f"{kind}_wall")
        wall = getattr(settings, f"{kind}_wall").lower()
        if wall == "none":
            continue
        column = box.column(align=True)
        column.prop(settings, f"{kind}_width")
        column.prop(settings, f"{kind}_height")
        column.prop(settings, f"{kind}_offset")
        if kind == "window":
            column.prop(settings, "window_sill")
            column.prop(settings, "window_mullion")
        if not getattr(settings, wall):
            box.label(text="Enable this wall to see the opening.", icon="INFO")
        if kind == "window" and not any(h[4] == "window" for h in opening_rectangles(settings, wall)):
            box.label(text="Widen wall or move window to another wall.", icon="INFO")


classes = (BS_RoomSettings,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.bs_room = PointerProperty(type=BS_RoomSettings)


def unregister():
    if hasattr(bpy.types.Object, "bs_room"):
        del bpy.types.Object.bs_room
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    _UPDATING.clear()
